# MoYa VPN — Core v0.5 (engineering build)

This is an Android library source package. It is not an APK and is not yet a release-ready VPN.

## Added in v0.4
- Android `VpnService` implementation with foreground notification, TUN ownership, IPv4 default route, IPv6 default route, DNS setup, socket-protection entry point, revoke cleanup, and explicit stop handling.
- Android VPN permission gate.
- Android Keystore-backed AES-256-GCM secret storage in app-private no-backup storage.
- Xray outbound delay probe through `Libv2ray.measureOutboundDelay`, matching the public API used by upstream v2rayNG.
- Xray state now distinguishes native core startup from successful outbound reachability. The engine is not marked established until at least one configured HTTPS probe succeeds.
- `AndroidTunnelSession` now connects Xray TUN creation, descriptor injection, coordinator startup, rollback, and teardown.
- Engine capability contract now supports engines that own their own TUN. Psiphon is modeled as an independent VpnManager/tun2socks lifecycle, not as a consumer of Xray's TUN.
- Psiphon adapter fails closed unless the official VpnManager + tun2socks + JNI path is imported and tested.

## Verified in this environment
- Pure Kotlin core sources compile with Kotlin/JVM.
- Fake-engine connect/disconnect smoke test passes (`SMOKE_TEST_OK`).
- Source package and ZIP integrity are checked at packaging time.

## Not verified / still required
- Full Android Gradle build: not run; Android SDK and Gradle are not installed in this environment.
- Xray: the official `libv2ray.aar` is not bundled. Add the exact release asset, verify its SHA-256, then compile against the real AAR.
- Android service/session: source has not been compiled or tested on Android 14 / Xiaomi 11T. Foreground-service policy, TUN routing, DNS, IPv6, revoke, and lifecycle behavior require device testing.
- Xray is now fail-closed until a verified native socket-protection path is implemented: `Libv2rayXrayNativeBridge.socketProtectionReady` is `false`, so `XrayEngine` refuses to start. Do not treat the `protectSocket` function parameter as wired.
- Network handover requires validation against the selected native AAR and device.
- Psiphon full-device VPN is intentionally blocked. The official app uses a separate `VpnManager` which establishes its own TUN and starts `Tun2SocksJniLoader`; the SDK alone is insufficient.
- Config Security Lab, signed source manifests, source discovery, and app UI are not complete.
- No real server profile is included. No real VPN connection or packet-leak test has been performed.

## Required build environment
- Android Studio / Android Gradle Plugin 8.7.3
- JDK 17
- Android SDK platform 35
- Kotlin Android plugin 2.0.21
- Add the pinned Xray AAR under `app/libs/` and declare it as a local dependency only after verifying the official checksum.

## Security notes
- AES-GCM is used for stored secret material. The Keystore key is non-exportable by design.
- Configs remain untrusted until inspected. A successful delay probe does not prove a server is safe.
- Do not log raw configs, UUIDs, credentials, private keys, server URIs, or native diagnostic messages.
- The Android TUN descriptor remains owned by the VPN service. Do not close it from an engine adapter.
- Do not enable Psiphon until the official Android packet-tunnel/TUN path is integrated and tested.

See `NATIVE_DEPENDENCIES.md` and `NATIVE_INTEGRATION_STATUS.md`.

## v0.5 engineering changes
- Added a shared-TUN session coordinator for Xray with rollback and descriptor cleanup.
- Added explicit engine-owned-TUN capability. The core coordinator no longer requires a shared TUN descriptor for Psiphon-style engines.
- Corrected the Psiphon integration contract to match the official architecture: Psiphon owns a separate TUN and routes its SOCKS listener through the official tun2socks JNI layer.
- Xray now fails closed while socket protection is unverified. The current libv2ray callback wrapper does not yet provide a proven `VpnService.protect()` integration.
- Added regression tests for shared-TUN lifecycle and engine-owned TUN handling.
