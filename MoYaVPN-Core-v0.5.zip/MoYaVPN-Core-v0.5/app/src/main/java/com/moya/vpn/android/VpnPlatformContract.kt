package com.moya.vpn.android

/** Platform adapter implemented by the Android VpnService module. */
interface VpnPlatform {
    fun establishTun(ipv4Address: String, ipv4Prefix: Int, dnsServers: List<String>, mtu: Int): Int
    fun protectSocket(fileDescriptor: Int): Boolean
    fun closeTun()
}

/** Called only after the user grants Android VPN permission. */
interface VpnPermissionGate { fun isPermissionGranted(): Boolean }
