package com.moya.vpn.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import java.io.IOException

/**
 * Owns Android's TUN interface. The selected native engine receives the TUN fd,
 * while this service retains the ParcelFileDescriptor for the entire tunnel lifetime.
 * Engine startup and connectivity verification are deliberately handled elsewhere.
 */
class MoYaVpnService : VpnService(), VpnPlatform {
    inner class LocalBinder : Binder() { fun service(): MoYaVpnService = this@MoYaVpnService }

    private val binder = LocalBinder()
    @Volatile private var tun: ParcelFileDescriptor? = null
    @Volatile private var revokedListener: (() -> Unit)? = null

    override fun onBind(intent: Intent): IBinder? {
        return if (intent.action == SERVICE_INTERFACE) super.onBind(intent) else binder
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            closeTun()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(startId)
            return START_NOT_STICKY
        }
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        return START_NOT_STICKY
    }

    fun setRevokedListener(listener: (() -> Unit)?) { revokedListener = listener }

    @Synchronized
    override fun establishTun(
        ipv4Address: String,
        ipv4Prefix: Int,
        dnsServers: List<String>,
        mtu: Int
    ): Int {
        require(ipv4Prefix in 1..32) { "INVALID_IPV4_PREFIX" }
        require(mtu in 1280..9000) { "INVALID_MTU" }
        require(dnsServers.isNotEmpty()) { "DNS_REQUIRED" }
        closeTun()

        val builder = Builder()
            .setSession("MoYa VPN")
            .setMtu(mtu)
            .addAddress(ipv4Address, ipv4Prefix)
            .addRoute("0.0.0.0", 0)

        dnsServers.forEach { builder.addDnsServer(it) }

        // Add IPv6 routing only when the platform supports it. The engine must also
        // be configured for IPv6; otherwise the app must use an IPv4-only profile.
        runCatching {
            builder.addAddress("fd42:6d6f:7961::1", 126)
            builder.addRoute("::", 0)
        }.getOrElse { throw IllegalStateException("IPV6_TUN_SETUP_FAILED", it) }

        val established = builder.establish() ?: throw SecurityException("VPN_PERMISSION_OR_ESTABLISH_FAILED")
        tun = established
        return established.fd
    }

    override fun protectSocket(fileDescriptor: Int): Boolean {
        if (fileDescriptor < 0) return false
        return protect(fileDescriptor)
    }

    @Synchronized
    override fun closeTun() {
        val current = tun
        tun = null
        try { current?.close() } catch (_: IOException) { }
    }

    fun currentTunFileDescriptor(): Int? = tun?.takeIf { it.fileDescriptor.valid() }?.fd

    override fun onRevoke() {
        try { revokedListener?.invoke() } finally {
            closeTun()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            super.onRevoke()
        }
    }

    override fun onDestroy() {
        closeTun()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "MoYa VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }
        return builder
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentTitle("MoYa VPN")
            .setContentText("VPN service is active")
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_START = "com.moya.vpn.action.START"
        const val ACTION_STOP = "com.moya.vpn.action.STOP"
        private const val CHANNEL_ID = "moya_vpn_status"
        private const val NOTIFICATION_ID = 4107
    }
}
