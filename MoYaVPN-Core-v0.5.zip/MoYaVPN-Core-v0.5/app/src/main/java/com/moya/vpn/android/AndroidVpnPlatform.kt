package com.moya.vpn.android

import android.content.Context
import android.net.VpnService

/** Thin adapter that exposes only the VPN operations required by the core. */
class AndroidVpnPlatform(private val service: MoYaVpnService) : VpnPlatform {
    override fun establishTun(ipv4Address: String, ipv4Prefix: Int, dnsServers: List<String>, mtu: Int): Int =
        service.establishTun(ipv4Address, ipv4Prefix, dnsServers, mtu)

    override fun protectSocket(fileDescriptor: Int): Boolean = service.protectSocket(fileDescriptor)
    override fun closeTun() = service.closeTun()
}

class AndroidVpnPermissionGate(context: Context) : VpnPermissionGate {
    private val appContext = context.applicationContext
    override fun isPermissionGranted(): Boolean = VpnService.prepare(appContext) == null
}

