package com.moya.vpn.security

import com.moya.vpn.core.ServerDescriptor

/** Security checks fail closed. A clean result is not a guarantee that a public server is trustworthy. */
enum class CheckDisposition { PASS, REVIEW, REJECT }
enum class CheckId { SIZE, PARSE, SCHEMA, DESTINATION, TLS, DNS, SIGNATURE }
data class CheckFinding(val id: CheckId, val disposition: CheckDisposition, val code: String)
data class SecurityReport(val findings: List<CheckFinding>) {
    val accepted: Boolean get() = findings.none { it.disposition != CheckDisposition.PASS }
}

fun interface ConfigSecurityPipeline { suspend fun inspect(server: ServerDescriptor): SecurityReport }

interface ConfigMaterialProvider {
    /** Returns secret material only to the selected engine; caller must clear mutable buffers. */
    suspend fun readConfig(secretRef: String): ByteArray?
}

interface PublisherSignatureVerifier {
    fun verify(manifest: ByteArray, signature: ByteArray, trustedPublicKey: ByteArray): Boolean
}
