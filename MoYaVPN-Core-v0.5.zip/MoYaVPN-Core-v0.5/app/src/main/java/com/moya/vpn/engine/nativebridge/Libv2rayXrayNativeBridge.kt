package com.moya.vpn.engine.nativebridge

import android.content.Context
import go.Seq
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import com.moya.vpn.engine.EngineCallback
import com.moya.vpn.engine.XrayNativeBridge
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Real adapter for AndroidLibXrayLite's generated libv2ray API.
 * API calls are aligned with the upstream v2rayNG CoreNativeManager/CoreServiceManager.
 */
class Libv2rayXrayNativeBridge(
    context: Context,
    private val assetPath: String,
    private val deviceId: String
) : XrayNativeBridge {
    private val appContext = context.applicationContext
    // CoreCallbackHandler methods verified so far do not expose a socket-protect hook.
    // Keep Xray disabled until the selected AAR's supported protection mechanism is proven.
    override val socketProtectionReady: Boolean = false
    private val initialized = AtomicBoolean(false)
    private val lock = Any()
    @Volatile private var controller: CoreController? = null
    @Volatile private var activeCallback: EngineCallback? = null

    private val nativeCallback = object : CoreCallbackHandler {
        override fun startup(): Long = 0L
        override fun shutdown(): Long {
            activeCallback?.onStopped()
            return 0L
        }
        override fun onEmitStatus(code: Long, message: String?): Long {
            // Do not forward native diagnostic text. It can contain endpoints or config data.
            if (code < 0L) activeCallback?.onFailure("XRAY_NATIVE_STATUS_$code")
            return 0L
        }
    }

    private fun ensureInitialized() {
        if (initialized.compareAndSet(false, true)) {
            try {
                Seq.setContext(appContext)
                Libv2ray.initCoreEnv(assetPath, deviceId)
            } catch (t: Throwable) {
                initialized.set(false)
                throw t
            }
        }
    }

    override suspend fun validateAndNormalize(configJson: String): String {
        val root = JSONObject(configJson)
        require(root.has("inbounds") && root.has("outbounds")) { "XRAY_CONFIG_SCHEMA_INVALID" }
        require(root.getJSONArray("outbounds").length() > 0) { "XRAY_OUTBOUND_MISSING" }
        ensureInitialized()
        // CoreController has no public config-normalization API. Keep the validated JSON unchanged;
        // native startLoop performs the authoritative core validation.
        return root.toString()
    }

    override suspend fun measureOutboundDelay(configJson: String, httpsTestUrl: String): Long =
        withContext(Dispatchers.IO) {
            require(httpsTestUrl.startsWith("https://", ignoreCase = true) && httpsTestUrl.length <= 2048) {
                "XRAY_TEST_URL_INVALID"
            }
            val normalized = validateAndNormalize(configJson)
            // This API is present in the upstream libv2ray API used by v2rayNG.
            // It is a diagnostic probe; a negative result means no successful probe.
            Libv2ray.measureOutboundDelay(normalized, httpsTestUrl)
        }

    override suspend fun start(
        configJson: String,
        tunFd: Int,
        protectSocket: (Int) -> Boolean,
        callback: EngineCallback
    ) = synchronized(lock) {
        check(controller?.isRunning != true) { "XRAY_ALREADY_RUNNING" }
        require(tunFd >= 0) { "XRAY_TUN_FD_REQUIRED" }
        ensureInitialized()
        val parsed = validateAndNormalize(configJson)
        val core = Libv2ray.newCoreController(nativeCallback)
        controller = core
        activeCallback = callback
        try {
            core.startLoop(parsed, tunFd)
            check(core.isRunning) { "XRAY_CORE_DID_NOT_START" }
            callback.onCoreStarted()
        } catch (t: Throwable) {
            activeCallback = null
            controller = null
            runCatching { if (core.isRunning) core.stopLoop() }
            callback.onFailure("XRAY_START_FAILED")
            throw t
        }
    }

    override suspend fun stop() = synchronized(lock) {
        val core = controller
        try {
            if (core?.isRunning == true) core.stopLoop()
        } finally {
            controller = null
            activeCallback?.onStopped()
            activeCallback = null
        }
    }
}
