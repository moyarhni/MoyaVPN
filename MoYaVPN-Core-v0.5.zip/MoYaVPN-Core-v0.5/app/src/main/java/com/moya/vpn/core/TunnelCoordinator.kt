package com.moya.vpn.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import java.time.Instant

/**
 * Single-owner state machine for tunnel lifecycle.
 * It serializes connect/disconnect, waits for a real Established event,
 * times out stalled engines, and rolls back partial starts.
 */
class TunnelCoordinator(
    private val registry: EngineRegistry,
    private val tunProvider: TunDescriptorProvider,
    private val validator: ServerPreflight,
    private val connectTimeoutMs: Long = 45_000L
) {
    private val mutex = Mutex()
    private val mutableStatus = MutableStateFlow(TunnelStatus())
    val status: StateFlow<TunnelStatus> = mutableStatus.asStateFlow()
    private var activeEngine: TunnelEngine? = null

    suspend fun connect(server: ServerDescriptor): Result<Unit> = mutex.withLock {
        if (mutableStatus.value.phase != TunnelPhase.IDLE && mutableStatus.value.phase != TunnelPhase.FAILED) {
            return@withLock Result.failure(IllegalStateException("Tunnel is not idle"))
        }
        val engine = registry.get(server.engine)
            ?: return@withLock fail(TunnelFailure.EngineUnavailable, "ENGINE_UNAVAILABLE")
        mutableStatus.value = TunnelStatus(TunnelPhase.VALIDATING, server.id, server.engine)

        try {
            val report = validator.validate(server)
            if (!report.accepted) return@withLock fail(TunnelFailure.InvalidConfiguration, "CONFIG_REJECTED")
            val engineCheck = engine.validate(server)
            if (!engineCheck.accepted) return@withLock fail(TunnelFailure.InvalidConfiguration, engineCheck.safeReasonCode ?: "ENGINE_VALIDATION_FAILED")

            val capabilities = engine.capabilities()
            val tunFd = if (capabilities.ownsTunInterface) {
                -1 // Engine establishes and owns its own VPN interface (Psiphon VpnManager path).
            } else {
                tunProvider.fileDescriptor()
                    ?: return@withLock fail(TunnelFailure.PermissionDenied, "TUN_NOT_ESTABLISHED")
            }
            mutableStatus.value = TunnelStatus(TunnelPhase.PREPARING, server.id, server.engine)
            activeEngine = engine
            mutableStatus.value = TunnelStatus(TunnelPhase.CONNECTING, server.id, server.engine)
            engine.start(server, tunFd)

            // StateFlow retains the latest event, so an immediate callback cannot be missed.
            val terminal = withTimeout(connectTimeoutMs) {
                engine.events.first { it is EngineEvent.Established || it is EngineEvent.Failed || it is EngineEvent.Stopped }
            }
            when (terminal) {
                EngineEvent.Established -> {
                    mutableStatus.value = TunnelStatus(TunnelPhase.CONNECTED, server.id, server.engine, Instant.now())
                    Result.success(Unit)
                }
                is EngineEvent.Failed -> {
                    runCatching { engine.stop() }
                    activeEngine = null
                    fail(TunnelFailure.EngineFailure(terminal.safeCode), terminal.safeCode)
                }
                EngineEvent.Stopped -> {
                    activeEngine = null
                    fail(TunnelFailure.EngineFailure("STOPPED_DURING_CONNECT"), "STOPPED_DURING_CONNECT")
                }
                else -> fail(TunnelFailure.InternalFailure, "UNEXPECTED_ENGINE_EVENT")
            }
        } catch (e: TimeoutCancellationException) {
            runCatching { engine.stop() }
            activeEngine = null
            fail(TunnelFailure.ConnectionTimedOut, "CONNECT_TIMEOUT")
        } catch (e: CancellationException) {
            runCatching { engine.stop() }
            activeEngine = null
            mutableStatus.value = TunnelStatus()
            throw e
        } catch (_: Throwable) {
            runCatching { engine.stop() }
            activeEngine = null
            fail(TunnelFailure.InternalFailure, "CONNECT_INTERNAL_ERROR")
        }
    }

    suspend fun disconnect(): Result<Unit> = mutex.withLock {
        val engine = activeEngine
        if (engine == null) {
            mutableStatus.value = TunnelStatus()
            return@withLock Result.success(Unit)
        }
        mutableStatus.value = mutableStatus.value.copy(phase = TunnelPhase.DISCONNECTING)
        val result = runCatching { engine.stop() }
        activeEngine = null
        mutableStatus.value = TunnelStatus()
        result
    }

    /** Called by the network monitor. The engine decides how to rebind sockets. */
    suspend fun onUnderlyingNetworkLost() {
        val engine = activeEngine ?: return
        if (mutableStatus.value.phase == TunnelPhase.CONNECTED) {
            mutableStatus.value = mutableStatus.value.copy(phase = TunnelPhase.CONNECTING)
            // Engine-specific network recovery is deliberately explicit; do not fake Connected.
            if (engine.events.value is EngineEvent.Failed) {
                mutableStatus.value = mutableStatus.value.copy(phase = TunnelPhase.FAILED,
                    failure = TunnelFailure.NetworkUnavailable)
            }
        }
    }

    private fun fail(failure: TunnelFailure, safeCode: String): Result<Unit> {
        mutableStatus.value = mutableStatus.value.copy(phase = TunnelPhase.FAILED, failure = failure)
        return Result.failure(IllegalStateException(safeCode))
    }
}

fun interface TunDescriptorProvider { fun fileDescriptor(): Int? }

/** Mutable descriptor slot shared by the Android VPN service session and coordinator. */
class MutableTunDescriptorProvider : TunDescriptorProvider {
    @Volatile private var descriptor: Int? = null

    override fun fileDescriptor(): Int? = descriptor

    fun attach(fileDescriptor: Int) {
        require(fileDescriptor >= 0) { "INVALID_TUN_DESCRIPTOR" }
        check(descriptor == null) { "TUN_DESCRIPTOR_ALREADY_ATTACHED" }
        descriptor = fileDescriptor
    }

    fun detach() { descriptor = null }
}
fun interface ServerPreflight { suspend fun validate(server: ServerDescriptor): PreflightResult }
data class PreflightResult(val accepted: Boolean, val safeCode: String? = null)
