# Native integration status — v0.4

## Xray
- Concrete `Libv2rayXrayNativeBridge` source uses the API names observed in upstream v2rayNG: `Seq.setContext`, `Libv2ray.initCoreEnv`, `Libv2ray.newCoreController`, `CoreController.startLoop`, `CoreController.stopLoop`, `CoreController.isRunning`.
- `Libv2ray.measureOutboundDelay(config, testUrl)` is exposed through the bridge and used as a reachability gate before `EngineEvent.Established`.
- `CoreStarted` and `Established` are separate events. Native loop startup alone is not treated as a successful remote connection.
- The official AAR is not bundled. Compilation against the exact AAR and runtime tests remain required.
- The bridge's `protectSocket` argument is not wired to a verified callback in the inspected `CoreCallbackHandler` API. `socketProtectionReady` is explicitly `false`, and `XrayEngine` fails closed until a supported socket-protection mechanism is verified and implemented.

## Android VPN service
- Added `MoYaVpnService`, `AndroidVpnPlatform`, and `AndroidVpnPermissionGate`.
- Added `AndroidTunnelSession` to establish the Xray TUN before engine startup, inject its descriptor into the coordinator, and close it on failure/disconnect.
- The service owns the `ParcelFileDescriptor`, creates IPv4/IPv6 default routes, adds DNS servers, exposes `protect(fd)`, and closes the TUN on stop/revoke/destroy.
- The session class is Xray/shared-TUN only. Psiphon has a separate VPN/TUN owner and must not use this session.
- Android compilation and device validation have not been performed. Verify foreground-service requirements on Android 14, permission flow, IPv6 behavior, DNS routing, and lifecycle recovery.

## Secret storage
- Added `AndroidKeystoreSecretStore`: AES-256-GCM, 96-bit IV, 128-bit authentication tag, Android Keystore key, app-private no-backup files, UUID references, and fail-closed decryption.
- Android runtime tests, tamper tests, backup/restore behavior, and key invalidation behavior remain required.

## Psiphon
- Official Android source inspected: `Psiphon-Inc/psiphon-android` `TunnelManager.java` and `com/psiphon3/VpnManager.java`.
- The official design is distinct from Xray: `PsiphonTunnel` supplies a local SOCKS listener; `VpnManager` establishes and owns a TUN, duplicates the descriptor, and starts `Tun2SocksJniLoader` with SOCKS and UDPGW endpoints.
- The official source shown here passes a null IPv6 parameter to tun2socks (IPv4-only routing in that path).
- Updated engine capability contract: Psiphon owns its TUN (`ownsTunInterface=true`), supports UDP, and does not consume the Xray descriptor. The coordinator now respects engine-owned TUN lifecycles.
- `PsiphonNativeBridge.fullDeviceVpnReady` remains `false`; the complete official VpnManager/Tun2Socks JNI implementation, native binaries, app callbacks, and service lifecycle are not yet imported or built. Psiphon remains unavailable by design.

## Release gate
1. Add and verify the pinned official Xray AAR.
2. Build the Android library with SDK 35 / JDK 17.
3. Verify Xray socket protection and wire service lifecycle, TUN ownership, engine startup, and network handover.
4. Implement and test Config Security Lab and signed source manifests.
5. Integrate Psiphon packet tunnel or keep it unavailable.
6. Test on Android 14, including DNS/IPv4/IPv6 leak tests, stop/revoke, reconnect, and network switching.
7. Review GPL-3.0 obligations for upstream components before distribution.
