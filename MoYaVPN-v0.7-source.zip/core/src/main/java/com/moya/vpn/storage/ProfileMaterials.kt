package com.moya.vpn.storage

import com.moya.vpn.discovery.ProxyProfile
import com.moya.vpn.discovery.XrayOutboundBuilder
import com.moya.vpn.engine.XrayConfigAssembler
import com.moya.vpn.security.ConfigMaterialProvider

/**
 * Bridges discovered profiles and the encrypted store: the generated Xray config is encrypted
 * at rest and only decrypted for the engine (and the stored-config preflight).
 */
class ProfileMaterials(private val secrets: SecretStore) : ConfigMaterialProvider {
    /** Returns the opaque secretRef to put in a ServerDescriptor. */
    suspend fun store(profile: ProxyProfile, mtu: Int = 1500): String {
        val config = XrayConfigAssembler.assembleTunConfig(XrayOutboundBuilder.build(profile), mtu)
        val bytes = config.toByteArray(Charsets.UTF_8)
        return try { secrets.put(bytes) } finally { bytes.fill(0) }
    }

    suspend fun remove(secretRef: String) = secrets.delete(secretRef)

    override suspend fun readConfig(secretRef: String): ByteArray? = secrets.get(secretRef)
}
