package com.moya.vpn.discovery

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlin.random.Random

data class SourceConfig(val id: String, val url: String, val enabled: Boolean = true)

interface SourceStore {
    suspend fun load(): List<SourceConfig>
    suspend fun save(sources: List<SourceConfig>)
}

class InMemorySourceStore(initial: List<SourceConfig> = DefaultSources.list) : SourceStore {
    @Volatile private var current = initial
    override suspend fun load(): List<SourceConfig> = current
    override suspend fun save(sources: List<SourceConfig>) { current = sources }
}

/**
 * Starting points only. Public lists die or get taken down (one well-known repo was disabled by
 * GitHub), so the user can edit this list and unhealthy sources are backed off automatically.
 * Only the first entry has been checked by hand (alive when reviewed); the others are unverified.
 */
object DefaultSources {
    val list = listOf(
        SourceConfig("au1rxx", "https://github.com/Au1rxx/free-vpn-subscriptions/raw/main/output/v2ray-base64.txt"),
        SourceConfig("epodonios", "https://github.com/Epodonios/v2ray-configs/raw/main/All_Configs_Sub.txt"),
        SourceConfig("delta-kronecker", "https://github.com/Delta-Kronecker/V2ray-Config/raw/refs/heads/main/config/protocols/vless.txt")
    )
}

data class SourceHealth(
    val lastAttemptMs: Long = 0L,
    val lastSuccessMs: Long = 0L,
    val lastLinkCount: Int = 0,
    val consecutiveFailures: Int = 0,
    val lastErrorCode: String? = null
)

/** [rejected] maps a stable reason code to a count, for the diagnostics screen. */
data class DiscoveryReport(
    val sourcesTried: Int,
    val sourcesFailed: Int,
    val linksSeen: Int,
    val accepted: Int,
    val rejected: Map<String, Int>,
    val atMs: Long
)

/** Sources -> parse -> TLS/Reality policy -> live board. */
class DiscoveryCoordinator(
    private val sources: SourceStore,
    private val fetcher: SourceFetcher,
    private val board: LiveServerBoard,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val random: Random = Random.Default,
    private val maxLinksPerSource: Int = 2000,
    private val maxSubmit: Int = 600,
    private val maxFailuresBeforeBackoff: Int = 5,
    private val retryAfterMs: Long = 30 * 60_000L
) {
    private val mutex = Mutex()
    private val mutableHealth = MutableStateFlow<Map<String, SourceHealth>>(emptyMap())
    val health: StateFlow<Map<String, SourceHealth>> = mutableHealth.asStateFlow()
    private val mutableReport = MutableStateFlow<DiscoveryReport?>(null)
    val report: StateFlow<DiscoveryReport?> = mutableReport.asStateFlow()

    suspend fun discover(): DiscoveryReport = mutex.withLock {
        val now = clock()
        val active = sources.load().filter { it.enabled && shouldTry(mutableHealth.value[it.id], now) }

        val semaphore = Semaphore(4)
        val fetched = coroutineScope {
            active.map { s -> async { semaphore.withPermit { s to fetcher.fetch(s.url) } } }.awaitAll()
        }

        val health = HashMap(mutableHealth.value)
        val rejected = HashMap<String, Int>()
        val accepted = LinkedHashMap<String, ProxyProfile>()
        var failed = 0
        var seen = 0

        for ((source, result) in fetched) {
            val previous = health[source.id] ?: SourceHealth()
            val links = result.getOrNull()?.let { SubscriptionDecoder.extractLinks(it).take(maxLinksPerSource) }
            if (links.isNullOrEmpty()) {
                failed++
                health[source.id] = previous.copy(
                    lastAttemptMs = now,
                    consecutiveFailures = previous.consecutiveFailures + 1,
                    lastErrorCode = if (links == null) errorCode(result.exceptionOrNull()) else "NO_LINKS"
                )
                continue
            }
            seen += links.size
            for (link in links) {
                when (val parsed = ShareLinkParser.parse(link)) {
                    is ParseResult.Rejected -> count(rejected, parsed.code)
                    is ParseResult.Ok -> {
                        val verdict = ConfigPolicy.evaluate(parsed.profile)
                        if (verdict.accepted) accepted.putIfAbsent(parsed.profile.dedupeKey, parsed.profile)
                        else count(rejected, verdict.code ?: "POLICY_REJECTED")
                    }
                }
            }
            health[source.id] = SourceHealth(now, now, links.size, 0, null)
        }
        mutableHealth.value = health

        // Random sample so that the head of a file is not always favoured.
        board.submit(accepted.values.toList().shuffled(random).take(maxSubmit))
        DiscoveryReport(active.size, failed, seen, accepted.size, rejected, now).also { mutableReport.value = it }
    }

    private fun shouldTry(h: SourceHealth?, now: Long): Boolean =
        h == null || h.consecutiveFailures < maxFailuresBeforeBackoff || now - h.lastAttemptMs >= retryAfterMs

    private fun count(map: HashMap<String, Int>, code: String) { map[code] = (map[code] ?: 0) + 1 }

    private fun errorCode(t: Throwable?): String {
        val message = t?.message
        // Other exception text may contain the source URL; never forward it.
        return if (message != null && message in KNOWN_FETCH_CODES) message else "FETCH_FAILED"
    }

    private companion object {
        val KNOWN_FETCH_CODES = setOf("SOURCE_NOT_HTTPS", "SOURCE_HTTP_ERROR", "SOURCE_TOO_LARGE")
    }
}
