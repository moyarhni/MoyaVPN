package com.moya.vpn.engine.nativebridge

/**
 * Official Psiphon Android architecture (Psiphon-Inc/psiphon-android):
 * PsiphonTunnel exposes a local SOCKS listener; the app's VpnManager creates its
 * own Android TUN, duplicates its fd, and starts Tun2SocksJniLoader against the
 * SOCKS and UDPGW ports. This is a separate VPN lifecycle from the Xray TUN path.
 *
 * The full upstream manager depends on additional Android app classes, JNI/NDK
 * artifacts and service callbacks. It is not safe to substitute the Psiphon
 * tunnel AAR alone or to pass Xray's TUN fd into Psiphon.
 */
object PsiphonSdkCapability {
    const val SDK_ARTIFACT = "ca.psiphon:psiphontunnel:2.0.43"
    const val OFFICIAL_ANDROID_REPO = "https://github.com/Psiphon-Inc/psiphon-android"
    const val VPN_MANAGER_SOURCE = "app/src/main/java/com/psiphon3/VpnManager.java"
    const val TUN2SOCKS_JNI_REQUIRED = true
    const val FULL_DEVICE_VPN_READY = false
    const val BLOCK_REASON = "OFFICIAL_PSIPHON_VPN_MANAGER_AND_JNI_NOT_INTEGRATED"
}
