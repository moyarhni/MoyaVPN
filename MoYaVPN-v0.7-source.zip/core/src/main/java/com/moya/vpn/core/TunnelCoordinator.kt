package com.moya.vpn.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import java.time.Instant

/**
 * Single-owner state machine for tunnel lifecycle.
 * It serializes connect/disconnect, waits for a real Established event,
 * times out stalled engines (including a stalled engine.start()), rolls back
 * partial starts, and keeps watching the engine after CONNECTED so that an
 * unexpected engine death is never reported as a live tunnel.
 */
class TunnelCoordinator(
    private val registry: EngineRegistry,
    private val tunProvider: TunDescriptorProvider,
    private val validator: ServerPreflight,
    private val connectTimeoutMs: Long = 45_000L,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
) {
    private val mutex = Mutex()
    private val mutableStatus = MutableStateFlow(TunnelStatus())
    val status: StateFlow<TunnelStatus> = mutableStatus.asStateFlow()
    private var activeEngine: TunnelEngine? = null
    private var watcher: Job? = null

    suspend fun connect(server: ServerDescriptor): Result<Unit> = mutex.withLock {
        if (mutableStatus.value.phase != TunnelPhase.IDLE && mutableStatus.value.phase != TunnelPhase.FAILED) {
            return@withLock Result.failure(IllegalStateException("Tunnel is not idle"))
        }
        val engine = registry.get(server.engine)
            ?: return@withLock fail(TunnelFailure.EngineUnavailable, "ENGINE_UNAVAILABLE")
        mutableStatus.value = TunnelStatus(TunnelPhase.VALIDATING, server.id, server.engine)

        try {
            val report = validator.validate(server)
            if (!report.accepted) return@withLock fail(TunnelFailure.InvalidConfiguration, "CONFIG_REJECTED")
            val engineCheck = engine.validate(server)
            if (!engineCheck.accepted) return@withLock fail(TunnelFailure.InvalidConfiguration, engineCheck.safeReasonCode ?: "ENGINE_VALIDATION_FAILED")

            val capabilities = engine.capabilities()
            val tunFd = if (capabilities.ownsTunInterface) {
                -1 // Engine establishes and owns its own VPN interface (Psiphon VpnManager path).
            } else {
                tunProvider.fileDescriptor()
                    ?: return@withLock fail(TunnelFailure.PermissionDenied, "TUN_NOT_ESTABLISHED")
            }
            if (!capabilities.ownsTunInterface && tunFd < 0) {
                return@withLock fail(TunnelFailure.PermissionDenied, "INVALID_TUN_DESCRIPTOR")
            }
            mutableStatus.value = TunnelStatus(TunnelPhase.PREPARING, server.id, server.engine)
            activeEngine = engine
            mutableStatus.value = TunnelStatus(TunnelPhase.CONNECTING, server.id, server.engine)

            // The timeout covers engine.start() itself: adapters may run reachability
            // probes inside start(), and a stalled start must not block forever.
            // StateFlow retains the latest event, so an immediate callback cannot be missed.
            val terminal = withTimeout(connectTimeoutMs) {
                engine.start(server, tunFd)
                engine.events.first { it is EngineEvent.Established || it is EngineEvent.Failed || it is EngineEvent.Stopped }
            }
            when (terminal) {
                EngineEvent.Established -> {
                    mutableStatus.value = TunnelStatus(TunnelPhase.CONNECTED, server.id, server.engine, Instant.now())
                    watchEngine(engine)
                    Result.success(Unit)
                }
                is EngineEvent.Failed -> {
                    runCatching { engine.stop() }
                    activeEngine = null
                    fail(TunnelFailure.EngineFailure(terminal.safeCode), terminal.safeCode)
                }
                EngineEvent.Stopped -> {
                    activeEngine = null
                    fail(TunnelFailure.EngineFailure("STOPPED_DURING_CONNECT"), "STOPPED_DURING_CONNECT")
                }
                else -> fail(TunnelFailure.InternalFailure, "UNEXPECTED_ENGINE_EVENT")
            }
        } catch (e: TimeoutCancellationException) {
            runCatching { engine.stop() }
            activeEngine = null
            fail(TunnelFailure.ConnectionTimedOut, "CONNECT_TIMEOUT")
        } catch (e: CancellationException) {
            runCatching { engine.stop() }
            activeEngine = null
            mutableStatus.value = TunnelStatus()
            throw e
        } catch (_: Throwable) {
            // Prefer the engine's own redacted failure code over a generic internal error.
            val reported = engine.events.value as? EngineEvent.Failed
            runCatching { engine.stop() }
            activeEngine = null
            if (reported != null) fail(TunnelFailure.EngineFailure(reported.safeCode), reported.safeCode)
            else fail(TunnelFailure.InternalFailure, "CONNECT_INTERNAL_ERROR")
        }
    }

    suspend fun disconnect(): Result<Unit> = mutex.withLock {
        stopWatcher()
        val engine = activeEngine
        if (engine == null) {
            mutableStatus.value = TunnelStatus()
            return@withLock Result.success(Unit)
        }
        mutableStatus.value = mutableStatus.value.copy(phase = TunnelPhase.DISCONNECTING)
        val result = runCatching { engine.stop() }
        activeEngine = null
        mutableStatus.value = TunnelStatus()
        result
    }

    /**
     * Fail-closed response to loss of the underlying network.
     * This coordinator has no verified socket-rebinding contract yet, so it must
     * not leave the UI in CONNECTING or claim that the tunnel is still protected.
     * A future engine-specific recovery API can replace this conservative stop.
     */
    suspend fun onUnderlyingNetworkLost() = mutex.withLock {
        val current = mutableStatus.value
        if (current.phase != TunnelPhase.CONNECTED && current.phase != TunnelPhase.CONNECTING) return@withLock
        stopWatcher()
        mutableStatus.value = current.copy(phase = TunnelPhase.DISCONNECTING)
        val engine = activeEngine
        val stopResult = if (engine != null) runCatching { engine.stop() } else Result.success(Unit)
        activeEngine = null
        mutableStatus.value = TunnelStatus(
            phase = TunnelPhase.FAILED,
            serverId = current.serverId,
            engine = current.engine,
            failure = TunnelFailure.NetworkUnavailable
        )
        // Keep the externally visible failure deterministic. A stop error is not
        // exposed because native exception text may contain sensitive details.
        stopResult.exceptionOrNull()?.let { /* recorded by the caller's redacted logger */ }
    }

    private fun stopWatcher() {
        watcher?.cancel()
        watcher = null
    }

    /**
     * Observes the engine after CONNECTED. If it fails or stops without a
     * disconnect() call, the status leaves CONNECTED (fail-closed, no fake "connected").
     */
    private fun watchEngine(engine: TunnelEngine) {
        stopWatcher()
        watcher = scope.launch {
            val terminal = engine.events.first { it is EngineEvent.Failed || it is EngineEvent.Stopped }
            mutex.withLock {
                val current = mutableStatus.value
                if (activeEngine !== engine || current.phase != TunnelPhase.CONNECTED) return@withLock
                val code = (terminal as? EngineEvent.Failed)?.safeCode ?: "ENGINE_STOPPED_UNEXPECTEDLY"
                runCatching { engine.stop() }
                activeEngine = null
                mutableStatus.value = TunnelStatus(
                    phase = TunnelPhase.FAILED,
                    serverId = current.serverId,
                    engine = current.engine,
                    failure = TunnelFailure.EngineFailure(code)
                )
            }
        }
    }

    private fun fail(failure: TunnelFailure, safeCode: String): Result<Unit> {
        mutableStatus.value = mutableStatus.value.copy(phase = TunnelPhase.FAILED, failure = failure)
        return Result.failure(IllegalStateException(safeCode))
    }
}

fun interface TunDescriptorProvider { fun fileDescriptor(): Int? }

/** Mutable descriptor slot shared by the Android VPN service session and coordinator. */
class MutableTunDescriptorProvider : TunDescriptorProvider {
    @Volatile private var descriptor: Int? = null

    override fun fileDescriptor(): Int? = descriptor

    fun attach(fileDescriptor: Int) {
        require(fileDescriptor >= 0) { "INVALID_TUN_DESCRIPTOR" }
        check(descriptor == null) { "TUN_DESCRIPTOR_ALREADY_ATTACHED" }
        descriptor = fileDescriptor
    }

    fun detach() { descriptor = null }
}
fun interface ServerPreflight { suspend fun validate(server: ServerDescriptor): PreflightResult }
data class PreflightResult(val accepted: Boolean, val safeCode: String? = null)
