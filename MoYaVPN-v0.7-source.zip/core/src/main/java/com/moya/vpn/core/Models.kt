package com.moya.vpn.core

import java.time.Instant

/** Engine IDs are stable storage/API values. Never persist localized display names. */
enum class EngineId { XRAY, PSIPHON }
enum class TunnelPhase { IDLE, VALIDATING, PREPARING, CONNECTING, CONNECTED, DISCONNECTING, FAILED }

data class ServerDescriptor(
    val id: String,
    val label: String,
    val engine: EngineId,
    val sourceId: String,
    /** Opaque key into encrypted storage. Raw credentials/configuration never belong here. */
    val secretRef: String
)

data class TunnelStatus(
    val phase: TunnelPhase = TunnelPhase.IDLE,
    val serverId: String? = null,
    val engine: EngineId? = null,
    val connectedAt: Instant? = null,
    val failure: TunnelFailure? = null
)

sealed interface TunnelFailure {
    data object PermissionDenied : TunnelFailure
    data object InvalidConfiguration : TunnelFailure
    data object EngineUnavailable : TunnelFailure
    data object NetworkUnavailable : TunnelFailure
    data object ConnectionTimedOut : TunnelFailure
    data object OperationInProgress : TunnelFailure
    data class EngineFailure(val safeCode: String) : TunnelFailure
    data object InternalFailure : TunnelFailure
}

sealed interface EngineEvent {
    data object Starting : EngineEvent
    data object CoreStarted : EngineEvent
    data object Established : EngineEvent
    data class Failed(val safeCode: String) : EngineEvent
    data object Stopped : EngineEvent
}

data class EngineCapabilities(
    val supportsIpv6: Boolean,
    val supportsUdp: Boolean,
    val supportsPerAppRouting: Boolean,
    /** True when the engine owns its VPN/TUN lifecycle instead of consuming the shared TUN fd. */
    val ownsTunInterface: Boolean = false
)

data class EngineValidation(val accepted: Boolean, val safeReasonCode: String? = null)
