package com.moya.vpn.discovery

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Extracts supported share links from a subscription body (plain text or Base64). */
object SubscriptionDecoder {
    private const val MAX_LINKS = 5000
    private val SCHEMES = listOf("vless://", "vmess://", "trojan://")

    fun extractLinks(body: String): List<String> {
        val trimmed = body.trim()
        val text = if (trimmed.take(256).contains("://")) {
            trimmed
        } else {
            runCatching { String(ShareLinkParser.decodeBase64Flexible(trimmed), Charsets.UTF_8) }
                .getOrNull()?.takeIf { it.contains("://") } ?: return emptyList()
        }
        return text.lineSequence()
            .map { it.trim() }
            .filter { line -> SCHEMES.any { line.startsWith(it, ignoreCase = true) } }
            .take(MAX_LINKS)
            .toList()
    }
}

fun interface SourceFetcher { suspend fun fetch(url: String): Result<String> }

/** HTTPS-only, size-capped downloader. HTTP downgrade redirects are not followed by HttpURLConnection. */
class SubscriptionFetcher(
    private val timeoutMs: Int = 15_000,
    private val maxBytes: Int = 4 * 1024 * 1024
) : SourceFetcher {
    override suspend fun fetch(url: String): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(url.startsWith("https://", ignoreCase = true)) { "SOURCE_NOT_HTTPS" }
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = timeoutMs
                conn.readTimeout = timeoutMs
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "MoYaVPN")
                check(conn.responseCode == 200) { "SOURCE_HTTP_ERROR" }
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                conn.inputStream.use { input ->
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        check(out.size() + n <= maxBytes) { "SOURCE_TOO_LARGE" }
                        out.write(buffer, 0, n)
                    }
                }
                out.toString(Charsets.UTF_8.name())
            } finally {
                conn.disconnect()
            }
        }
    }
}
