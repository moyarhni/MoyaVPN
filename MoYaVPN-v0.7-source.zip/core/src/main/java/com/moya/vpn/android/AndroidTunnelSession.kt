package com.moya.vpn.android

import com.moya.vpn.core.MutableTunDescriptorProvider
import com.moya.vpn.core.ServerDescriptor
import com.moya.vpn.core.TunnelCoordinator
import com.moya.vpn.core.TunnelPhase
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** TUN parameters are explicit so DNS, MTU and addressing are not hidden defaults. */
data class AndroidTunSettings(
    val ipv4Address: String,
    val ipv4Prefix: Int,
    val dnsServers: List<String>,
    val mtu: Int = 1500
)

/**
 * Joins the Android TUN lifetime to the engine coordinator.
 * The VPN service must already be started in the foreground and Android VPN
 * permission must already be granted before connect() is called.
 */
class AndroidTunnelSession(
    private val platform: VpnPlatform,
    private val descriptorProvider: MutableTunDescriptorProvider,
    private val coordinator: TunnelCoordinator,
    private val permissionGate: VpnPermissionGate
) {
    private val mutex = Mutex()
    private var tunAttached = false

    suspend fun connect(server: ServerDescriptor, settings: AndroidTunSettings): Result<Unit> = mutex.withLock {
        if (server.engine != com.moya.vpn.core.EngineId.XRAY) {
            return@withLock Result.failure(IllegalArgumentException("ENGINE_OWNS_TUN_USE_NATIVE_SESSION"))
        }
        if (!permissionGate.isPermissionGranted()) {
            return@withLock Result.failure(SecurityException("VPN_PERMISSION_REQUIRED"))
        }
        if (coordinator.status.value.phase != TunnelPhase.IDLE &&
            coordinator.status.value.phase != TunnelPhase.FAILED) {
            return@withLock Result.failure(IllegalStateException("TUNNEL_NOT_IDLE"))
        }
        // A previous tunnel may still be attached after a FAILED state (engine death or
        // network loss keeps the TUN open so traffic is blackholed, not leaked). Release
        // it before establishing a new one, otherwise attach() would reject the new fd.
        closeTunLocked()
        try {
            val fd = platform.establishTun(
                settings.ipv4Address,
                settings.ipv4Prefix,
                settings.dnsServers,
                settings.mtu
            )
            descriptorProvider.attach(fd)
            tunAttached = true
            val result = coordinator.connect(server)
            if (result.isFailure) closeTunLocked()
            result
        } catch (t: Throwable) {
            closeTunLocked()
            Result.failure(t)
        }
    }

    suspend fun disconnect(): Result<Unit> = mutex.withLock {
        val result = coordinator.disconnect()
        closeTunLocked()
        result
    }

    /** Called from VpnService.onRevoke/onDestroy after the engine has been stopped. */
    suspend fun onPlatformRevoked(): Result<Unit> = disconnect()

    private fun closeTunLocked() {
        if (tunAttached) {
            descriptorProvider.detach()
            platform.closeTun()
            tunAttached = false
        }
    }
}
