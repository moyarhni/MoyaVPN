package com.moya.vpn.security

import com.moya.vpn.core.ServerDescriptor

/** Security checks fail closed. A clean result is not a guarantee that a public server is trustworthy. */
enum class CheckDisposition { PASS, REVIEW, REJECT }
enum class CheckId { SIZE, PARSE, SCHEMA, DESTINATION, TLS, DNS, SIGNATURE }
data class CheckFinding(val id: CheckId, val disposition: CheckDisposition, val code: String)
data class SecurityReport(val findings: List<CheckFinding>) {
    val accepted: Boolean get() = findings.none { it.disposition != CheckDisposition.PASS }
}

fun interface ConfigSecurityPipeline { suspend fun inspect(server: ServerDescriptor): SecurityReport }

interface ConfigMaterialProvider {
    /** Returns secret material only to the selected engine; caller must clear mutable buffers. */
    suspend fun readConfig(secretRef: String): ByteArray?
}

interface PublisherSignatureVerifier {
    fun verify(manifest: ByteArray, signature: ByteArray, trustedPublicKey: ByteArray): Boolean
}

/**
 * Independent check of the *stored* artifact right before connecting (defense in depth):
 * the first outbound must use TLS or Reality and must not disable certificate verification.
 */
class StoredConfigPreflight(private val materials: ConfigMaterialProvider) : com.moya.vpn.core.ServerPreflight {
    override suspend fun validate(server: ServerDescriptor): com.moya.vpn.core.PreflightResult {
        val bytes = materials.readConfig(server.secretRef)
            ?: return com.moya.vpn.core.PreflightResult(false, "CONFIG_MISSING")
        return try {
            val root = org.json.JSONObject(String(bytes, Charsets.UTF_8))
            val stream = root.getJSONArray("outbounds").getJSONObject(0).optJSONObject("streamSettings")
                ?: return com.moya.vpn.core.PreflightResult(false, "STREAM_MISSING")
            val security = stream.optString("security")
            if (security != "tls" && security != "reality") {
                com.moya.vpn.core.PreflightResult(false, "INSECURE_TRANSPORT")
            } else if (stream.optJSONObject("tlsSettings")?.optBoolean("allowInsecure", false) == true) {
                com.moya.vpn.core.PreflightResult(false, "ALLOW_INSECURE")
            } else {
                com.moya.vpn.core.PreflightResult(true)
            }
        } catch (_: Exception) {
            com.moya.vpn.core.PreflightResult(false, "CONFIG_INVALID")
        } finally {
            bytes.fill(0)
        }
    }
}
