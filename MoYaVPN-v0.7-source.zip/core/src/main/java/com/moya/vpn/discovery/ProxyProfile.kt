package com.moya.vpn.discovery

import java.security.MessageDigest

enum class ProxyProtocol { VLESS, VMESS, TROJAN }
enum class SecurityMode { TLS, REALITY }
enum class Transport { TCP, WS, GRPC }

/**
 * Normalised, policy-checkable form of a public share link.
 * Public configs are untrusted input: the Xray config is always generated from this
 * model by [XrayOutboundBuilder], never taken verbatim from a source.
 */
data class ProxyProfile(
    val protocol: ProxyProtocol,
    val host: String,
    val port: Int,
    /** UUID (VLESS/VMess) or password (Trojan). Never logged. */
    val credential: String,
    val security: SecurityMode,
    val transport: Transport,
    val sni: String? = null,
    val fingerprint: String? = null,
    val alpn: List<String> = emptyList(),
    val flow: String? = null,
    val realityPublicKey: String? = null,
    val realityShortId: String? = null,
    val realitySpiderX: String? = null,
    val wsPath: String? = null,
    val wsHost: String? = null,
    val grpcServiceName: String? = null,
    val remark: String = ""
) {
    /** Stable de-duplication key (SHA-256). Does not expose the raw credential. */
    val dedupeKey: String by lazy {
        val raw = listOf(protocol, host.lowercase(), port, credential, security, transport, sni, wsPath, grpcServiceName)
            .joinToString("|")
        MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    /** Redacted on purpose: no host, credential or key material in logs. */
    override fun toString(): String = "ProxyProfile(protocol=$protocol, id=${dedupeKey.take(8)})"
}
