package com.moya.vpn.storage

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** App-private encrypted blob store. AES-256-GCM key material stays in Android Keystore. */
class AndroidKeystoreSecretStore(context: Context) : SecretStore {
    private val appContext = context.applicationContext
    private val directory = File(appContext.noBackupFilesDir, "moya-secrets")
    private val alias = "com.moya.vpn.secretstore.aes256gcm.v1"

    override suspend fun put(plain: ByteArray): String = withContext(Dispatchers.IO) {
        require(plain.isNotEmpty() && plain.size <= MAX_SECRET_BYTES) { "SECRET_SIZE_INVALID" }
        ensureDirectory()
        val reference = UUID.randomUUID().toString()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(plain)
        val iv = cipher.iv
        require(iv.size == GCM_IV_BYTES) { "GCM_IV_INVALID" }
        val payload = byteArrayOf(FORMAT_VERSION.toByte()) + iv + encrypted
        val target = fileFor(reference)
        val temp = File(directory, ".$reference.tmp")
        try {
            temp.writeBytes(payload)
            if (!temp.renameTo(target)) throw IllegalStateException("SECRET_COMMIT_FAILED")
        } finally {
            payload.fill(0)
            encrypted.fill(0)
            temp.delete()
        }
        reference
    }

    override suspend fun get(reference: String): ByteArray? = withContext(Dispatchers.IO) {
        val file = runCatching { fileFor(reference) }.getOrNull() ?: return@withContext null
        if (!file.isFile || file.length() !in (1L + GCM_IV_BYTES + 16L)..(MAX_SECRET_BYTES + 128L)) return@withContext null
        val payload = runCatching { file.readBytes() }.getOrNull() ?: return@withContext null
        try {
            if (payload.size < 1 + GCM_IV_BYTES + 16 || payload[0].toInt() != FORMAT_VERSION) return@withContext null
            val iv = payload.copyOfRange(1, 1 + GCM_IV_BYTES)
            val ciphertext = payload.copyOfRange(1 + GCM_IV_BYTES, payload.size)
            try {
                val cipher = Cipher.getInstance(TRANSFORMATION)
                cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(GCM_TAG_BITS, iv))
                cipher.doFinal(ciphertext)
            } finally {
                iv.fill(0)
                ciphertext.fill(0)
            }
        } catch (_: Exception) {
            null // Includes tampering, wrong key, and malformed ciphertext.
        } finally {
            payload.fill(0)
        }
    }

    override suspend fun delete(reference: String) = withContext(Dispatchers.IO) {
        runCatching { fileFor(reference).delete() }
        Unit
    }

    private fun ensureDirectory() {
        if (!directory.exists() && !directory.mkdirs()) throw IllegalStateException("SECRET_STORE_UNAVAILABLE")
        if (!directory.isDirectory) throw IllegalStateException("SECRET_STORE_UNAVAILABLE")
    }

    private fun fileFor(reference: String): File {
        require(reference.matches(Regex("[0-9a-fA-F-]{36}"))) { "SECRET_REFERENCE_INVALID" }
        val root = directory.canonicalFile
        val target = File(root, "$reference.bin").canonicalFile
        require(target.parentFile == root) { "SECRET_REFERENCE_INVALID" }
        return target
    }

    private fun getOrCreateKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (keyStore.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val FORMAT_VERSION = 1
        private const val GCM_IV_BYTES = 12
        private const val GCM_TAG_BITS = 128
        private const val MAX_SECRET_BYTES = 2 * 1024 * 1024
    }
}
