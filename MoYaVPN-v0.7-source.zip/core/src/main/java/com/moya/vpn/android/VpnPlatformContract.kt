package com.moya.vpn.android

/** Platform adapter implemented by the Android VpnService module. */
interface VpnPlatform {
    fun establishTun(ipv4Address: String, ipv4Prefix: Int, dnsServers: List<String>, mtu: Int): Int
    fun protectSocket(fileDescriptor: Int): Boolean
    fun closeTun()
    /**
     * True while this app's own sockets are excluded from the tunnel (Builder.addDisallowedApplication).
     * The native engine runs inside this process, so its upstream sockets then bypass the TUN and
     * cannot loop back into it.
     */
    val ownAppBypassesTunnel: Boolean get() = false
}

/** Called only after the user grants Android VPN permission. */
interface VpnPermissionGate { fun isPermissionGranted(): Boolean }
