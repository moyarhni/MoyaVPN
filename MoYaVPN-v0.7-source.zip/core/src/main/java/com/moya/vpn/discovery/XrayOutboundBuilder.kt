package com.moya.vpn.discovery

import org.json.JSONArray
import org.json.JSONObject

/**
 * Builds the Xray *outbound* object from a policy-checked [ProxyProfile].
 *
 * Only the outbound is produced here. The inbound/TUN part of the full config depends on the
 * exact libv2ray API of the pinned AAR and is assembled in the native bridge once that API has
 * been inspected. Certificate verification is never disabled.
 */
object XrayOutboundBuilder {
    fun build(p: ProxyProfile): String {
        val outbound = JSONObject()
        outbound.put("tag", "proxy")
        outbound.put(
            "protocol",
            when (p.protocol) {
                ProxyProtocol.VLESS -> "vless"
                ProxyProtocol.VMESS -> "vmess"
                ProxyProtocol.TROJAN -> "trojan"
            }
        )
        outbound.put("settings", settings(p))
        outbound.put("streamSettings", streamSettings(p))
        return outbound.toString()
    }

    private fun settings(p: ProxyProfile): JSONObject = when (p.protocol) {
        ProxyProtocol.VLESS -> {
            val user = JSONObject().put("id", p.credential).put("encryption", "none")
            if (!p.flow.isNullOrEmpty()) user.put("flow", p.flow)
            vnext(p, user)
        }
        ProxyProtocol.VMESS -> {
            val user = JSONObject().put("id", p.credential).put("alterId", 0).put("security", "auto")
            vnext(p, user)
        }
        ProxyProtocol.TROJAN -> {
            val server = JSONObject().put("address", p.host).put("port", p.port).put("password", p.credential)
            JSONObject().put("servers", JSONArray().put(server))
        }
    }

    private fun vnext(p: ProxyProfile, user: JSONObject): JSONObject {
        val server = JSONObject()
            .put("address", p.host)
            .put("port", p.port)
            .put("users", JSONArray().put(user))
        return JSONObject().put("vnext", JSONArray().put(server))
    }

    private fun streamSettings(p: ProxyProfile): JSONObject {
        val stream = JSONObject()
        stream.put(
            "network",
            when (p.transport) {
                Transport.TCP -> "tcp"
                Transport.WS -> "ws"
                Transport.GRPC -> "grpc"
            }
        )
        val serverName = p.sni ?: p.host
        val fingerprint = p.fingerprint ?: "chrome"
        when (p.security) {
            SecurityMode.TLS -> {
                stream.put("security", "tls")
                val tls = JSONObject()
                    .put("serverName", serverName)
                    .put("fingerprint", fingerprint)
                    .put("allowInsecure", false)
                if (p.alpn.isNotEmpty()) tls.put("alpn", JSONArray(p.alpn))
                stream.put("tlsSettings", tls)
            }
            SecurityMode.REALITY -> {
                stream.put("security", "reality")
                stream.put(
                    "realitySettings",
                    JSONObject()
                        .put("serverName", serverName)
                        .put("fingerprint", fingerprint)
                        .put("publicKey", p.realityPublicKey.orEmpty())
                        .put("shortId", p.realityShortId.orEmpty())
                        .put("spiderX", p.realitySpiderX ?: "/")
                )
            }
        }
        when (p.transport) {
            Transport.WS -> {
                val ws = JSONObject().put("path", p.wsPath ?: "/")
                if (!p.wsHost.isNullOrEmpty()) ws.put("headers", JSONObject().put("Host", p.wsHost))
                stream.put("wsSettings", ws)
            }
            Transport.GRPC -> stream.put("grpcSettings", JSONObject().put("serviceName", p.grpcServiceName.orEmpty()))
            Transport.TCP -> Unit
        }
        return stream
    }
}
