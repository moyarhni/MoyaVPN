package com.moya.vpn.engine

import com.moya.vpn.core.EngineId
import com.moya.vpn.core.TunnelEngine

/** Xray and Psiphon must remain separate implementations and config domains. */
interface XrayEngineAdapter : TunnelEngine { override val id: EngineId get() = EngineId.XRAY }
interface PsiphonEngineAdapter : TunnelEngine { override val id: EngineId get() = EngineId.PSIPHON }

/** Native SDK bridge contract. Concrete implementations are supplied by version-pinned SDK modules. */
interface XrayNativeBridge {
    /** Must be true only when native outbound sockets are demonstrably protected from VPN recursion. */
    val socketProtectionReady: Boolean get() = false
    suspend fun validateAndNormalize(configJson: String): String
    /** Returns outbound delay in milliseconds, or a negative value when the probe fails. */
    suspend fun measureOutboundDelay(configJson: String, httpsTestUrl: String): Long
    suspend fun start(configJson: String, tunFd: Int, protectSocket: (Int) -> Boolean, callback: EngineCallback)
    suspend fun stop()
}

interface PsiphonNativeBridge {
    /** True only when official Psiphon VpnManager + tun2socks + JNI are integrated and tested. */
    val fullDeviceVpnReady: Boolean get() = false
    suspend fun validateConfig(configJson: String): Boolean
    /** Starts the official Psiphon core and its VpnManager/tun2socks packet path. */
    suspend fun start(configJson: String, callback: EngineCallback)
    suspend fun stop()
}

interface EngineCallback {
    /** Native loop is active. This is not proof that the remote server is reachable. */
    fun onCoreStarted()
    /** The engine's own reachability check succeeded. */
    fun onConnected()
    fun onFailure(safeCode: String)
    fun onStopped()
}
