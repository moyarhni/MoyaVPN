package com.moya.vpn.engine

import com.moya.vpn.core.*
import com.moya.vpn.security.ConfigMaterialProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Production adapter wrapper. The platform-specific bridge must be backed by
 * the exact, verified native SDK release selected by the Android build.
 */
class XrayEngine(
    private val bridge: XrayNativeBridge,
    private val materials: ConfigMaterialProvider,
    private val protectSocket: (Int) -> Boolean,
    private val reachabilityTestUrls: List<String> = listOf(
        "https://www.cloudflare.com/cdn-cgi/trace",
        "https://www.google.com/generate_204"
    )
) : XrayEngineAdapter {
    private val lock = Mutex()
    private val mutableEvents = MutableStateFlow<EngineEvent>(EngineEvent.Stopped)
    override val events: StateFlow<EngineEvent> = mutableEvents
    private var running = false

    override fun capabilities() = EngineCapabilities(
        supportsIpv6 = true, supportsUdp = true, supportsPerAppRouting = false
    )

    override suspend fun validate(server: ServerDescriptor): EngineValidation {
        if (server.engine != EngineId.XRAY) return EngineValidation(false, "ENGINE_MISMATCH")
        if (!bridge.socketProtectionReady) return EngineValidation(false, "XRAY_SOCKET_PROTECTION_NOT_VERIFIED")
        val bytes = materials.readConfig(server.secretRef) ?: return EngineValidation(false, "CONFIG_MISSING")
        return try {
            val json = bytes.toString(Charsets.UTF_8)
            bridge.validateAndNormalize(json)
            EngineValidation(true)
        } catch (_: Throwable) {
            EngineValidation(false, "XRAY_CONFIG_INVALID")
        } finally {
            bytes.fill(0)
        }
    }

    override suspend fun start(server: ServerDescriptor, tunFileDescriptor: Int) = lock.withLock {
        check(!running) { "XRAY_ALREADY_RUNNING" }
        require(server.engine == EngineId.XRAY) { "ENGINE_MISMATCH" }
        check(bridge.socketProtectionReady) { "XRAY_SOCKET_PROTECTION_NOT_VERIFIED" }
        val bytes = materials.readConfig(server.secretRef) ?: error("CONFIG_MISSING")
        mutableEvents.value = EngineEvent.Starting
        try {
            val rawJson = bytes.toString(Charsets.UTF_8)
            val normalizedJson = bridge.validateAndNormalize(rawJson)
            bridge.start(normalizedJson, tunFileDescriptor, protectSocket, object : EngineCallback {
                override fun onCoreStarted() { mutableEvents.value = EngineEvent.CoreStarted }
                override fun onConnected() { mutableEvents.value = EngineEvent.Established }
                override fun onFailure(safeCode: String) { mutableEvents.value = EngineEvent.Failed(safeCode.take(64)) }
                override fun onStopped() { mutableEvents.value = EngineEvent.Stopped }
            })

            require(reachabilityTestUrls.isNotEmpty() && reachabilityTestUrls.size <= 5) {
                "XRAY_REACHABILITY_ENDPOINTS_INVALID"
            }
            var reachable = false
            for (url in reachabilityTestUrls) {
                try {
                    if (bridge.measureOutboundDelay(normalizedJson, url) >= 0L) {
                        reachable = true
                        break
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Throwable) {
                    // Try the next configured HTTPS probe. Do not expose native error text.
                }
            }
            val nativeFailure = mutableEvents.value as? EngineEvent.Failed
            if (nativeFailure != null) error(nativeFailure.safeCode)
            check(reachable) { "XRAY_OUTBOUND_UNREACHABLE" }
            mutableEvents.value = EngineEvent.Established
            running = true
        } catch (cancelled: CancellationException) {
            runCatching { bridge.stop() }
            mutableEvents.value = EngineEvent.Stopped
            throw cancelled
        } catch (t: Throwable) {
            runCatching { bridge.stop() }
            mutableEvents.value = EngineEvent.Failed(
                if (t.message == "XRAY_OUTBOUND_UNREACHABLE") "XRAY_OUTBOUND_UNREACHABLE" else "XRAY_START_FAILED"
            )
            throw t
        } finally {
            bytes.fill(0)
        }
    }

    /** Explicit server reachability diagnostic. This does not change tunnel state. */
    suspend fun testOutboundDelay(server: ServerDescriptor, httpsTestUrl: String): Long {
        require(server.engine == EngineId.XRAY) { "ENGINE_MISMATCH" }
        val bytes = materials.readConfig(server.secretRef) ?: error("CONFIG_MISSING")
        return try {
            bridge.measureOutboundDelay(bytes.toString(Charsets.UTF_8), httpsTestUrl)
        } finally {
            bytes.fill(0)
        }
    }

    override suspend fun stop() = lock.withLock {
        if (running) bridge.stop()
        running = false
        mutableEvents.value = EngineEvent.Stopped
    }
}

class PsiphonEngine(
    private val bridge: PsiphonNativeBridge,
    private val materials: ConfigMaterialProvider
) : PsiphonEngineAdapter {
    private val lock = Mutex()
    private val mutableEvents = MutableStateFlow<EngineEvent>(EngineEvent.Stopped)
    override val events: StateFlow<EngineEvent> = mutableEvents
    private var running = false

    override fun capabilities() = EngineCapabilities(
        supportsIpv6 = false, supportsUdp = true, supportsPerAppRouting = false,
        ownsTunInterface = true
    )

    override suspend fun validate(server: ServerDescriptor): EngineValidation {
        if (server.engine != EngineId.PSIPHON) return EngineValidation(false, "ENGINE_MISMATCH")
        if (!bridge.fullDeviceVpnReady) return EngineValidation(false, "PSIPHON_TUN_ROUTING_NOT_INTEGRATED")
        val bytes = materials.readConfig(server.secretRef) ?: return EngineValidation(false, "CONFIG_MISSING")
        return try {
            val valid = bridge.validateConfig(bytes.toString(Charsets.UTF_8))
            EngineValidation(valid, if (valid) null else "PSIPHON_CONFIG_INVALID")
        } catch (_: Throwable) {
            EngineValidation(false, "PSIPHON_CONFIG_INVALID")
        } finally {
            bytes.fill(0)
        }
    }

    override suspend fun start(server: ServerDescriptor, tunFileDescriptor: Int) = lock.withLock {
        check(!running) { "PSIPHON_ALREADY_RUNNING" }
        require(server.engine == EngineId.PSIPHON) { "ENGINE_MISMATCH" }
        check(bridge.fullDeviceVpnReady) { "PSIPHON_TUN_ROUTING_NOT_INTEGRATED" }
        val bytes = materials.readConfig(server.secretRef) ?: error("CONFIG_MISSING")
        mutableEvents.value = EngineEvent.Starting
        try {
            // Official Psiphon VpnManager creates and owns its own TUN, then routes the
            // Psiphon SOCKS listener through tun2socks. It must not consume Xray's TUN fd.
            bridge.start(bytes.toString(Charsets.UTF_8), object : EngineCallback {
                override fun onCoreStarted() { mutableEvents.value = EngineEvent.CoreStarted }
                override fun onConnected() { mutableEvents.value = EngineEvent.Established }
                override fun onFailure(safeCode: String) { mutableEvents.value = EngineEvent.Failed(safeCode.take(64)) }
                override fun onStopped() { mutableEvents.value = EngineEvent.Stopped }
            })
            running = true
        } catch (t: Throwable) {
            mutableEvents.value = EngineEvent.Failed("PSIPHON_START_FAILED")
            throw t
        } finally {
            bytes.fill(0)
        }
    }

    override suspend fun stop() = lock.withLock {
        if (running) bridge.stop()
        running = false
        mutableEvents.value = EngineEvent.Stopped
    }
}
