package com.moya.vpn.storage

/** Implement with Android Keystore + AES-GCM; never persist raw secrets in preferences/logs. */
interface SecretStore {
    suspend fun put(plain: ByteArray): String
    suspend fun get(reference: String): ByteArray?
    suspend fun delete(reference: String)
}

interface RedactedEventLogger {
    /** Accept only stable event codes and non-sensitive numeric metadata. */
    fun record(eventCode: String, value: Long? = null)
}
