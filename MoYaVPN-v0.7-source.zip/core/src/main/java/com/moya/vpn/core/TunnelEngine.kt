package com.moya.vpn.core

import kotlinx.coroutines.flow.StateFlow

/**
 * Adapter boundary. Each engine owns its native config format and lifecycle.
 * Implementations must never log raw configs, UUIDs, keys, or server URLs.
 */
interface TunnelEngine {
    val id: EngineId
    val events: StateFlow<EngineEvent>
    fun capabilities(): EngineCapabilities
    suspend fun validate(server: ServerDescriptor): EngineValidation
    /** Starts asynchronously. Completion is reported only through [events]. */
    suspend fun start(server: ServerDescriptor, tunFileDescriptor: Int)
    suspend fun stop()
}

class EngineRegistry(engines: Collection<TunnelEngine>) {
    private val enginesById = engines.associateBy { it.id }
    init { require(enginesById.size == engines.size) { "Duplicate engine ID" } }
    fun get(id: EngineId): TunnelEngine? = enginesById[id]
    fun available(): Set<EngineId> = enginesById.keys
}
