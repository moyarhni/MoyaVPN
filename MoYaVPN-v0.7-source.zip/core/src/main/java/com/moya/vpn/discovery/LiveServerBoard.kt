package com.moya.vpn.discovery

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit

data class ServerEntry(
    val id: String,
    val profile: ProxyProfile,
    /** Last successful TCP RTT, or null when unreachable / not yet measured. */
    val rttMs: Int?,
    val failCode: String?,
    /** 0 = never probed. */
    val checkedAtMs: Long,
    val consecutiveFailures: Int
)

data class BoardState(
    /** Reachable entries first (lowest RTT first), then unreachable / unmeasured. */
    val entries: List<ServerEntry> = emptyList(),
    val refreshing: Boolean = false,
    val lastRefreshMs: Long = 0L,
    /** True when a whole batch failed: probably the phone's network is down, so nothing was penalised. */
    val networkSuspect: Boolean = false
)

/**
 * Live list of candidate servers with periodically refreshed RTTs.
 * Cost control: each refresh probes only (a) the current top entries, (b) a bounded batch of
 * never-measured entries and (c) a few failed entries for retry. The loop should run only while
 * the list is visible ([start] / [stop]) to save battery and data.
 */
class LiveServerBoard(
    private val prober: LatencyProber,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val maxPool: Int = 500,
    private val topRecheck: Int = 30,
    private val newBatch: Int = 60,
    private val retryBatch: Int = 20,
    private val concurrency: Int = 12,
    private val maxConsecutiveFailures: Int = 5
) {
    private val lock = Mutex()
    private val refreshMutex = Mutex()
    private val entries = LinkedHashMap<String, ServerEntry>()
    private var refreshing = false
    private var lastRefresh = 0L
    private var suspect = false
    private var loop: Job? = null

    private val mutableState = MutableStateFlow(BoardState())
    val state: StateFlow<BoardState> = mutableState.asStateFlow()

    suspend fun submit(profiles: List<ProxyProfile>) = lock.withLock {
        for (p in profiles) {
            val key = p.dedupeKey
            if (entries.containsKey(key)) continue
            if (entries.size >= maxPool && !evictOneFailed()) break
            entries[key] = ServerEntry(key, p, null, null, 0L, 0)
        }
        publish()
    }

    fun find(id: String): ServerEntry? = mutableState.value.entries.firstOrNull { it.id == id }

    fun bestCandidates(n: Int): List<ServerEntry> =
        mutableState.value.entries.filter { it.rttMs != null }.take(n)

    suspend fun refreshOnce() = refreshMutex.withLock {
        val targets = lock.withLock {
            val values = entries.values
            val top = values.filter { it.rttMs != null }.sortedBy { it.rttMs }.take(topRecheck)
            val fresh = values.filter { it.checkedAtMs == 0L }.take(newBatch)
            val retry = values.filter { it.rttMs == null && it.checkedAtMs > 0L }.take(retryBatch)
            refreshing = true
            publish()
            (top + fresh + retry).distinctBy { it.id }
        }
        if (targets.isEmpty()) {
            lock.withLock { refreshing = false; publish() }
            return@withLock
        }

        val semaphore = Semaphore(concurrency)
        val results = try {
            coroutineScope {
                targets.map { t -> async { semaphore.withPermit { t.id to prober.probe(t.profile) } } }.awaitAll()
            }
        } catch (e: CancellationException) {
            lock.withLock { refreshing = false; publish() }
            throw e
        }

        lock.withLock {
            val now = clock()
            val anyOk = results.any { it.second.rttMs != null }
            if (!anyOk && results.size >= 5) {
                // Every probe failed: most likely our own network is down. Do not punish servers.
                suspect = true
            } else {
                suspect = false
                for ((id, r) in results) {
                    val cur = entries[id] ?: continue
                    entries[id] = if (r.rttMs != null) {
                        cur.copy(rttMs = r.rttMs, failCode = null, checkedAtMs = now, consecutiveFailures = 0)
                    } else {
                        cur.copy(rttMs = null, failCode = r.code, checkedAtMs = now,
                            consecutiveFailures = cur.consecutiveFailures + 1)
                    }
                }
                entries.values.removeAll { it.consecutiveFailures >= maxConsecutiveFailures }
            }
            refreshing = false
            lastRefresh = now
            publish()
        }
    }

    /** Starts the periodic refresh (default: every minute). Call only while the list is on screen. */
    fun start(scope: CoroutineScope, intervalMs: Long = 60_000L) {
        loop?.cancel()
        loop = scope.launch {
            while (isActive) {
                try {
                    refreshOnce()
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Throwable) {
                    // A failed round must not kill the loop; the next round retries.
                }
                delay(intervalMs)
            }
        }
    }

    fun stop() {
        loop?.cancel()
        loop = null
    }

    private fun evictOneFailed(): Boolean {
        val victim = entries.values.firstOrNull { it.rttMs == null && it.checkedAtMs > 0L } ?: return false
        entries.remove(victim.id)
        return true
    }

    /** Must be called with [lock] held. */
    private fun publish() {
        val (reachable, other) = entries.values.partition { it.rttMs != null }
        mutableState.value = BoardState(
            entries = reachable.sortedBy { it.rttMs } + other,
            refreshing = refreshing,
            lastRefreshMs = lastRefresh,
            networkSuspect = suspect
        )
    }
}
