package com.moya.vpn.discovery

enum class ConnectMode { AUTO, MANUAL }

sealed interface PickResult {
    data class Picked(val entry: ServerEntry) : PickResult
    data object NoneAvailable : PickResult
    data object NotFound : PickResult
}

/**
 * Chooses the server to connect to.
 * AUTO: walks the best RTT candidates and returns the first one that passes [verifier]
 * (a real outbound probe, e.g. the engine's delay check), because an open TCP port does not
 * prove the proxy works. MANUAL: returns the entry the user selected; the tunnel coordinator
 * still verifies it on connect.
 */
class ConnectionPlanner(
    private val board: LiveServerBoard,
    private val verifier: suspend (ProxyProfile) -> Boolean,
    private val autoCandidates: Int = 5
) {
    suspend fun pick(mode: ConnectMode, manualId: String? = null): PickResult = when (mode) {
        ConnectMode.MANUAL -> {
            val entry = manualId?.let { board.find(it) }
            if (entry == null) PickResult.NotFound else PickResult.Picked(entry)
        }
        ConnectMode.AUTO -> {
            var chosen: ServerEntry? = null
            for (candidate in board.bestCandidates(autoCandidates)) {
                if (verifier(candidate.profile)) { chosen = candidate; break }
            }
            if (chosen == null) PickResult.NoneAvailable else PickResult.Picked(chosen)
        }
    }
}
