package com.moya.vpn.discovery

import java.net.InetAddress

data class PolicyVerdict(val accepted: Boolean, val code: String? = null)

/**
 * Security policy for untrusted public configs (fail closed).
 * Passing this policy means "structurally acceptable", not "trustworthy":
 * the server operator can still observe unencrypted inner traffic.
 */
object ConfigPolicy {
    private val UUID_RE = Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
    private val HEX_RE = Regex("^[0-9a-fA-F]*$")
    private val REALITY_KEY_RE = Regex("^[A-Za-z0-9_-]{43}=?$")
    private val IPV4_RE = Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$")
    private val HOSTNAME_RE = Regex("^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$")
    private val LOCAL_SUFFIXES = listOf(".localhost", ".local", ".internal", ".lan", ".home", ".corp")

    fun evaluate(p: ProxyProfile): PolicyVerdict {
        if (p.port !in 1..65535) return reject("PORT_INVALID")
        hostProblem(p.host)?.let { return reject(it) }

        when (p.protocol) {
            ProxyProtocol.VLESS, ProxyProtocol.VMESS ->
                if (!UUID_RE.matches(p.credential)) return reject("UUID_INVALID")
            ProxyProtocol.TROJAN ->
                if (p.credential.isEmpty() || p.credential.length > 256) return reject("PASSWORD_INVALID")
        }

        val flow = p.flow.orEmpty()
        if (flow.isNotEmpty()) {
            if (flow != "xtls-rprx-vision") return reject("FLOW_UNSUPPORTED")
            if (p.protocol != ProxyProtocol.VLESS || p.transport != Transport.TCP) return reject("FLOW_INVALID_COMBINATION")
        }

        if (p.security == SecurityMode.REALITY) {
            if (p.protocol != ProxyProtocol.VLESS) return reject("REALITY_REQUIRES_VLESS")
            if (p.transport == Transport.WS) return reject("REALITY_TRANSPORT_INVALID")
            if (p.sni.isNullOrBlank()) return reject("REALITY_SNI_MISSING")
            if (p.realityPublicKey == null || !REALITY_KEY_RE.matches(p.realityPublicKey)) return reject("REALITY_KEY_INVALID")
            val sid = p.realityShortId.orEmpty()
            if (sid.length > 16 || sid.length % 2 != 0 || !HEX_RE.matches(sid)) return reject("REALITY_SHORTID_INVALID")
        }
        return PolicyVerdict(true)
    }

    private fun reject(code: String) = PolicyVerdict(false, code)

    /** Returns a reject code, or null when the host is acceptable. */
    private fun hostProblem(rawHost: String): String? {
        val h = rawHost.lowercase()
        if (h.isEmpty() || h.length > 253) return "HOST_INVALID"
        if (h == "localhost" || LOCAL_SUFFIXES.any { h.endsWith(it) }) return "HOST_BLOCKED"

        IPV4_RE.matchEntire(h)?.let { m ->
            val octets = m.groupValues.drop(1).map { it.toInt() }
            if (octets.any { it > 255 }) return "HOST_INVALID"
            return if (isBlockedIpv4(octets)) "HOST_BLOCKED" else null
        }
        if (h.contains(':')) {
            // IPv6 literal: parsing a literal never triggers a DNS lookup.
            val addr = try { InetAddress.getByName(h) } catch (_: Exception) { return "HOST_INVALID" }
            val bytes = addr.address
            if (bytes.size == 4) return if (isBlockedIpv4(bytes.map { it.toInt() and 0xFF })) "HOST_BLOCKED" else null
            val ula = (bytes[0].toInt() and 0xFE) == 0xFC
            return if (addr.isLoopbackAddress || addr.isAnyLocalAddress || addr.isLinkLocalAddress ||
                addr.isSiteLocalAddress || addr.isMulticastAddress || ula) "HOST_BLOCKED" else null
        }
        return if (HOSTNAME_RE.matches(h)) null else "HOST_INVALID"
    }

    private fun isBlockedIpv4(o: List<Int>): Boolean {
        val a = o[0]
        val b = o[1]
        return a == 0 || a == 10 || a == 127 ||
            (a == 100 && b in 64..127) || (a == 169 && b == 254) ||
            (a == 172 && b in 16..31) || (a == 192 && b == 168) || a >= 224
    }
}
