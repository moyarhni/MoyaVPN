package com.moya.vpn.discovery

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

/** Lets probe sockets bypass the VPN tunnel (VpnService.protect) so they measure the real network. */
fun interface SocketProtector { fun protect(socket: Socket): Boolean }

data class ProbeResult(val rttMs: Int?, val code: String? = null)

interface LatencyProber { suspend fun probe(profile: ProxyProfile): ProbeResult }

/**
 * Cheap reachability probe: TCP connect time to server:port.
 * This is NOT proof that the proxy works (a dead Xray behind an open port still answers), so the
 * connection planner confirms the top candidates with a real outbound probe before connecting.
 * Host-name DNS resolution uses the system resolver and is not covered by [SocketProtector].
 */
class TcpLatencyProber(
    private val protector: SocketProtector = SocketProtector { true },
    private val timeoutMs: Int = 4_000
) : LatencyProber {
    override suspend fun probe(profile: ProxyProfile): ProbeResult = withContext(Dispatchers.IO) {
        val socket = Socket()
        try {
            if (!protector.protect(socket)) return@withContext ProbeResult(null, "PROTECT_FAILED")
            val address = InetSocketAddress(profile.host, profile.port)
            if (address.isUnresolved) return@withContext ProbeResult(null, "DNS_FAILED")
            val start = System.nanoTime()
            socket.connect(address, timeoutMs)
            val ms = ((System.nanoTime() - start) / 1_000_000L).toInt().coerceAtLeast(1)
            ProbeResult(ms)
        } catch (_: SocketTimeoutException) {
            ProbeResult(null, "TIMEOUT")
        } catch (_: IOException) {
            ProbeResult(null, "CONNECT_FAILED")
        } finally {
            try { socket.close() } catch (_: IOException) { }
        }
    }
}
