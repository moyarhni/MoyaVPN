package com.moya.vpn.engine

import org.json.JSONArray
import org.json.JSONObject

/**
 * Wraps a policy-checked outbound into a complete Xray config with a TUN inbound.
 * On Android the TUN fd is supplied by the VpnService via libv2ray's StartLoop(config, tunFd);
 * Xray must not create or route the interface itself, so no routing-table options are set.
 * Logging is disabled because Xray log lines can contain endpoints.
 */
object XrayConfigAssembler {
    fun assembleTunConfig(outboundJson: String, mtu: Int = 1500): String {
        require(mtu in 1280..9000) { "INVALID_MTU" }
        val tunInbound = JSONObject()
            .put("tag", "tun-in")
            .put("port", 0)
            .put("protocol", "tun")
            .put("settings", JSONObject().put("name", "xray0").put("mtu", mtu))
        return JSONObject()
            .put("log", JSONObject().put("loglevel", "none"))
            .put("inbounds", JSONArray().put(tunInbound))
            .put("outbounds", JSONArray().put(JSONObject(outboundJson)))
            .toString()
    }
}
