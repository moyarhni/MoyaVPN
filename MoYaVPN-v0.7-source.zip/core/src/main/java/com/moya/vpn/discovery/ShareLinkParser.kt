package com.moya.vpn.discovery

import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder
import java.util.Base64

sealed interface ParseResult {
    data class Ok(val profile: ProxyProfile) : ParseResult
    /** [code] is a stable, non-sensitive reason code. */
    data class Rejected(val code: String) : ParseResult
}

/**
 * Parses vless://, trojan:// and vmess:// share links. Anything that is not
 * TLS/Reality-protected is rejected here, before any network activity.
 */
object ShareLinkParser {
    private const val MAX_LINK_LENGTH = 4096
    private const val MAX_REMARK = 64

    fun parse(raw: String): ParseResult {
        val line = raw.trim()
        if (line.isEmpty() || line.length > MAX_LINK_LENGTH) return ParseResult.Rejected("LINK_SIZE")
        return try {
            when {
                line.startsWith("vless://", ignoreCase = true) -> parseUriStyle(line, ProxyProtocol.VLESS)
                line.startsWith("trojan://", ignoreCase = true) -> parseUriStyle(line, ProxyProtocol.TROJAN)
                line.startsWith("vmess://", ignoreCase = true) -> parseVmess(line)
                else -> ParseResult.Rejected("PROTOCOL_UNSUPPORTED")
            }
        } catch (_: Exception) {
            ParseResult.Rejected("LINK_MALFORMED")
        }
    }

    private fun parseUriStyle(line: String, protocol: ProxyProtocol): ParseResult {
        val hash = line.indexOf('#')
        val remark = if (hash >= 0) URLDecoder.decode(line.substring(hash + 1), "UTF-8").take(MAX_REMARK) else ""
        val uri = URI(if (hash >= 0) line.substring(0, hash) else line)
        val host = uri.host?.removeSurrounding("[", "]")?.takeIf { it.isNotEmpty() }
            ?: return ParseResult.Rejected("HOST_MISSING")
        val credential = uri.userInfo?.takeIf { it.isNotEmpty() } ?: return ParseResult.Rejected("CREDENTIAL_MISSING")
        if (uri.port == -1) return ParseResult.Rejected("PORT_MISSING")
        return build(protocol, host, uri.port, credential, parseQuery(uri.rawQuery), remark)
    }

    private fun parseVmess(line: String): ParseResult {
        val json = JSONObject(String(decodeBase64Flexible(line.substring("vmess://".length)), Charsets.UTF_8))
        if (json.optString("type", "none").ifEmpty { "none" }.lowercase() != "none") {
            return ParseResult.Rejected("HEADER_OBFS_UNSUPPORTED")
        }
        val q = HashMap<String, String>()
        q["type"] = json.optString("net", "tcp").ifEmpty { "tcp" }
        q["security"] = json.optString("tls", "")
        q["sni"] = json.optString("sni", "")
        q["alpn"] = json.optString("alpn", "")
        q["fp"] = json.optString("fp", "")
        q["path"] = json.optString("path", "")
        q["host"] = json.optString("host", "")
        return build(
            ProxyProtocol.VMESS,
            json.optString("add", "").trim(),
            json.optInt("port", -1),
            json.optString("id", "").trim(),
            q,
            json.optString("ps", "").take(MAX_REMARK)
        )
    }

    /** [q] keys must be lower-case. */
    private fun build(
        protocol: ProxyProtocol, host: String, port: Int, credential: String,
        q: Map<String, String>, remark: String
    ): ParseResult {
        if (host.isEmpty()) return ParseResult.Rejected("HOST_MISSING")
        if (credential.isEmpty()) return ParseResult.Rejected("CREDENTIAL_MISSING")
        if (port !in 1..65535) return ParseResult.Rejected("PORT_INVALID")
        if (truthy(q["allowinsecure"]) || truthy(q["insecure"])) return ParseResult.Rejected("ALLOW_INSECURE")
        if ((q["headertype"] ?: "none").lowercase().ifEmpty { "none" } != "none") {
            return ParseResult.Rejected("HEADER_OBFS_UNSUPPORTED")
        }
        val transport = when ((q["type"] ?: "tcp").lowercase().ifEmpty { "tcp" }) {
            "tcp", "raw" -> Transport.TCP
            "ws" -> Transport.WS
            "grpc" -> Transport.GRPC
            else -> return ParseResult.Rejected("TRANSPORT_UNSUPPORTED")
        }
        val securityRaw = (q["security"] ?: "").lowercase().ifEmpty { if (protocol == ProxyProtocol.TROJAN) "tls" else "" }
        val security = when (securityRaw) {
            "tls" -> SecurityMode.TLS
            "reality" -> SecurityMode.REALITY
            else -> return ParseResult.Rejected("INSECURE_TRANSPORT")
        }
        if (protocol == ProxyProtocol.VLESS && (q["encryption"] ?: "none").lowercase().ifEmpty { "none" } != "none") {
            return ParseResult.Rejected("VLESS_ENCRYPTION_UNSUPPORTED")
        }
        return ParseResult.Ok(
            ProxyProfile(
                protocol = protocol,
                host = host,
                port = port,
                credential = credential,
                security = security,
                transport = transport,
                sni = q["sni"]?.ifEmpty { null },
                fingerprint = q["fp"]?.ifEmpty { null },
                alpn = (q["alpn"] ?: "").split(',').map { it.trim() }.filter { it.isNotEmpty() },
                flow = q["flow"]?.ifEmpty { null },
                realityPublicKey = q["pbk"]?.ifEmpty { null },
                realityShortId = q["sid"]?.ifEmpty { null },
                realitySpiderX = q["spx"]?.ifEmpty { null },
                wsPath = if (transport == Transport.WS) (q["path"]?.ifEmpty { null } ?: "/") else null,
                wsHost = q["host"]?.ifEmpty { null },
                grpcServiceName = if (transport == Transport.GRPC) (q["servicename"] ?: q["path"])?.ifEmpty { null } else null,
                remark = remark
            )
        )
    }

    private fun truthy(v: String?): Boolean = v != null && (v == "1" || v.equals("true", ignoreCase = true))

    private fun parseQuery(raw: String?): Map<String, String> {
        if (raw.isNullOrEmpty()) return emptyMap()
        val out = LinkedHashMap<String, String>()
        for (part in raw.split('&')) {
            if (part.isEmpty()) continue
            val i = part.indexOf('=')
            val key = if (i < 0) part else part.substring(0, i)
            val value = if (i < 0) "" else part.substring(i + 1)
            out[URLDecoder.decode(key, "UTF-8").lowercase()] = URLDecoder.decode(value, "UTF-8")
        }
        return out
    }

    /** Accepts standard or URL-safe Base64, with or without padding and whitespace. */
    internal fun decodeBase64Flexible(input: String): ByteArray {
        val cleaned = input.filterNot { it.isWhitespace() }.replace('-', '+').replace('_', '/').trimEnd('=')
        val padded = cleaned + "=".repeat((4 - cleaned.length % 4) % 4)
        return Base64.getDecoder().decode(padded)
    }
}
