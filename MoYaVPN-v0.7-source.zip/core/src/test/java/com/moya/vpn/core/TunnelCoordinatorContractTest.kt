package com.moya.vpn.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue

class TunnelCoordinatorContractTest {
    private class FakeEngine : TunnelEngine {
        override val id = EngineId.XRAY
        override val events = MutableStateFlow<EngineEvent>(EngineEvent.Starting)
        var stopped = false
        override fun capabilities() = EngineCapabilities(true, true, false)
        override suspend fun validate(server: ServerDescriptor) = EngineValidation(true)
        override suspend fun start(server: ServerDescriptor, tunFileDescriptor: Int) { events.value = EngineEvent.Established }
        override suspend fun stop() { stopped = true; events.value = EngineEvent.Stopped }
    }

    @Test fun waitsForEstablishedAndDisconnects() = runBlocking {
        val engine = FakeEngine()
        val coordinator = TunnelCoordinator(EngineRegistry(listOf(engine)), TunDescriptorProvider { 42 },
            ServerPreflight { PreflightResult(true) })
        val server = ServerDescriptor("id", "test", EngineId.XRAY, "test", "secret-ref")
        assertTrue(coordinator.connect(server).isSuccess)
        assertEquals(TunnelPhase.CONNECTED, coordinator.status.value.phase)
        assertTrue(coordinator.disconnect().isSuccess)
        assertTrue(engine.stopped)
        assertEquals(TunnelPhase.IDLE, coordinator.status.value.phase)
    }
    @Test fun underlyingNetworkLossStopsEngineAndFailsClosed() = runBlocking {
        val engine = FakeEngine()
        val coordinator = TunnelCoordinator(
            EngineRegistry(listOf(engine)), TunDescriptorProvider { 42 },
            ServerPreflight { PreflightResult(true) }
        )
        val server = ServerDescriptor("id-network", "test", EngineId.XRAY, "test", "secret-ref")
        assertTrue(coordinator.connect(server).isSuccess)
        coordinator.onUnderlyingNetworkLost()
        assertTrue(engine.stopped)
        assertEquals(TunnelPhase.FAILED, coordinator.status.value.phase)
        assertEquals(TunnelFailure.NetworkUnavailable, coordinator.status.value.failure)
        assertTrue(coordinator.disconnect().isSuccess)
        assertEquals(TunnelPhase.IDLE, coordinator.status.value.phase)
    }

    @Test fun engineOwnedTunDoesNotRequireSharedDescriptor() = runBlocking {
        val engine = object : TunnelEngine {
            override val id = EngineId.PSIPHON
            override val events = MutableStateFlow<EngineEvent>(EngineEvent.Stopped)
            override fun capabilities() = EngineCapabilities(false, true, false, ownsTunInterface = true)
            override suspend fun validate(server: ServerDescriptor) = EngineValidation(true)
            override suspend fun start(server: ServerDescriptor, tunFileDescriptor: Int) {
                assertEquals(-1, tunFileDescriptor)
                events.value = EngineEvent.Established
            }
            override suspend fun stop() { events.value = EngineEvent.Stopped }
        }
        val coordinator = TunnelCoordinator(
            EngineRegistry(listOf(engine)), TunDescriptorProvider { null }, ServerPreflight { PreflightResult(true) }
        )
        val server = ServerDescriptor("ps", "Psiphon", EngineId.PSIPHON, "source", "secret-ref")
        assertTrue(coordinator.connect(server).isSuccess)
        assertEquals(TunnelPhase.CONNECTED, coordinator.status.value.phase)
    }

}
