package com.moya.vpn.discovery

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Base64

class DiscoveryParsingTest {
    private val uuid = "11111111-2222-3333-4444-555555555555"
    private val pbk = "A".repeat(43)

    private fun ok(raw: String): ProxyProfile {
        val r = ShareLinkParser.parse(raw)
        assertTrue("expected Ok but was $r", r is ParseResult.Ok)
        return (r as ParseResult.Ok).profile
    }

    private fun rejected(raw: String): String {
        val r = ShareLinkParser.parse(raw)
        assertTrue("expected Rejected but was $r", r is ParseResult.Rejected)
        return (r as ParseResult.Rejected).code
    }

    private val realityLink = "vless://$uuid@example.com:443?type=tcp&security=reality&sni=www.microsoft.com" +
        "&fp=chrome&pbk=$pbk&sid=abcd1234&flow=xtls-rprx-vision#my%20node"

    @Test fun parsesVlessReality() {
        val p = ok(realityLink)
        assertEquals(ProxyProtocol.VLESS, p.protocol)
        assertEquals(SecurityMode.REALITY, p.security)
        assertEquals("example.com", p.host)
        assertEquals(443, p.port)
        assertEquals("xtls-rprx-vision", p.flow)
        assertEquals("my node", p.remark)
        assertTrue(ConfigPolicy.evaluate(p).accepted)
    }

    @Test fun parsesTrojanWithEncodedPassword() {
        val p = ok("trojan://pass%40word@example.org:443?sni=example.org#t")
        assertEquals("pass@word", p.credential)
        assertEquals(SecurityMode.TLS, p.security)
    }

    @Test fun parsesVmessWebSocketTls() {
        val json = """{"v":"2","ps":"x","add":"vm.example.com","port":"443","id":"$uuid","aid":"0",
            "net":"ws","type":"none","host":"vm.example.com","path":"/ws","tls":"tls","sni":"vm.example.com"}"""
        val link = "vmess://" + Base64.getEncoder().encodeToString(json.toByteArray())
        val p = ok(link)
        assertEquals(ProxyProtocol.VMESS, p.protocol)
        assertEquals(Transport.WS, p.transport)
        assertEquals("/ws", p.wsPath)
        assertTrue(ConfigPolicy.evaluate(p).accepted)
    }

    @Test fun rejectsLinksWithoutTlsOrReality() {
        assertEquals("INSECURE_TRANSPORT", rejected("vless://$uuid@example.com:443?type=tcp#n"))
        assertEquals("INSECURE_TRANSPORT", rejected("vless://$uuid@example.com:443?security=none"))
    }

    @Test fun rejectsAllowInsecure() {
        assertEquals("ALLOW_INSECURE", rejected("vless://$uuid@example.com:443?security=tls&allowInsecure=1"))
    }

    @Test fun rejectsUnsupportedSchemeAndGarbage() {
        assertEquals("PROTOCOL_UNSUPPORTED", rejected("ss://YWVzLTEyOC1nY206cGFzcw@example.com:8388"))
        assertEquals("LINK_MALFORMED", rejected("vmess://not-base64-json!!"))
        assertEquals("LINK_SIZE", rejected(""))
    }

    @Test fun policyBlocksPrivateAndLocalHosts() {
        for (host in listOf("192.168.1.10", "10.0.0.5", "127.0.0.1", "172.16.0.1", "169.254.1.1", "localhost", "router.local")) {
            val p = ok("vless://$uuid@$host:443?security=tls")
            val v = ConfigPolicy.evaluate(p)
            assertFalse("$host should be blocked", v.accepted)
            assertEquals("HOST_BLOCKED", v.code)
        }
        val ipv6 = ok("vless://$uuid@[::1]:443?security=tls")
        assertEquals("HOST_BLOCKED", ConfigPolicy.evaluate(ipv6).code)
    }

    @Test fun policyAcceptsPublicIp() {
        assertTrue(ConfigPolicy.evaluate(ok("vless://$uuid@93.184.216.34:443?security=tls&sni=example.com")).accepted)
    }

    @Test fun policyChecksRealityParameters() {
        val badKey = ok("vless://$uuid@example.com:443?security=reality&sni=a.com&pbk=short&sid=ab")
        assertEquals("REALITY_KEY_INVALID", ConfigPolicy.evaluate(badKey).code)
        val badSid = ok("vless://$uuid@example.com:443?security=reality&sni=a.com&pbk=$pbk&sid=abc")
        assertEquals("REALITY_SHORTID_INVALID", ConfigPolicy.evaluate(badSid).code)
        val noSni = ok("vless://$uuid@example.com:443?security=reality&pbk=$pbk&sid=ab")
        assertEquals("REALITY_SNI_MISSING", ConfigPolicy.evaluate(noSni).code)
    }

    @Test fun policyRejectsBadUuid() {
        val p = ok("vless://not-a-uuid@example.com:443?security=tls")
        assertEquals("UUID_INVALID", ConfigPolicy.evaluate(p).code)
    }

    @Test fun builderProducesRealityOutbound() {
        val json = JSONObject(XrayOutboundBuilder.build(ok(realityLink)))
        assertEquals("vless", json.getString("protocol"))
        val stream = json.getJSONObject("streamSettings")
        assertEquals("reality", stream.getString("security"))
        assertEquals(pbk, stream.getJSONObject("realitySettings").getString("publicKey"))
        val user = json.getJSONObject("settings").getJSONArray("vnext").getJSONObject(0)
            .getJSONArray("users").getJSONObject(0)
        assertEquals("xtls-rprx-vision", user.getString("flow"))
    }

    @Test fun builderNeverDisablesCertificateVerification() {
        val p = ok("trojan://secret@example.org:443?sni=example.org")
        val tls = JSONObject(XrayOutboundBuilder.build(p)).getJSONObject("streamSettings").getJSONObject("tlsSettings")
        assertFalse(tls.getBoolean("allowInsecure"))
    }

    @Test fun profileToStringIsRedacted() {
        val p = ok(realityLink)
        val s = p.toString()
        assertFalse(s.contains("example.com"))
        assertFalse(s.contains(uuid))
    }

    @Test fun decoderHandlesPlainAndBase64() {
        val plain = "vless://$uuid@example.com:443?security=tls\nss://abc\n\ntrojan://p@example.org:443"
        assertEquals(2, SubscriptionDecoder.extractLinks(plain).size)
        val b64 = Base64.getEncoder().encodeToString(plain.toByteArray())
        assertEquals(2, SubscriptionDecoder.extractLinks(b64).size)
        assertTrue(SubscriptionDecoder.extractLinks("<html>not a subscription</html>").isEmpty())
    }
}
