package com.moya.vpn.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MutableTunDescriptorProviderTest {
    @Test fun attachAndDetachDescriptor() {
        val provider = MutableTunDescriptorProvider()
        assertNull(provider.fileDescriptor())
        provider.attach(17)
        assertEquals(17, provider.fileDescriptor())
        provider.detach()
        assertNull(provider.fileDescriptor())
    }

    @Test(expected = IllegalArgumentException::class)
    fun rejectsNegativeDescriptor() {
        MutableTunDescriptorProvider().attach(-1)
    }
}
