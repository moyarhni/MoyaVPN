package com.moya.vpn.discovery

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LiveServerBoardTest {
    private class FakeProber(val rtt: MutableMap<String, Int?>) : LatencyProber {
        override suspend fun probe(profile: ProxyProfile): ProbeResult {
            val v = rtt[profile.host]
            return if (v == null) ProbeResult(null, "TIMEOUT") else ProbeResult(v)
        }
    }

    private fun profile(host: String) = ProxyProfile(
        protocol = ProxyProtocol.VLESS, host = host, port = 443,
        credential = "11111111-2222-3333-4444-555555555555",
        security = SecurityMode.TLS, transport = Transport.TCP
    )

    @Test fun ranksReachableByRttAndKeepsOthersLast() = runBlocking {
        val prober = FakeProber(mutableMapOf("a.example" to 80, "b.example" to 20, "c.example" to 50, "dead.example" to null))
        val board = LiveServerBoard(prober)
        board.submit(prober.rtt.keys.map { profile(it) })
        board.refreshOnce()
        val hosts = board.state.value.entries.map { it.profile.host }
        assertEquals(listOf("b.example", "c.example", "a.example", "dead.example"), hosts)
        assertEquals("b.example", board.bestCandidates(1).single().profile.host)
    }

    @Test fun rttsUpdateOnNextRefresh() = runBlocking {
        val prober = FakeProber(mutableMapOf("a.example" to 80, "b.example" to 20))
        val board = LiveServerBoard(prober)
        board.submit(listOf(profile("a.example"), profile("b.example")))
        board.refreshOnce()
        prober.rtt["a.example"] = 5
        board.refreshOnce()
        assertEquals("a.example", board.state.value.entries.first().profile.host)
    }

    @Test fun deadServerIsRemovedAfterRepeatedFailures() = runBlocking {
        val prober = FakeProber(mutableMapOf("ok.example" to 30, "dead.example" to null))
        val board = LiveServerBoard(prober, maxConsecutiveFailures = 5)
        board.submit(prober.rtt.keys.map { profile(it) })
        repeat(4) { board.refreshOnce() }
        assertEquals(2, board.state.value.entries.size)
        board.refreshOnce()
        assertEquals(listOf("ok.example"), board.state.value.entries.map { it.profile.host })
    }

    @Test fun totalProbeFailureIsTreatedAsLocalNetworkProblem() = runBlocking {
        val hosts = (1..6).map { "h$it.example" }
        val prober = FakeProber(hosts.associateWith { null as Int? }.toMutableMap())
        val board = LiveServerBoard(prober, maxConsecutiveFailures = 2)
        board.submit(hosts.map { profile(it) })
        repeat(5) { board.refreshOnce() }
        assertEquals(6, board.state.value.entries.size)
        assertTrue(board.state.value.networkSuspect)
    }

    @Test fun poolIsCappedAndDeduplicated() = runBlocking {
        val prober = FakeProber(mutableMapOf())
        val board = LiveServerBoard(prober, maxPool = 3)
        board.submit((1..5).map { profile("n$it.example") })
        assertEquals(3, board.state.value.entries.size)
        board.submit(listOf(profile("n1.example")))
        assertEquals(3, board.state.value.entries.size)
    }

    @Test fun autoModePicksFirstVerifiedCandidate() = runBlocking {
        val prober = FakeProber(mutableMapOf("fast.example" to 10, "mid.example" to 40, "slow.example" to 90))
        val board = LiveServerBoard(prober)
        board.submit(prober.rtt.keys.map { profile(it) })
        board.refreshOnce()
        val planner = ConnectionPlanner(board, verifier = { it.host != "fast.example" })
        val result = planner.pick(ConnectMode.AUTO)
        assertEquals("mid.example", (result as PickResult.Picked).entry.profile.host)
    }

    @Test fun autoModeReportsNoneWhenNothingVerifies() = runBlocking {
        val prober = FakeProber(mutableMapOf("a.example" to 10))
        val board = LiveServerBoard(prober)
        board.submit(listOf(profile("a.example")))
        board.refreshOnce()
        assertEquals(PickResult.NoneAvailable, ConnectionPlanner(board, verifier = { false }).pick(ConnectMode.AUTO))
    }

    @Test fun manualModeReturnsSelectedEntry() = runBlocking {
        val prober = FakeProber(mutableMapOf("a.example" to 10, "b.example" to 20))
        val board = LiveServerBoard(prober)
        board.submit(prober.rtt.keys.map { profile(it) })
        board.refreshOnce()
        val target = board.state.value.entries.last()
        val planner = ConnectionPlanner(board, verifier = { false })
        assertEquals(target, (planner.pick(ConnectMode.MANUAL, target.id) as PickResult.Picked).entry)
        assertEquals(PickResult.NotFound, planner.pick(ConnectMode.MANUAL, "missing"))
    }
}
