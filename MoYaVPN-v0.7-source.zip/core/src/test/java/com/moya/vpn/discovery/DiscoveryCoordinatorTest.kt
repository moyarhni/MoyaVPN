package com.moya.vpn.discovery

import com.moya.vpn.core.ServerDescriptor
import com.moya.vpn.core.EngineId
import com.moya.vpn.engine.XrayConfigAssembler
import com.moya.vpn.security.ConfigMaterialProvider
import com.moya.vpn.security.StoredConfigPreflight
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DiscoveryCoordinatorTest {
    private val uuid = "11111111-2222-3333-4444-555555555555"
    private fun tls(host: String) = "vless://$uuid@$host:443?security=tls&sni=$host"

    private class FakeFetcher(val bodies: MutableMap<String, Result<String>>) : SourceFetcher {
        override suspend fun fetch(url: String): Result<String> =
            bodies[url] ?: Result.failure(IllegalStateException("x"))
    }

    private class AlwaysUp : LatencyProber {
        override suspend fun probe(profile: ProxyProfile) = ProbeResult(10)
    }

    private fun setup(bodies: MutableMap<String, Result<String>>, clock: () -> Long = { 0L }):
        Triple<DiscoveryCoordinator, LiveServerBoard, FakeFetcher> {
        val board = LiveServerBoard(AlwaysUp())
        val fetcher = FakeFetcher(bodies)
        val sources = InMemorySourceStore(listOf(SourceConfig("a", "https://a.example/sub"), SourceConfig("b", "https://b.example/sub")))
        return Triple(DiscoveryCoordinator(sources, fetcher, board, clock), board, fetcher)
    }

    @Test fun acceptsValidLinksAndReportsRejectionsByCode() = runBlocking {
        val bodyA = listOf(tls("one.example"), tls("two.example"), "vless://$uuid@three.example:443?security=none",
            "vless://$uuid@192.168.0.9:443?security=tls").joinToString("\n")
        val bodyB = listOf(tls("two.example"), tls("four.example")).joinToString("\n") // two.example duplicated
        val (coordinator, board, _) = setup(mutableMapOf("https://a.example/sub" to Result.success(bodyA), "https://b.example/sub" to Result.success(bodyB)))
        val report = coordinator.discover()
        assertEquals(2, report.sourcesTried)
        assertEquals(0, report.sourcesFailed)
        assertEquals(3, report.accepted) // one, two, four
        assertEquals(1, report.rejected["INSECURE_TRANSPORT"])
        assertEquals(1, report.rejected["HOST_BLOCKED"])
        assertEquals(3, board.state.value.entries.size)
    }

    @Test fun failingAndEmptySourcesAreRecordedWithoutLeakingErrorText() = runBlocking {
        val (coordinator, _, _) = setup(mutableMapOf("https://a.example/sub" to Result.success("<html>blocked</html>")))
        val report = coordinator.discover()
        assertEquals(2, report.sourcesFailed)
        assertEquals("NO_LINKS", coordinator.health.value["a"]?.lastErrorCode)
        assertEquals("FETCH_FAILED", coordinator.health.value["b"]?.lastErrorCode)
    }

    @Test fun deadSourceIsBackedOffThenRetried() = runBlocking {
        var now = 0L
        val (coordinator, _, _) = setup(mutableMapOf("https://a.example/sub" to Result.success(tls("ok.example"))), { now })
        repeat(5) { coordinator.discover() } // source b fails 5 times
        assertEquals(1, coordinator.discover().sourcesTried) // b skipped
        now += 31 * 60_000L
        assertEquals(2, coordinator.discover().sourcesTried) // b retried after back-off
    }

    @Test fun assemblerBuildsTunConfigWithoutLogging() {
        val profile = (ShareLinkParser.parse(tls("host.example")) as ParseResult.Ok).profile
        val json = JSONObject(XrayConfigAssembler.assembleTunConfig(XrayOutboundBuilder.build(profile), 1400))
        val inbound = json.getJSONArray("inbounds").getJSONObject(0)
        assertEquals("tun", inbound.getString("protocol"))
        assertEquals(1400, inbound.getJSONObject("settings").getInt("mtu"))
        assertEquals("proxy", json.getJSONArray("outbounds").getJSONObject(0).getString("tag"))
        assertEquals("none", json.getJSONObject("log").getString("loglevel"))
    }

    private class FakeMaterials(val configs: Map<String, String>) : ConfigMaterialProvider {
        override suspend fun readConfig(secretRef: String) = configs[secretRef]?.toByteArray()
    }

    private val server = ServerDescriptor("id", "t", EngineId.XRAY, "src", "ref")

    @Test fun preflightAcceptsGeneratedConfigAndRejectsTampering() = runBlocking {
        val profile = (ShareLinkParser.parse(tls("host.example")) as ParseResult.Ok).profile
        val good = XrayConfigAssembler.assembleTunConfig(XrayOutboundBuilder.build(profile))
        assertTrue(StoredConfigPreflight(FakeMaterials(mapOf("ref" to good))).validate(server).accepted)

        val insecure = good.replace("\"allowInsecure\":false", "\"allowInsecure\":true")
        assertNotNull(insecure)
        assertEquals("ALLOW_INSECURE", StoredConfigPreflight(FakeMaterials(mapOf("ref" to insecure))).validate(server).safeCode)

        val plain = good.replace("\"security\":\"tls\"", "\"security\":\"none\"")
        assertEquals("INSECURE_TRANSPORT", StoredConfigPreflight(FakeMaterials(mapOf("ref" to plain))).validate(server).safeCode)

        assertFalse(StoredConfigPreflight(FakeMaterials(emptyMap())).validate(server).accepted)
        assertEquals("CONFIG_INVALID", StoredConfigPreflight(FakeMaterials(mapOf("ref" to "not json"))).validate(server).safeCode)
    }
}
