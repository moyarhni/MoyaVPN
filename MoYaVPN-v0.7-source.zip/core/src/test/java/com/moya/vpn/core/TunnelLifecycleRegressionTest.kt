package com.moya.vpn.core

import com.moya.vpn.android.AndroidTunSettings
import com.moya.vpn.android.AndroidTunnelSession
import com.moya.vpn.android.VpnPermissionGate
import com.moya.vpn.android.VpnPlatform
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TunnelLifecycleRegressionTest {

    private open class ScriptedEngine : TunnelEngine {
        override val id = EngineId.XRAY
        override val events = MutableStateFlow<EngineEvent>(EngineEvent.Stopped)
        var stopCalls = 0
        override fun capabilities() = EngineCapabilities(true, true, false)
        override suspend fun validate(server: ServerDescriptor) = EngineValidation(true)
        override suspend fun start(server: ServerDescriptor, tunFileDescriptor: Int) {
            events.value = EngineEvent.Established
        }
        override suspend fun stop() { stopCalls++; events.value = EngineEvent.Stopped }
    }

    private val server = ServerDescriptor("s", "test", EngineId.XRAY, "src", "ref")

    private fun coordinator(engine: TunnelEngine, timeoutMs: Long = 45_000L) = TunnelCoordinator(
        EngineRegistry(listOf(engine)), TunDescriptorProvider { 7 },
        ServerPreflight { PreflightResult(true) }, timeoutMs
    )

    @Test fun engineDeathAfterConnectLeavesConnectedState() = runBlocking {
        val engine = ScriptedEngine()
        val c = coordinator(engine)
        assertTrue(c.connect(server).isSuccess)
        assertEquals(TunnelPhase.CONNECTED, c.status.value.phase)

        engine.events.value = EngineEvent.Failed("NATIVE_CRASH")

        val failed = withTimeout(5_000) { c.status.first { it.phase != TunnelPhase.CONNECTED } }
        assertEquals(TunnelPhase.FAILED, failed.phase)
        assertEquals(TunnelFailure.EngineFailure("NATIVE_CRASH"), failed.failure)
        assertTrue(engine.stopCalls >= 1)
    }

    @Test fun unexpectedEngineStopLeavesConnectedState() = runBlocking {
        val engine = ScriptedEngine()
        val c = coordinator(engine)
        assertTrue(c.connect(server).isSuccess)
        engine.events.value = EngineEvent.Stopped
        val failed = withTimeout(5_000) { c.status.first { it.phase != TunnelPhase.CONNECTED } }
        assertEquals(TunnelPhase.FAILED, failed.phase)
        assertEquals(TunnelFailure.EngineFailure("ENGINE_STOPPED_UNEXPECTEDLY"), failed.failure)
    }

    @Test fun intentionalDisconnectIsNotReportedAsFailure() = runBlocking {
        val engine = ScriptedEngine()
        val c = coordinator(engine)
        assertTrue(c.connect(server).isSuccess)
        assertTrue(c.disconnect().isSuccess)
        delay(200) // give a (wrongly) surviving watcher time to act
        assertEquals(TunnelPhase.IDLE, c.status.value.phase)
        assertEquals(null, c.status.value.failure)
    }

    @Test fun stalledEngineStartTimesOut() = runBlocking {
        val engine = object : ScriptedEngine() {
            override suspend fun start(server: ServerDescriptor, tunFileDescriptor: Int) {
                events.value = EngineEvent.Starting
                delay(60_000)
            }
        }
        val c = coordinator(engine, timeoutMs = 300L)
        assertTrue(c.connect(server).isFailure)
        assertEquals(TunnelPhase.FAILED, c.status.value.phase)
        assertEquals(TunnelFailure.ConnectionTimedOut, c.status.value.failure)
        assertTrue(engine.stopCalls >= 1)
    }

    @Test fun engineStartExceptionKeepsRedactedEngineCode() = runBlocking {
        val engine = object : ScriptedEngine() {
            override suspend fun start(server: ServerDescriptor, tunFileDescriptor: Int) {
                events.value = EngineEvent.Failed("XRAY_OUTBOUND_UNREACHABLE")
                throw IllegalStateException("XRAY_OUTBOUND_UNREACHABLE")
            }
        }
        val c = coordinator(engine)
        assertTrue(c.connect(server).isFailure)
        assertEquals(TunnelFailure.EngineFailure("XRAY_OUTBOUND_UNREACHABLE"), c.status.value.failure)
    }

    @Test fun sessionCanReconnectAfterFailedState() = runBlocking {
        class Platform : VpnPlatform {
            var established = 0
            var closed = 0
            override fun establishTun(ipv4Address: String, ipv4Prefix: Int, dnsServers: List<String>, mtu: Int): Int {
                established++; return 55
            }
            override fun protectSocket(fileDescriptor: Int) = true
            override fun closeTun() { closed++ }
        }
        val engine = object : ScriptedEngine() {
            override suspend fun start(server: ServerDescriptor, tunFileDescriptor: Int) {
                assertEquals(55, tunFileDescriptor)
                events.value = EngineEvent.Established
            }
        }
        val provider = MutableTunDescriptorProvider()
        val platform = Platform()
        val c = TunnelCoordinator(EngineRegistry(listOf(engine)), provider, ServerPreflight { PreflightResult(true) })
        val session = AndroidTunnelSession(platform, provider, c, object : VpnPermissionGate {
            override fun isPermissionGranted() = true
        })
        val settings = AndroidTunSettings("10.0.0.2", 32, listOf("1.1.1.1"))

        assertTrue(session.connect(server, settings).isSuccess)
        engine.events.value = EngineEvent.Failed("NATIVE_CRASH")
        withTimeout(5_000) { c.status.first { it.phase == TunnelPhase.FAILED } }

        // Before the fix the stale descriptor made the second connect fail.
        assertTrue(session.connect(server, settings).isSuccess)
        assertEquals(TunnelPhase.CONNECTED, c.status.value.phase)
        assertEquals(2, platform.established)
    }
}
