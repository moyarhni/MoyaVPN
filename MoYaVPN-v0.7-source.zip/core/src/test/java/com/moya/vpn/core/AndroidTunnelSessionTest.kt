package com.moya.vpn.core

import com.moya.vpn.android.AndroidTunSettings
import com.moya.vpn.android.AndroidTunnelSession
import com.moya.vpn.android.VpnPermissionGate
import com.moya.vpn.android.VpnPlatform
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AndroidTunnelSessionTest {
    private class FakePlatform : VpnPlatform {
        var closed = false
        override fun establishTun(ipv4Address: String, ipv4Prefix: Int, dnsServers: List<String>, mtu: Int) = 55
        override fun protectSocket(fileDescriptor: Int) = true
        override fun closeTun() { closed = true }
    }

    private class FakeEngine : TunnelEngine {
        override val id = EngineId.XRAY
        override val events = MutableStateFlow<EngineEvent>(EngineEvent.Stopped)
        override fun capabilities() = EngineCapabilities(true, true, false)
        override suspend fun validate(server: ServerDescriptor) = EngineValidation(true)
        override suspend fun start(server: ServerDescriptor, tunFileDescriptor: Int) {
            assertEquals(55, tunFileDescriptor)
            events.value = EngineEvent.Established
        }
        override suspend fun stop() { events.value = EngineEvent.Stopped }
    }

    @Test fun connectAndDisconnectOwnsTunLifetime() = runBlocking {
        val provider = MutableTunDescriptorProvider()
        val platform = FakePlatform()
        val coordinator = TunnelCoordinator(
            EngineRegistry(listOf(FakeEngine())), provider, ServerPreflight { PreflightResult(true) }
        )
        val session = AndroidTunnelSession(platform, provider, coordinator, object : VpnPermissionGate {
            override fun isPermissionGranted() = true
        })
        val server = ServerDescriptor("x", "test", EngineId.XRAY, "source", "secret")
        assertTrue(session.connect(server, AndroidTunSettings("10.0.0.2", 32, listOf("1.1.1.1"))).isSuccess)
        assertEquals(TunnelPhase.CONNECTED, coordinator.status.value.phase)
        assertTrue(session.disconnect().isSuccess)
        assertTrue(platform.closed)
        assertFalse(provider.fileDescriptor() != null)
    }
}
