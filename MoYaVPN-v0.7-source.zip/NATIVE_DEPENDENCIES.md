# Native engine dependency review (2026-11-19)

## Xray Android library
- Upstream: https://github.com/2dust/AndroidLibXrayLite
- Latest release observed during review: `v26.11.9` (published 2026-11-10).
- Release asset: `libv2ray.aar` (60,437,926 bytes).
- Upstream release SHA-256: `cdfef146218233a31a8b52c8b1016557730d3b63fc121d4c84cacea50e669155`.
- Release page: https://github.com/2dust/AndroidLibXrayLite/releases/tag/v26.11.9
- The corresponding v2rayNG code calls `CoreController.startLoop(config, tunFd)` and `stopLoop()`. We must implement against the exact exported interface in the selected AAR, not guess method signatures.

## Psiphon Android library
- Upstream: https://github.com/Psiphon-Labs/psiphon-tunnel-core-Android-library
- Latest release observed during review: `v2.0.43` (published 2026-11-17).
- Upstream integration instructions publish `ca.psiphon:psiphontunnel` through the raw GitHub Maven repository; the library README documents the versioned Maven dependency and source build.
- Core source: https://github.com/Psiphon-Labs/psiphon-tunnel-core
- License: GPL-3.0. Review distribution obligations before bundling or shipping.

## Important integration distinction
The Psiphon library's `PsiphonTunnel` API can start the tunnel core and expose local SOCKS/HTTP proxy callbacks. The official full-device Android client also contains a VPN service and tun2socks integration. A local proxy alone is not equivalent to a device-wide VPN. MoYa must integrate the packet-tunnel path and protect upstream sockets correctly.

## Release gate
Before enabling either engine in a release build:
1. Download the exact pinned artifact from the official release channel.
2. Verify the SHA-256 (where published) and inspect the artifact/API surface.
3. Confirm supported ABIs and minimum Android API.
4. Run a device-level connect/disconnect test and packet/DNS leak tests.
5. Record license notices and source-offer obligations in the app distribution.

## v0.4 API note
The upstream v2rayNG `CoreNativeManager` calls `Libv2ray.measureOutboundDelay(config, testUrl)` for outbound connection-delay testing. MoYa exposes this call and requires a successful HTTPS probe before its Xray engine reports `Established`. This check is a reachability test only; it is not a security or trust assessment.

## v0.5 implementation notes

### Xray socket protection gate
The current `Libv2rayXrayNativeBridge` does not claim socket-protection support. `XrayNativeBridge.socketProtectionReady` defaults to `false`, and `XrayEngine` refuses to validate/start until an implementation proves how every native outbound socket is protected from being routed back into the VPN TUN. Do not flip this flag merely to enable the engine.

### Psiphon packet path
The official Android implementation is not a simple adapter around `PsiphonTunnel.startTunneling()`. The upstream `com.psiphon3.VpnManager`:
- creates the VPN interface through a registered `VpnService.Builder` provider;
- owns a `ParcelFileDescriptor` for that interface;
- duplicates the descriptor before passing it to tun2socks;
- routes the local Psiphon SOCKS port and UDPGW endpoint through `Tun2SocksJniLoader`;
- stops tun2socks before closing the original descriptor.

Upstream files inspected:
- `app/src/main/java/com/psiphon3/VpnManager.java`
- `app/src/main/java/com/psiphon3/psiphonlibrary/TunnelManager.java`

The inspected `VpnManager` invocation passes `null` for its IPv6 tun2socks parameter, so that exact upstream path is IPv4-only. A future MoYa Psiphon module must include the matching JNI/native artifacts and preserve this lifecycle. It must not share Xray's TUN descriptor.
