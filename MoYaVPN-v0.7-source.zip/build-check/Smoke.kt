import com.moya.vpn.core.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking

private class Fake : TunnelEngine {
  override val id = EngineId.XRAY
  override val events = MutableStateFlow<EngineEvent>(EngineEvent.Starting)
  var stopped = false
  override fun capabilities() = EngineCapabilities(true,true,false)
  override suspend fun validate(server: ServerDescriptor) = EngineValidation(true)
  override suspend fun start(server: ServerDescriptor, tunFileDescriptor: Int) { events.value = EngineEvent.Established }
  override suspend fun stop() { stopped = true; events.value = EngineEvent.Stopped }
}
fun main() = runBlocking {
 val engine=Fake()
 val coordinator=TunnelCoordinator(EngineRegistry(listOf(engine)), TunDescriptorProvider { 99 }, ServerPreflight { PreflightResult(true) })
 val server=ServerDescriptor("s1","test",EngineId.XRAY,"test","secret")
 check(coordinator.connect(server).isSuccess)
 check(coordinator.status.value.phase == TunnelPhase.CONNECTED)
 check(coordinator.disconnect().isSuccess)
 check(engine.stopped && coordinator.status.value.phase == TunnelPhase.IDLE)
 println("SMOKE_TEST_OK")
}
