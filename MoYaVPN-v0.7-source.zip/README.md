# MoYaVPN (v0.7, work in progress)

Android VPN app built on the MoYaVPN core. Modules:

- `:core` — pure Kotlin/Android library: tunnel coordinator, VpnService, encrypted secret store,
  discovery (share-link parser, TLS/Reality policy, live RTT board, planner), Xray config builders.
- `:app` — Compose UI (Persian/English, RTL), wiring, native bridge to the pinned `libv2ray` AAR.

## Build
Requirements: JDK 17, Android SDK 35, Gradle 8.9.

1. Download the pinned AAR into `app/libs/libv2ray.aar` (release `v26.11.9` of
   `2dust/AndroidLibXrayLite`) and check it: `sha256sum -c app/libs/libv2ray.aar.sha256`
   (run from the repository root). The hash was copied from the project's earlier review notes;
   compare it with the upstream release page before trusting it.
2. `gradle :core:testDebugUnitTest :app:assembleDebug`
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

GitHub Actions (`.github/workflows/android.yml`) does the same and uploads the debug APK.

## Release signing
Never commit a keystore. Provide it through the environment only:
`MOYA_KEYSTORE_PATH`, `MOYA_KEYSTORE_PASSWORD`, `MOYA_KEY_ALIAS`, `MOYA_KEY_PASSWORD`.
In CI, store the keystore as base64 in the secret `MOYA_KEYSTORE_B64` plus the three password/alias
secrets; without them the release step is skipped.

## Security properties (and limits)
- Public configs are untrusted: only `vless`/`vmess`/`trojan` with TLS or Reality are accepted,
  certificate verification is never disabled, and the Xray config is generated from a fixed template.
- Generated configs are stored encrypted (Android Keystore, AES-GCM) and re-checked before connect.
- Logging is redacted; Xray logging is off.
- The app excludes itself from the VPN so Xray's own sockets cannot loop. As a consequence, the app's
  own traffic (list refresh, probes) uses the underlying network, not the tunnel.
- Free public servers can observe or alter unencrypted traffic. This app cannot prevent that.

## Known limitations
- Not yet compiled or run on a device by the author of this change set; first CI run will show errors.
- No automatic reconnect after network change (fails closed, user reconnects).
- OpenVPN/vpngate engine, Psiphon, per-app routing, persisted source list: not implemented.
- Default source URLs are unverified starting points and can disappear.
- AndroidLibXrayLite is LGPL-3.0: license notices and library-replacement terms must be handled
  before distribution.
