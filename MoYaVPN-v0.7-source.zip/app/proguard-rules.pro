# gomobile-generated JNI bindings are looked up by name from native code.
-keep class go.** { *; }
-keep class libv2ray.** { *; }
-dontwarn go.**
-dontwarn libv2ray.**
