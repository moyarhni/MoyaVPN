package com.moya.vpn.app

import android.app.Application

class MoYaApp : Application() {
    /** Lazy so that a native-library problem can never crash the process at startup. */
    val container: AppContainer by lazy { AppContainer(this) }
}
