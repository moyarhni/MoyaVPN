package com.moya.vpn.app

import android.Manifest
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) vm.connect()
    }
    // The foreground-service notification still works if this is denied; the user just cannot see it.
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        requestVpnPermissionThenConnect()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val state by vm.ui.collectAsState()
            MainScreen(
                state = state,
                onConnect = ::onConnectClicked,
                onDisconnect = vm::disconnect,
                onRefresh = vm::refresh,
                onMode = vm::setMode,
                onSelect = vm::select
            )
        }
    }

    override fun onStart() { super.onStart(); vm.setVisible(true) }
    override fun onStop() { vm.setVisible(false); super.onStop() }

    private fun onConnectClicked() {
        val needsNotificationPermission = Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needsNotificationPermission) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        else requestVpnPermissionThenConnect()
    }

    private fun requestVpnPermissionThenConnect() {
        val intent = VpnService.prepare(this)
        if (intent == null) vm.connect() else vpnPermission.launch(intent)
    }
}
