package com.moya.vpn.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.moya.vpn.core.TunnelStatus
import com.moya.vpn.discovery.BoardState
import com.moya.vpn.discovery.ConnectMode
import com.moya.vpn.discovery.DiscoveryReport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val tunnel: TunnelStatus = TunnelStatus(),
    val board: BoardState = BoardState(),
    val report: DiscoveryReport? = null,
    val mode: ConnectMode = ConnectMode.AUTO,
    val selectedId: String? = null,
    val busy: Boolean = false,
    val discovering: Boolean = false,
    /** Stable error code, or null. Localized by the UI. */
    val errorCode: String? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as MoYaApp).container

    private data class Local(
        val mode: ConnectMode = ConnectMode.AUTO,
        val selectedId: String? = null,
        val busy: Boolean = false,
        val discovering: Boolean = false,
        val errorCode: String? = null
    )

    private val local = MutableStateFlow(Local())

    val ui: StateFlow<UiState> = combine(
        container.coordinator.status, container.board.state, container.discovery.report, local
    ) { tunnel, board, report, l ->
        UiState(
            tunnel = tunnel, board = board, report = report, mode = l.mode, selectedId = l.selectedId,
            busy = l.busy, discovering = l.discovering,
            errorCode = l.errorCode ?: AppContainer.errorCodeOf(tunnel.failure)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UiState())

    fun setMode(mode: ConnectMode) = local.update { it.copy(mode = mode) }
    fun select(id: String) = local.update { it.copy(selectedId = id, mode = ConnectMode.MANUAL) }

    /** The one-minute RTT refresh runs only while the screen is visible (battery and data). */
    fun setVisible(visible: Boolean) {
        if (visible) container.board.start(viewModelScope) else container.board.stop()
    }

    fun refresh() {
        if (local.value.discovering) return
        viewModelScope.launch {
            local.update { it.copy(discovering = true, errorCode = null) }
            try {
                container.discovery.discover()
                container.board.refreshOnce()
            } finally {
                local.update { it.copy(discovering = false) }
            }
        }
    }

    fun connect() {
        if (local.value.busy) return
        viewModelScope.launch {
            local.update { it.copy(busy = true, errorCode = null) }
            val result = container.connect(local.value.mode, local.value.selectedId)
            local.update { it.copy(busy = false, errorCode = result.exceptionOrNull()?.message) }
        }
    }

    fun disconnect() {
        viewModelScope.launch {
            local.update { it.copy(busy = true) }
            container.disconnect()
            local.update { it.copy(busy = false, errorCode = null) }
        }
    }
}
