package com.moya.vpn.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.moya.vpn.core.TunnelPhase
import com.moya.vpn.discovery.ConnectMode
import com.moya.vpn.discovery.ServerEntry

@Composable
fun MainScreen(
    state: UiState,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onRefresh: () -> Unit,
    onMode: (ConnectMode) -> Unit,
    onSelect: (String) -> Unit
) {
    val active = state.tunnel.phase in ACTIVE_PHASES
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Column(
                Modifier.safeDrawingPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatusCard(state)
                Button(
                    onClick = if (active) onDisconnect else onConnect,
                    enabled = active || !state.busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(if (active) R.string.disconnect else R.string.connect)) }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeButton(R.string.mode_auto, state.mode == ConnectMode.AUTO) { onMode(ConnectMode.AUTO) }
                    ModeButton(R.string.mode_manual, state.mode == ConnectMode.MANUAL) { onMode(ConnectMode.MANUAL) }
                }

                OutlinedButton(onClick = onRefresh, enabled = !state.discovering, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(if (state.discovering) R.string.refreshing else R.string.refresh))
                }

                Text(stringResource(R.string.free_warning), style = MaterialTheme.typography.bodySmall)
                if (state.board.networkSuspect) {
                    Text(stringResource(R.string.network_suspect), color = MaterialTheme.colorScheme.error)
                }

                Text(stringResource(R.string.servers), style = MaterialTheme.typography.titleSmall)
                if (state.board.entries.isEmpty()) {
                    Text(stringResource(R.string.empty_list))
                }
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(state.board.entries, key = { it.id }) { entry ->
                        ServerRow(entry, selected = entry.id == state.selectedId) { onSelect(entry.id) }
                    }
                }
                Diagnostics(state)
            }
        }
    }
}

private val ACTIVE_PHASES = setOf(
    TunnelPhase.VALIDATING, TunnelPhase.PREPARING, TunnelPhase.CONNECTING, TunnelPhase.CONNECTED
)

@Composable
private fun ModeButton(label: Int, selected: Boolean, onClick: () -> Unit) {
    if (selected) Button(onClick = onClick) { Text(stringResource(label)) }
    else OutlinedButton(onClick = onClick) { Text(stringResource(label)) }
}

@Composable
private fun StatusCard(state: UiState) {
    val phaseText = when (state.tunnel.phase) {
        TunnelPhase.IDLE -> R.string.status_idle
        TunnelPhase.VALIDATING, TunnelPhase.PREPARING, TunnelPhase.CONNECTING -> R.string.status_working
        TunnelPhase.CONNECTED -> R.string.status_connected
        TunnelPhase.DISCONNECTING -> R.string.status_disconnecting
        TunnelPhase.FAILED -> R.string.status_failed
    }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(stringResource(phaseText), style = MaterialTheme.typography.headlineSmall)
            val code = state.errorCode
            if (code != null) {
                Text(stringResource(errorMessage(code)), color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

private fun errorMessage(code: String): Int = when (code) {
    "NO_VERIFIED_SERVER" -> R.string.err_no_verified_server
    "SERVER_NOT_SELECTED" -> R.string.err_server_not_selected
    "PERMISSION" -> R.string.err_permission
    "TIMEOUT" -> R.string.err_timeout
    "NETWORK" -> R.string.err_network
    "CONFIG" -> R.string.err_config
    "ENGINE_UNAVAILABLE" -> R.string.err_engine_unavailable
    "ENGINE" -> R.string.err_engine
    "SERVICE_UNAVAILABLE" -> R.string.err_service
    "BUSY" -> R.string.err_busy
    else -> R.string.err_unknown
}

@Composable
private fun ServerRow(entry: ServerEntry, selected: Boolean, onClick: () -> Unit) {
    val rtt = entry.rttMs // property of another module: copy before use
    val colors = if (selected) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    else CardDefaults.cardColors()
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = colors) {
        Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("#${entry.id.take(4)} · ${entry.profile.protocol.name} · ${entry.profile.security.name}")
            Text(if (rtt != null) stringResource(R.string.ping_ms, rtt) else stringResource(R.string.not_reachable))
        }
    }
}

@Composable
private fun Diagnostics(state: UiState) {
    val report = state.report ?: return
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(stringResource(R.string.diag_title), style = MaterialTheme.typography.titleSmall)
        Text(
            stringResource(R.string.diag_summary, report.sourcesTried, report.sourcesFailed, report.linksSeen, report.accepted),
            style = MaterialTheme.typography.bodySmall
        )
        if (report.rejected.isNotEmpty()) {
            val top = report.rejected.entries.sortedByDescending { it.value }.take(4).joinToString { "${it.key}=${it.value}" }
            Text(stringResource(R.string.diag_rejected, top), style = MaterialTheme.typography.bodySmall)
        }
    }
}
