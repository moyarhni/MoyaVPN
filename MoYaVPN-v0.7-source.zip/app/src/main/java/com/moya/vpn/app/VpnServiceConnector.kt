package com.moya.vpn.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import com.moya.vpn.android.MoYaVpnService
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/** Starts the foreground VPN service and binds to it so the core can drive the TUN. */
class VpnServiceConnector(context: Context) {
    private val appContext = context.applicationContext
    @Volatile private var service: MoYaVpnService? = null
    private var connection: ServiceConnection? = null

    suspend fun ensureBound(): MoYaVpnService {
        service?.let { return it }
        return suspendCancellableCoroutine { cont ->
            val conn = object : ServiceConnection {
                override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                    val bound = (binder as MoYaVpnService.LocalBinder).service()
                    service = bound
                    if (cont.isActive) cont.resume(bound)
                }

                override fun onServiceDisconnected(name: ComponentName) { service = null }
            }
            connection = conn
            appContext.startForegroundService(
                Intent(appContext, MoYaVpnService::class.java).setAction(MoYaVpnService.ACTION_START)
            )
            val bindOk = appContext.bindService(Intent(appContext, MoYaVpnService::class.java), conn, Context.BIND_AUTO_CREATE)
            if (!bindOk) cont.resumeWith(Result.failure(IllegalStateException("SERVICE_BIND_FAILED")))
            cont.invokeOnCancellation { runCatching { appContext.unbindService(conn) } }
        }
    }

    fun stop() {
        connection?.let { runCatching { appContext.unbindService(it) } }
        connection = null
        service = null
        runCatching {
            appContext.startService(Intent(appContext, MoYaVpnService::class.java).setAction(MoYaVpnService.ACTION_STOP))
        }
    }
}
