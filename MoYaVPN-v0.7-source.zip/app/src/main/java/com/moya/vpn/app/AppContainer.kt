package com.moya.vpn.app

import android.app.Application
import android.net.ConnectivityManager
import android.net.Network
import com.moya.vpn.android.AndroidTunSettings
import com.moya.vpn.android.AndroidTunnelSession
import com.moya.vpn.android.AndroidVpnPermissionGate
import com.moya.vpn.android.AndroidVpnPlatform
import com.moya.vpn.core.EngineId
import com.moya.vpn.core.EngineRegistry
import com.moya.vpn.core.MutableTunDescriptorProvider
import com.moya.vpn.core.ServerDescriptor
import com.moya.vpn.core.TunnelCoordinator
import com.moya.vpn.core.TunnelFailure
import com.moya.vpn.discovery.ConnectMode
import com.moya.vpn.discovery.ConnectionPlanner
import com.moya.vpn.discovery.DiscoveryCoordinator
import com.moya.vpn.discovery.InMemorySourceStore
import com.moya.vpn.discovery.LiveServerBoard
import com.moya.vpn.discovery.PickResult
import com.moya.vpn.discovery.ProxyProfile
import com.moya.vpn.discovery.SubscriptionFetcher
import com.moya.vpn.discovery.TcpLatencyProber
import com.moya.vpn.discovery.XrayOutboundBuilder
import com.moya.vpn.engine.XrayConfigAssembler
import com.moya.vpn.engine.XrayEngine
import com.moya.vpn.engine.nativebridge.Libv2rayXrayNativeBridge
import com.moya.vpn.security.StoredConfigPreflight
import com.moya.vpn.storage.AndroidKeystoreSecretStore
import com.moya.vpn.storage.ProfileMaterials
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.UUID

/** Manual wiring of all components (no DI framework needed at this size). */
class AppContainer(private val app: Application) {
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val secretStore = AndroidKeystoreSecretStore(app)
    private val materials = ProfileMaterials(secretStore)
    private val connector = VpnServiceConnector(app)
    private val connectMutex = Mutex()

    @Volatile private var platform: AndroidVpnPlatform? = null
    private var session: AndroidTunnelSession? = null
    private var sessionPlatform: AndroidVpnPlatform? = null
    private var currentSecretRef: String? = null

    private val bridge = Libv2rayXrayNativeBridge(
        context = app,
        assetPath = File(app.filesDir, "xray").apply { mkdirs() }.absolutePath,
        deviceId = deviceId(),
        ownAppExcludedFromTunnel = { platform?.ownAppBypassesTunnel == true }
    )
    private val descriptorProvider = MutableTunDescriptorProvider()

    val coordinator = TunnelCoordinator(
        EngineRegistry(listOf(XrayEngine(bridge, materials, protectSocket = { fd -> platform?.protectSocket(fd) ?: false }))),
        descriptorProvider,
        StoredConfigPreflight(materials)
    )
    val board = LiveServerBoard(TcpLatencyProber())
    val discovery = DiscoveryCoordinator(InMemorySourceStore(), SubscriptionFetcher(), board)
    private val planner = ConnectionPlanner(board, ::verifyProfile)

    init { registerNetworkWatcher() }

    /** Real outbound probe through a throw-away Xray instance on the underlying network. */
    private suspend fun verifyProfile(profile: ProxyProfile): Boolean = try {
        val config = XrayConfigAssembler.assembleTunConfig(XrayOutboundBuilder.build(profile))
        bridge.measureOutboundDelay(config, PROBE_URL) >= 0L
    } catch (_: Exception) {
        false
    }

    /** Failure value is a stable code (see [errorCodeOf]), never a message with endpoints. */
    suspend fun connect(mode: ConnectMode, manualId: String?): Result<Unit> = connectMutex.withLock {
        val entry = when (val pick = planner.pick(mode, manualId)) {
            is PickResult.Picked -> pick.entry
            PickResult.NoneAvailable -> return Result.failure(IllegalStateException("NO_VERIFIED_SERVER"))
            PickResult.NotFound -> return Result.failure(IllegalStateException("SERVER_NOT_SELECTED"))
        }
        val service = try {
            connector.ensureBound()
        } catch (_: Exception) {
            return Result.failure(IllegalStateException("SERVICE_UNAVAILABLE"))
        }
        val currentPlatform = AndroidVpnPlatform(service)
        platform = currentPlatform
        service.setRevokedListener { appScope.launch { session?.onPlatformRevoked(); cleanupSecret() } }

        val activeSession = if (session != null && sessionPlatform === currentPlatform) session!! else {
            descriptorProvider.detach()
            AndroidTunnelSession(currentPlatform, descriptorProvider, coordinator, AndroidVpnPermissionGate(app))
                .also { session = it; sessionPlatform = currentPlatform }
        }

        val secretRef = materials.store(entry.profile)
        val descriptor = ServerDescriptor(entry.id, "server-${entry.id.take(6)}", EngineId.XRAY, "public", secretRef)
        val result = activeSession.connect(descriptor, TUN_SETTINGS)
        if (result.isSuccess) {
            currentSecretRef = secretRef
            Result.success(Unit)
        } else {
            materials.remove(secretRef)
            val code = errorCodeOf(coordinator.status.value.failure) ?: "UNKNOWN"
            connector.stop()
            Result.failure(IllegalStateException(code))
        }
    }

    suspend fun disconnect() = connectMutex.withLock {
        session?.disconnect()
        cleanupSecret()
        connector.stop()
    }

    private suspend fun cleanupSecret() {
        currentSecretRef?.let { materials.remove(it) }
        currentSecretRef = null
    }

    /** Fail closed when the underlying network disappears (see TunnelCoordinator). */
    private fun registerNetworkWatcher() {
        val cm = app.getSystemService(ConnectivityManager::class.java) ?: return
        cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
            override fun onLost(network: Network) {
                appScope.launch { coordinator.onUnderlyingNetworkLost() }
            }
        })
    }

    private fun deviceId(): String {
        val prefs = app.getSharedPreferences("moya_internal", 0)
        return prefs.getString("device_key", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("device_key", it).apply()
        }
    }

    companion object {
        private const val PROBE_URL = "https://www.google.com/generate_204"
        private val TUN_SETTINGS = AndroidTunSettings("10.77.0.2", 32, listOf("1.1.1.1", "8.8.8.8"))

        /** Maps a failure to a stable code the UI turns into a localized message. */
        fun errorCodeOf(failure: TunnelFailure?): String? = when (failure) {
            null -> null
            TunnelFailure.PermissionDenied -> "PERMISSION"
            TunnelFailure.ConnectionTimedOut -> "TIMEOUT"
            TunnelFailure.NetworkUnavailable -> "NETWORK"
            TunnelFailure.InvalidConfiguration -> "CONFIG"
            TunnelFailure.EngineUnavailable -> "ENGINE_UNAVAILABLE"
            TunnelFailure.OperationInProgress -> "BUSY"
            is TunnelFailure.EngineFailure -> "ENGINE"
            TunnelFailure.InternalFailure -> "UNKNOWN"
        }
    }
}
