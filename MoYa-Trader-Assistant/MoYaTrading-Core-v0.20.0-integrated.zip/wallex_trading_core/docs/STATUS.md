# MoYaTrading Core v0.20.0

## Completed in this increment
- Risk circuit state is written in the same database transaction as a realized losing paper trade.
- Paper entry checks both wallet-local and central persistent circuit state.
- Open positions remain closable after the entry circuit is paused.
- Portfolio endpoint exposes the paper wallet and open-position inventory.
- Risk status endpoint exposes entry and close permissions.
- Market collection loop isolates unexpected cycle failures and uses bounded exponential backoff.
- Service and capability version identifiers updated to 0.20.0.

## Still not operational
- No live exchange order adapter or private Wallex account access.
- No live trading or withdrawal capability.
- TLS termination, production secrets management, deployment supervision, and external monitoring must be configured at deployment.
- Paper ledger SHORT positions are a simplified simulation and do not model exchange margin, funding, or liquidation.

## Verification
Run from this directory:

```bash
PYTHONPATH=. pytest -q
python -m compileall -q app
```
