"""Persistent entry circuit breaker. Closing positions remains permitted."""
from datetime import datetime, timezone
from sqlalchemy import Integer, String, DateTime
from sqlalchemy.orm import Mapped, mapped_column, Session
from .db import Base, SessionLocal

class RiskCircuitState(Base):
    __tablename__ = "risk_circuit_state"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    entries_paused: Mapped[bool] = mapped_column(default=False)
    reason: Mapped[str | None] = mapped_column(String(80), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

def pause_entries_in_session(db: Session, reason: str = "first_realized_loss") -> dict:
    row = db.get(RiskCircuitState, 1)
    if row is None:
        row = RiskCircuitState(id=1)
    row.entries_paused = True
    row.reason = reason[:80]
    row.updated_at = datetime.now(timezone.utc)
    db.add(row)
    return {"entries_paused": True, "reason": row.reason}

def pause_entries(reason: str = "first_realized_loss") -> dict:
    with SessionLocal() as db:
        result = pause_entries_in_session(db, reason)
        db.commit()
        return result

def entries_paused(db: Session | None = None) -> bool:
    if db is not None:
        row = db.get(RiskCircuitState, 1)
        return bool(row and row.entries_paused)
    with SessionLocal() as session:
        row = session.get(RiskCircuitState, 1)
        return bool(row and row.entries_paused)

def circuit_status() -> dict:
    with SessionLocal() as db:
        row = db.get(RiskCircuitState, 1)
        return {"entries_paused": bool(row and row.entries_paused),
                "reason": row.reason if row else None,
                "updated_at": row.updated_at.isoformat() if row and row.updated_at else None}
