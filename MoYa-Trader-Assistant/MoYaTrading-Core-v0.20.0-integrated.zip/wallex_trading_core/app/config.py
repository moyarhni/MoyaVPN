from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    wallex_base_url: str = "https://api.wallex.ir"
    symbols: str = "BTCUSDT,BTCTMN,USDTTMN"
    poll_seconds: int = 15
    request_timeout_seconds: float = 10
    database_url: str = "sqlite:///./wallex_market.db"
    max_market_data_age_seconds: int = 60
    moya_api_token: str = ""
    live_trading_enabled: bool = False

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def symbol_list(self) -> list[str]:
        return [s.strip().upper() for s in self.symbols.split(",") if s.strip()]

settings = Settings()
