"""Pure risk calculations. This module never submits or manages exchange orders."""
from dataclasses import dataclass
from decimal import Decimal
D = Decimal

@dataclass(frozen=True, slots=True)
class RiskConfig:
    risk_fraction: Decimal = D("0.01")
    max_position_fraction: Decimal = D("0.25")
    fee_rate: Decimal = D("0.001")
    max_daily_loss_fraction: Decimal = D("0.03")

    def validate(self):
        if not D("0") < self.risk_fraction <= D("0.05"): raise ValueError("risk_fraction must be in (0, 0.05]")
        if not D("0") < self.max_position_fraction <= D("1"): raise ValueError("max_position_fraction must be in (0, 1]")
        if not D("0") <= self.fee_rate < D("0.1"): raise ValueError("fee_rate out of range")
        if not D("0") < self.max_daily_loss_fraction <= D("0.2"): raise ValueError("daily loss limit out of range")

def size_spot_position(*, quote_balance: Decimal, entry: Decimal, stop: Decimal,
                       config: RiskConfig | None = None, daily_realized_loss: Decimal = D("0")) -> dict:
    cfg = config or RiskConfig(); cfg.validate()
    vals = [D(str(x)) for x in (quote_balance, entry, stop, daily_realized_loss)]
    balance, price, stop_price, daily_loss = vals
    if any(not x.is_finite() for x in vals) or balance < 0 or price <= 0 or stop_price <= 0 or daily_loss < 0:
        raise ValueError("Invalid risk input")
    daily_limit = balance * cfg.max_daily_loss_fraction
    if daily_loss >= daily_limit and daily_limit > 0:
        return {"allowed": False, "quantity": "0", "reason": "daily_loss_limit_reached"}
    if stop_price >= price:
        return {"allowed": False, "quantity": "0", "reason": "stop_must_be_below_entry_for_spot_long"}
    risk_budget = balance * cfg.risk_fraction
    per_unit = price - stop_price + (price + stop_price) * cfg.fee_rate
    by_risk = risk_budget / per_unit if per_unit > 0 else D("0")
    by_cap = balance * cfg.max_position_fraction / price
    qty = min(by_risk, by_cap)
    if qty <= 0:
        return {"allowed": False, "quantity": "0", "reason": "insufficient_balance"}
    return {"allowed": True, "quantity": str(qty), "risk_budget": str(risk_budget),
            "position_value": str(qty * price), "daily_loss_limit": str(daily_limit), "reason": "risk_checks_passed"}
