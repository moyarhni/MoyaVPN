import json
import logging
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from sqlalchemy.orm import Session
from .db import MarketEvent, SystemEvent
from .wallex import WallexClient
from .config import settings
from .market_data import normalize_ticker_snapshot, MarketDataError

log = logging.getLogger("wallex.collector")

def dumps(payload) -> str:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"), default=str)

def extract_symbols(response) -> dict:
    result = response.get("result", {}) if isinstance(response, dict) else {}
    symbols = result.get("symbols", {}) if isinstance(result, dict) else {}
    return symbols if isinstance(symbols, dict) else {}

def dec(value):
    try:
        number = Decimal(str(value))
        return str(number) if number.is_finite() else None
    except (InvalidOperation, TypeError, ValueError):
        return None

class MarketCollector:
    def __init__(self, client: WallexClient):
        self.client = client
        self.last_success_at = None
        self.last_error = None
        self.known_symbols = {}
        self.last_cycle = None

    def _save(self, db: Session, symbol: str, kind: str, payload, exchange_ts=None):
        db.add(MarketEvent(symbol=symbol, event_type=kind,
            exchange_ts=str(exchange_ts) if exchange_ts is not None else None,
            payload=dumps(payload)))

    async def collect_once(self, db: Session):
        cycle = {"symbols_ok": [], "symbols_invalid": [], "symbols_missing": [], "supplemental_errors": 0}
        try:
            response = await self.client.markets()
            all_markets = extract_symbols(response)
            if not all_markets:
                raise ValueError("Wallex markets response contains no symbols")
            self.known_symbols = all_markets

            for symbol in settings.symbol_list:
                market = all_markets.get(symbol)
                if not isinstance(market, dict):
                    cycle["symbols_missing"].append(symbol)
                    self._save(db, symbol, "market_missing", {"symbol": symbol})
                    continue

                try:
                    stats = market.get("stats") or {}
                    ticker = normalize_ticker_snapshot(stats)
                    snapshot = {
                        "lastPrice": str(ticker.last_price),
                        "bidPrice": str(ticker.bid_price) if ticker.bid_price is not None else None,
                        "askPrice": str(ticker.ask_price) if ticker.ask_price is not None else None,
                        "volume24h": str(ticker.volume_24h) if ticker.volume_24h is not None else None,
                        "quoteVolume24h": str(ticker.quote_volume_24h) if ticker.quote_volume_24h is not None else None,
                        "change24h": stats.get("24h_ch"),
                        "tickSize": market.get("tickSize"),
                        "stepSize": market.get("stepSize"),
                        "minQty": dec(market.get("minQty")),
                        "minNotional": dec(market.get("minNotional")),
                        "quality": "valid",
                    }
                    self._save(db, symbol, "market_snapshot", snapshot)
                    cycle["symbols_ok"].append(symbol)
                except MarketDataError as exc:
                    cycle["symbols_invalid"].append(symbol)
                    self._save(db, symbol, "market_invalid", {"reason": str(exc)})
                    continue

                # Supplemental endpoints are isolated: their failure does not
                # invalidate a valid ticker or block the next configured symbol.
                for kind, method in (("orderbook_snapshot", self.client.depth), ("trades_snapshot", self.client.trades)):
                    try:
                        payload = await method(symbol)
                        if not isinstance(payload, dict):
                            raise ValueError("unexpected response type")
                        self._save(db, symbol, kind, payload.get("result", payload))
                    except Exception as exc:
                        cycle["supplemental_errors"] += 1
                        self._save(db, symbol, f"{kind}_error", {"error": type(exc).__name__})

            db.commit()
            self.last_success_at = datetime.now(timezone.utc).isoformat()
            self.last_error = None
            cycle["ok"] = not cycle["symbols_invalid"] and not cycle["symbols_missing"]
            cycle["symbols_seen"] = len(all_markets)
            cycle["collected"] = len(cycle["symbols_ok"])
            self.last_cycle = cycle
            return cycle
        except Exception as exc:
            db.rollback()
            self.last_error = f"{type(exc).__name__}: {exc}"
            log.exception("Market collection failed")
            db.add(SystemEvent(level="ERROR", message=self.last_error))
            db.commit()
            self.last_cycle = {"ok": False, "error": self.last_error}
            return self.last_cycle
