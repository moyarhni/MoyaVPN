"""Deterministic spot decision layer. Research/paper only; never submits orders."""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from typing import Sequence

from .market_data import Candle
from .signal_engine import SignalConfig, analyze_closed_candles
from .pattern_engine import PatternConfig, detect_patterns
from .composite_patterns import combine_patterns
from .risk_manager import RiskConfig, size_spot_position

D = Decimal

@dataclass(frozen=True, slots=True)
class DecisionConfig:
    min_combined_score: int = 60
    min_direction_gap: int = 15
    max_risk_fraction: Decimal = D("0.01")
    fee_rate: Decimal = D("0.001")
    stop_atr_multiple: Decimal = D("1.5")
    reward_risk_ratio: Decimal = D("2")
    max_position_fraction: Decimal = D("0.25")

    def validate(self) -> None:
        if not 0 <= self.min_combined_score <= 100 or not 0 <= self.min_direction_gap <= 100:
            raise ValueError("Score thresholds must be between 0 and 100")
        if not 0 < self.max_risk_fraction <= D("0.05"):
            raise ValueError("Risk fraction must be in (0, 5%]")
        if not 0 <= self.fee_rate < 1 or self.stop_atr_multiple <= 0 or self.reward_risk_ratio <= 0:
            raise ValueError("Invalid fee, stop or reward/risk configuration")
        if not 0 < self.max_position_fraction <= 1:
            raise ValueError("Position cap must be in (0, 1]")


def make_decision(candles: Sequence[Candle], *, symbol: str,
                  quote_balance: Decimal = D("0"), base_quantity: Decimal = D("0"),
                  entry_paused: bool = False, config: DecisionConfig | None = None) -> dict:
    """Combine indicator and pattern evidence into BUY/SELL/HOLD/NO_TRADE."""
    cfg = config or DecisionConfig(); cfg.validate()
    if not symbol or not symbol.strip():
        raise ValueError("symbol is required")
    quote_balance, base_quantity = D(str(quote_balance)), D(str(base_quantity))
    if not quote_balance.is_finite() or not base_quantity.is_finite() or quote_balance < 0 or base_quantity < 0:
        raise ValueError("Balances must be finite and non-negative")

    signal = analyze_closed_candles(candles, SignalConfig())
    patterns = detect_patterns(candles, PatternConfig())
    long_pattern = max((p["score"] for p in patterns["patterns_detected"] if p["direction"] == "bullish"), default=0)
    short_pattern = max((p["score"] for p in patterns["patterns_detected"] if p["direction"] == "bearish"), default=0)
    long_score = min(100, int(signal["scores"]["long"] * 0.75 + long_pattern * 0.25))
    short_score = min(100, int(signal["scores"]["short"] * 0.75 + short_pattern * 0.25))
    gap = abs(long_score-short_score)
    composite = combine_patterns(patterns, indicator_signal=signal.get("signal"))
    composite_bull = max((x["score"] for x in composite["combinations"] if x["direction"] == "bullish"), default=0)
    composite_bear = max((x["score"] for x in composite["combinations"] if x["direction"] == "bearish"), default=0)
    long_score = min(100, int(long_score * 0.85 + composite_bull * 0.15))
    short_score = min(100, int(short_score * 0.85 + composite_bear * 0.15))
    gap = abs(long_score-short_score)
    close = candles[-1].close
    atr = D(signal["evidence"]["atr"])
    stop = close - cfg.stop_atr_multiple*atr
    target = close + cfg.stop_atr_multiple*atr*cfg.reward_risk_ratio

    action, reason = "NO_TRADE", "No direction has sufficient combined evidence"
    if entry_paused:
        action, reason = "NO_TRADE", "Entry circuit breaker is active after a realized loss"
    elif signal["signal"] == "NO_TRADE" or max(long_score, short_score) < cfg.min_combined_score or gap < cfg.min_direction_gap:
        action, reason = "NO_TRADE", "Indicator, score or direction-gap filter did not pass"
    elif long_score > short_score:
        action, reason = "BUY", "Bullish evidence passed the decision filters"
    elif short_score > long_score:
        action = "SELL" if base_quantity > 0 else "HOLD"
        reason = "Bearish evidence: sell only the available spot asset" if base_quantity > 0 else "Bearish evidence in spot: no short position is opened"

    risk_result = size_spot_position(quote_balance=quote_balance, entry=close, stop=stop,
        config=RiskConfig(risk_fraction=cfg.max_risk_fraction, max_position_fraction=cfg.max_position_fraction,
                          fee_rate=cfg.fee_rate))
    quantity = D(risk_result["quantity"])
    if action == "BUY" and not risk_result["allowed"]:
        action, reason, quantity = "NO_TRADE", risk_result["reason"], D("0")
    if action != "BUY":
        quantity = D("0")
    return {
        "engine": "moya_decision_v1", "mode": "research_and_paper_only",
        "symbol": symbol.upper(), "action": action, "reason": reason,
        "scores": {"bullish": long_score, "bearish": short_score, "direction_gap": gap},
        "position": {"suggested_buy_quantity": str(quantity), "available_base_quantity": str(base_quantity),
                     "risk_budget_quote": risk_result.get("risk_budget", "0"), "max_position_fraction": str(cfg.max_position_fraction), "risk_check": risk_result},
        "levels": {"reference_price": str(close), "stop_loss": str(stop) if stop > 0 else None,
                   "take_profit": str(target)},
        "evidence": {"indicator_signal": signal["signal"], "indicator_scores": signal["scores"],
                     "detected_patterns": patterns["patterns_detected"], "composite_patterns": composite["combinations"], "pattern_detector_coverage": patterns.get("detector_coverage")},
        "safety": {"live_trading_enabled": False, "orders_submitted": False,
                   "spot_shorting_disabled": True, "entry_paused": entry_paused,
                   "scores_are_probabilities": False},
    }
