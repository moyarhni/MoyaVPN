"""Persistent pattern observation memory; stores observations, not automatic strategy changes."""
from __future__ import annotations
import json
from datetime import datetime, timezone
from sqlalchemy import Integer, String, Text, DateTime, select, func
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base, SessionLocal

class PatternObservation(Base):
    __tablename__ = "pattern_observations"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    pattern_key: Mapped[str] = mapped_column(String(120), index=True)
    symbol: Mapped[str] = mapped_column(String(32), index=True)
    timeframe: Mapped[str] = mapped_column(String(16), default="unknown")
    direction: Mapped[str] = mapped_column(String(16))
    score: Mapped[int] = mapped_column(Integer)
    features_json: Mapped[str] = mapped_column(Text, default="{}")
    outcome: Mapped[str] = mapped_column(String(16), default="pending", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

def record_observation(*, pattern_key: str, symbol: str, direction: str, score: int,
                       timeframe: str = "unknown", features: dict | None = None) -> int:
    if not pattern_key or not symbol or direction not in {"bullish", "bearish", "neutral"} or not 0 <= int(score) <= 100:
        raise ValueError("Invalid pattern observation")
    with SessionLocal() as db:
        row = PatternObservation(pattern_key=pattern_key[:120], symbol=symbol.upper()[:32],
            timeframe=timeframe[:16], direction=direction, score=int(score),
            features_json=json.dumps(features or {}, separators=(",", ":"), default=str))
        db.add(row); db.commit(); db.refresh(row); return row.id

def resolve_observation(observation_id: int, outcome: str) -> None:
    if outcome not in {"win", "loss", "neutral", "invalid"}: raise ValueError("Invalid outcome")
    with SessionLocal() as db:
        row = db.get(PatternObservation, observation_id)
        if row is None: raise LookupError("Pattern observation not found")
        if row.outcome != "pending": raise ValueError("Observation is already resolved")
        row.outcome = outcome; row.resolved_at = datetime.now(timezone.utc); db.commit()

def pattern_memory_summary(*, symbol: str | None = None, limit: int = 100) -> list[dict]:
    if not 1 <= limit <= 1000: raise ValueError("limit must be between 1 and 1000")
    with SessionLocal() as db:
        stmt = select(PatternObservation.pattern_key, PatternObservation.direction,
            func.count(PatternObservation.id).label("samples"),
            func.sum((PatternObservation.outcome == "win").cast(Integer)).label("wins"),
            func.sum((PatternObservation.outcome == "loss").cast(Integer)).label("losses"))
        if symbol: stmt = stmt.where(PatternObservation.symbol == symbol.upper())
        rows = db.execute(stmt.group_by(PatternObservation.pattern_key, PatternObservation.direction)
                          .order_by(func.count(PatternObservation.id).desc()).limit(limit)).all()
        return [{"pattern_key": r.pattern_key, "direction": r.direction, "samples": int(r.samples),
                 "wins": int(r.wins or 0), "losses": int(r.losses or 0)} for r in rows]
