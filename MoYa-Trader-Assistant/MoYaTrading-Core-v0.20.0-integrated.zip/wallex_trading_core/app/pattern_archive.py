"""Versioned pattern archive, similarity lookup and lossless compaction helpers."""
from __future__ import annotations
import hashlib, json
from datetime import datetime, timezone
from sqlalchemy import Integer, String, Text, DateTime, select, func
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base, SessionLocal

class PatternArchiveRecord(Base):
    __tablename__ = 'pattern_archive_records'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    pattern_key: Mapped[str] = mapped_column(String(120), index=True)
    schema_version: Mapped[str] = mapped_column(String(24), default='1.0.0')
    fingerprint: Mapped[str] = mapped_column(String(64), index=True)
    features_json: Mapped[str] = mapped_column(Text)
    provenance_json: Mapped[str] = mapped_column(Text, default='{}')
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class PatternAggregate(Base):
    __tablename__ = 'pattern_aggregates'
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    pattern_key: Mapped[str] = mapped_column(String(120), index=True)
    symbol: Mapped[str] = mapped_column(String(32), index=True)
    timeframe: Mapped[str] = mapped_column(String(16), default='unknown')
    direction: Mapped[str] = mapped_column(String(16))
    samples: Mapped[int] = mapped_column(Integer, default=0)
    wins: Mapped[int] = mapped_column(Integer, default=0)
    losses: Mapped[int] = mapped_column(Integer, default=0)
    neutral: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

def _canonical(value):
    return json.dumps(value or {}, sort_keys=True, separators=(',', ':'), default=str)

def archive_pattern(pattern_key: str, features: dict, *, schema_version='1.0.0', provenance=None) -> dict:
    if not pattern_key or len(pattern_key) > 120: raise ValueError('invalid pattern_key')
    raw = _canonical(features); fingerprint = hashlib.sha256(raw.encode()).hexdigest()
    with SessionLocal() as db:
        row = PatternArchiveRecord(pattern_key=pattern_key, schema_version=schema_version,
            fingerprint=fingerprint, features_json=raw, provenance_json=_canonical(provenance))
        db.add(row); db.commit(); db.refresh(row)
        return {'id': row.id, 'pattern_key': pattern_key, 'schema_version': schema_version, 'fingerprint': fingerprint}

def find_similar_patterns(pattern_key: str, *, limit=50) -> list[dict]:
    if not 1 <= limit <= 500: raise ValueError('limit must be 1..500')
    with SessionLocal() as db:
        rows = db.scalars(select(PatternArchiveRecord).where(PatternArchiveRecord.pattern_key == pattern_key)
                          .order_by(PatternArchiveRecord.id.desc()).limit(limit)).all()
        return [{'id': r.id, 'pattern_key': r.pattern_key, 'schema_version': r.schema_version,
                 'fingerprint': r.fingerprint, 'features': json.loads(r.features_json),
                 'provenance': json.loads(r.provenance_json)} for r in rows]

def compact_resolved_observations() -> dict:
    """Aggregate resolved observations without deleting source records."""
    from .pattern_memory import PatternObservation
    with SessionLocal() as db:
        rows = db.execute(select(PatternObservation.pattern_key, PatternObservation.symbol,
            PatternObservation.timeframe, PatternObservation.direction, PatternObservation.outcome,
            func.count(PatternObservation.id)).where(PatternObservation.outcome != 'pending')
            .group_by(PatternObservation.pattern_key, PatternObservation.symbol,
                      PatternObservation.timeframe, PatternObservation.direction,
                      PatternObservation.outcome)).all()
        changed = 0
        for key, symbol, timeframe, direction, outcome, count in rows:
            agg = db.scalar(select(PatternAggregate).where(
                PatternAggregate.pattern_key == key, PatternAggregate.symbol == symbol,
                PatternAggregate.timeframe == timeframe, PatternAggregate.direction == direction))
            if agg is None:
                agg = PatternAggregate(pattern_key=key, symbol=symbol, timeframe=timeframe, direction=direction)
                db.add(agg)
            # Rebuild exact aggregate from source of truth; idempotent on repeated runs.
            counts = {o: int(db.scalar(select(func.count(PatternObservation.id)).where(
                PatternObservation.pattern_key == key, PatternObservation.symbol == symbol,
                PatternObservation.timeframe == timeframe, PatternObservation.direction == direction,
                PatternObservation.outcome == o)) or 0) for o in ('win','loss','neutral','invalid')}
            agg.samples = sum(counts.values()); agg.wins = counts['win']; agg.losses = counts['loss']
            agg.neutral = counts['neutral'] + counts['invalid']; agg.updated_at = datetime.now(timezone.utc)
            changed += 1
        db.commit()
        return {'aggregates_rebuilt': changed, 'source_observations_deleted': 0}
