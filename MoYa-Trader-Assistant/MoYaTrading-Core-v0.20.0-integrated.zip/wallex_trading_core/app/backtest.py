"""Deterministic candle-by-candle SMA crossover backtester.

Research-only engine. Signals use closed candles and execute at the next candle
open. When stop-loss and take-profit both fit inside one candle, stop-loss wins.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Sequence

from .market_data import Candle


class BacktestError(ValueError):
    pass


def _d(value, name: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise BacktestError(f"Invalid {name}") from exc
    if not result.is_finite():
        raise BacktestError(f"Invalid {name}")
    return result


@dataclass(frozen=True, slots=True)
class BacktestConfig:
    fast_period: int = 9
    slow_period: int = 21
    starting_balance: Decimal = Decimal("10000")
    stake_quote: Decimal = Decimal("100")
    leverage: Decimal = Decimal("1")
    fee_rate: Decimal = Decimal("0.001")
    slippage_bps: Decimal = Decimal("5")
    stop_loss_pct: Decimal | None = Decimal("0.02")
    take_profit_pct: Decimal | None = None
    allow_short: bool = True
    strategy: str = "sma_crossover"

    def validate(self):
        if self.strategy not in {"sma_crossover", "ema_crossover", "donchian_breakout"}:
            raise BacktestError("Unsupported strategy")
        if self.fast_period < 2 or self.slow_period <= self.fast_period:
            raise BacktestError("Require 2 <= fast_period < slow_period")
        for name in ("starting_balance", "stake_quote", "leverage", "fee_rate", "slippage_bps"):
            object.__setattr__(self, name, _d(getattr(self, name), name))
        if self.starting_balance <= 0 or self.stake_quote <= 0 or self.leverage < 1:
            raise BacktestError("Balance and stake must be positive; leverage must be >= 1")
        if self.fee_rate < 0 or self.fee_rate >= 1 or self.slippage_bps < 0 or self.slippage_bps > 5000:
            raise BacktestError("Fee or slippage is outside supported range")
        for name in ("stop_loss_pct", "take_profit_pct"):
            value = getattr(self, name)
            if value is not None:
                value = _d(value, name)
                if value <= 0 or value >= 1:
                    raise BacktestError(f"{name} must be between 0 and 1")
                object.__setattr__(self, name, value)


@dataclass(slots=True)
class _Position:
    direction: str
    quantity: Decimal
    entry_price: Decimal
    entry_fee: Decimal
    entry_ts: int


def _adverse(price: Decimal, direction: str, is_entry: bool, slip: Decimal) -> Decimal:
    # direction describes position direction; adverse execution is always against it.
    long_buy = (direction == "LONG" and is_entry) or (direction == "SHORT" and not is_entry)
    return price * (Decimal(1) + slip if long_buy else Decimal(1) - slip)


def run_sma_backtest(candles: Sequence[Candle], config: BacktestConfig, trade_start_index: int = 0) -> dict:
    config.validate()
    if not isinstance(trade_start_index, int) or trade_start_index < 0 or trade_start_index >= len(candles):
        raise BacktestError("trade_start_index must identify a candle in the supplied data")
    if len(candles) > 100_000:
        raise BacktestError("Maximum 100,000 candles per run")
    if len(candles) < config.slow_period + 2:
        raise BacktestError("Not enough candles for the selected SMA periods")
    for i, candle in enumerate(candles):
        if i and candle.timestamp <= candles[i - 1].timestamp:
            raise BacktestError("Candles must be strictly chronological")
        if min(candle.open, candle.high, candle.low, candle.close) <= 0 or candle.volume < 0:
            raise BacktestError("Candle prices must be positive and volume non-negative")
        if candle.high < max(candle.open, candle.low, candle.close) or candle.low > min(candle.open, candle.high, candle.close):
            raise BacktestError("Invalid OHLC range")

    fast, slow = config.fast_period, config.slow_period
    ema_fast: list[Decimal] = []
    ema_slow: list[Decimal] = []
    if config.strategy == "ema_crossover":
        alpha_fast = Decimal(2) / Decimal(fast + 1)
        alpha_slow = Decimal(2) / Decimal(slow + 1)
        for idx, candle in enumerate(candles):
            ema_fast.append(candle.close if idx == 0 else alpha_fast*candle.close + (1-alpha_fast)*ema_fast[-1])
            ema_slow.append(candle.close if idx == 0 else alpha_slow*candle.close + (1-alpha_slow)*ema_slow[-1])
    slip = config.slippage_bps / Decimal(10_000)
    balance = config.starting_balance
    position: _Position | None = None
    pending: str | None = None
    trades: list[dict] = []
    equity_curve: list[Decimal] = [balance]

    def close_position(raw_price: Decimal, ts: int, reason: str):
        nonlocal position, balance
        assert position is not None
        exit_price = _adverse(raw_price, position.direction, False, slip)
        gross = ((exit_price - position.entry_price) if position.direction == "LONG"
                 else (position.entry_price - exit_price)) * position.quantity
        exit_fee = exit_price * position.quantity * config.fee_rate
        net = gross - position.entry_fee - exit_fee
        balance += gross - exit_fee
        trades.append({
            "direction": position.direction, "quantity": str(position.quantity),
            "entry_timestamp": position.entry_ts, "exit_timestamp": ts,
            "entry_price": str(position.entry_price), "exit_price": str(exit_price),
            "gross_pnl": str(gross), "entry_fee": str(position.entry_fee),
            "exit_fee": str(exit_fee), "net_pnl": str(net), "exit_reason": reason,
        })
        position = None
        equity_curve.append(balance)

    for i, candle in enumerate(candles):
        # Execute only signals generated by the previous, fully closed candle.
        if i >= trade_start_index and pending == "EXIT" and position is not None:
            close_position(candle.open, candle.timestamp, "sma_reverse")
        elif i >= trade_start_index and pending in ("LONG", "SHORT") and position is None:
            direction = pending
            raw = candle.open
            entry = _adverse(raw, direction, True, slip)
            notional = config.stake_quote * config.leverage
            qty = notional / entry
            fee = notional * config.fee_rate
            if balance >= config.stake_quote + fee:
                balance -= fee
                equity_curve.append(balance)
                position = _Position(direction, qty, entry, fee, candle.timestamp)
        pending = None

        # Conservative intrabar risk handling: stop is checked before target.
        if position is not None:
            entry = position.entry_price
            if position.direction == "LONG":
                stop = entry * (1 - config.stop_loss_pct) if config.stop_loss_pct is not None else None
                target = entry * (1 + config.take_profit_pct) if config.take_profit_pct is not None else None
                stop_hit = stop is not None and candle.low <= stop
                target_hit = target is not None and candle.high >= target
            else:
                stop = entry * (1 + config.stop_loss_pct) if config.stop_loss_pct is not None else None
                target = entry * (1 - config.take_profit_pct) if config.take_profit_pct is not None else None
                stop_hit = stop is not None and candle.high >= stop
                target_hit = target is not None and candle.low <= target
            if stop_hit:
                close_position(stop, candle.timestamp, "stop_loss")
            elif target_hit:
                close_position(target, candle.timestamp, "take_profit")

        # Signals use only this candle's close and earlier candles.
        crossed_up = crossed_down = False
        if config.strategy == "sma_crossover" and i >= slow:
            prev_fast = sum((c.close for c in candles[i-fast:i]), Decimal(0)) / fast
            prev_slow = sum((c.close for c in candles[i-slow:i]), Decimal(0)) / slow
            curr_fast = sum((c.close for c in candles[i-fast+1:i+1]), Decimal(0)) / fast
            curr_slow = sum((c.close for c in candles[i-slow+1:i+1]), Decimal(0)) / slow
            crossed_up = prev_fast <= prev_slow and curr_fast > curr_slow
            crossed_down = prev_fast >= prev_slow and curr_fast < curr_slow
        elif config.strategy == "ema_crossover" and i >= slow:
            crossed_up = ema_fast[i-1] <= ema_slow[i-1] and ema_fast[i] > ema_slow[i]
            crossed_down = ema_fast[i-1] >= ema_slow[i-1] and ema_fast[i] < ema_slow[i]
        elif config.strategy == "donchian_breakout" and i >= slow + 1:
            prior_upper = max(c.high for c in candles[i-slow:i])
            prior_lower = min(c.low for c in candles[i-slow:i])
            older_upper = max(c.high for c in candles[i-slow-1:i-1])
            older_lower = min(c.low for c in candles[i-slow-1:i-1])
            crossed_up = candles[i-1].close <= older_upper and candle.close > prior_upper
            crossed_down = candles[i-1].close >= older_lower and candle.close < prior_lower
        if i >= max(0, trade_start_index - 1) and (crossed_up or crossed_down):
            if position is None:
                if crossed_up:
                    pending = "LONG"
                elif crossed_down and config.allow_short:
                    pending = "SHORT"
            elif (position.direction == "LONG" and crossed_down) or (position.direction == "SHORT" and crossed_up):
                pending = "EXIT"

    # No forced liquidation at the final close; that would assume an execution
    # opportunity not represented by a subsequent candle.
    wins = [Decimal(t["net_pnl"]) for t in trades if Decimal(t["net_pnl"]) > 0]
    losses = [Decimal(t["net_pnl"]) for t in trades if Decimal(t["net_pnl"]) < 0]
    gross_profit, gross_loss = sum(wins, Decimal(0)), abs(sum(losses, Decimal(0)))
    peak = config.starting_balance
    max_dd = Decimal(0)
    for value in equity_curve:
        peak = max(peak, value)
        if peak > 0:
            max_dd = max(max_dd, (peak - value) / peak)
    net_profit = balance - config.starting_balance
    return {
        "engine": f"{config.strategy}_v1", "strategy": config.strategy, "mode": "historical_backtest_only",
        "candle_count": len(candles), "starting_balance": str(config.starting_balance),
        "ending_balance": str(balance), "net_profit": str(net_profit),
        "return_pct": str(net_profit / config.starting_balance * 100),
        "trade_count": len(trades), "win_rate_pct": str(Decimal(len(wins)) / len(trades) * 100 if trades else Decimal(0)),
        "profit_factor": str(gross_profit / gross_loss if gross_loss else (Decimal("Infinity") if gross_profit else Decimal(0))),
        "max_drawdown_pct": str(max_dd * 100),
        "drawdown_basis": "Balance snapshots at entry-fee deductions and trade closes; excludes unrealized price movement.",
        "open_position_at_end": position is not None,
        "open_position_direction": position.direction if position else None,
        "trades": trades,
        "assumptions": [
            "Signals use closed candles and execute at the next candle open.",
            "Slippage is a fixed adverse basis-point estimate, not order-book replay.",
            "Fees apply on entry and exit.",
            "If stop-loss and take-profit both occur in one candle, stop-loss is assumed first.",
            "An open final position is marked as open and is not forcibly liquidated.",
            "These strategy implementations are research baselines, not validated production strategies.",
        ],
    }
