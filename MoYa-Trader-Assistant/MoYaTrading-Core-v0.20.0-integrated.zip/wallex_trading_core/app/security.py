"""Minimal API bearer-token guard. Configure MOYA_API_TOKEN before network exposure."""
import secrets
from fastapi import Request
from fastapi.responses import JSONResponse
from .config import settings

class ApiSecurityMiddleware:
    def __init__(self, app): self.app = app
    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http': return await self.app(scope, receive, send)
        request = Request(scope, receive=receive)
        token = getattr(settings, 'moya_api_token', '')
        path = request.url.path
        if token and path not in {'/health'} and not path.startswith('/docs') and not path.startswith('/openapi'):
            supplied = request.headers.get('authorization', '')
            if not supplied.startswith('Bearer ') or not secrets.compare_digest(supplied[7:], token):
                response = JSONResponse({'detail':'Unauthorized'}, status_code=401)
                return await response(scope, receive, send)
        return await self.app(scope, receive, send)
