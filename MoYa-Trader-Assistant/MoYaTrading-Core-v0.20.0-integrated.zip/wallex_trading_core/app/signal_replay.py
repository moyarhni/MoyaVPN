"""Chronological replay for trend_momentum_v1 signals (research-only)."""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from typing import Sequence

from .market_data import Candle
from .signal_engine import SignalConfig, analyze_closed_candles, SignalAnalysisError


class SignalReplayError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class ReplayConfig:
    starting_balance: Decimal = Decimal("10000")
    stake_quote: Decimal = Decimal("100")
    fee_rate: Decimal = Decimal("0.001")
    slippage_bps: Decimal = Decimal("5")
    signal: SignalConfig = SignalConfig()

    def validate(self):
        for name in ("starting_balance", "stake_quote", "fee_rate", "slippage_bps"):
            value = Decimal(str(getattr(self, name)))
            if not value.is_finite():
                raise SignalReplayError(f"Invalid {name}")
            object.__setattr__(self, name, value)
        if self.starting_balance <= 0 or self.stake_quote <= 0:
            raise SignalReplayError("Balance and stake must be positive")
        if not 0 <= self.fee_rate < 1 or not 0 <= self.slippage_bps <= 500:
            raise SignalReplayError("Fee or slippage outside supported range")
        self.signal.validate()


def run_signal_replay(candles: Sequence[Candle], config: ReplayConfig | None = None) -> dict:
    """Replay signals using prefix-only data; execute at the next candle open."""
    cfg = config or ReplayConfig()
    cfg.validate()
    minimum = max(cfg.signal.slow_ema + 2, cfg.signal.rsi_period + 2,
                  cfg.signal.atr_period + 2, cfg.signal.breakout_period + 1)
    if len(candles) < minimum + 2:
        raise SignalReplayError(f"Need at least {minimum + 2} candles")
    if len(candles) > 100_000:
        raise SignalReplayError("Maximum 100,000 candles")
    for i, c in enumerate(candles):
        if i and c.timestamp <= candles[i-1].timestamp:
            raise SignalReplayError("Candles must be strictly chronological")
        if min(c.open, c.high, c.low, c.close) <= 0 or c.volume < 0 or c.high < max(c.open,c.low,c.close) or c.low > min(c.open,c.high,c.close):
            raise SignalReplayError("Invalid OHLCV candle")

    balance = cfg.starting_balance
    position = None
    pending = None
    trades = []
    slip = cfg.slippage_bps / Decimal(10000)

    def close(raw_exit, ts, reason):
        nonlocal balance, position
        side = position["side"]
        exit_price = raw_exit * (1-slip if side == "LONG" else 1+slip)
        gross = ((exit_price-position["entry"]) if side == "LONG" else (position["entry"]-exit_price)) * position["qty"]
        fee = exit_price * position["qty"] * cfg.fee_rate
        net = gross - position["entry_fee"] - fee
        balance += gross - fee
        trades.append({"side":side,"entry_timestamp":position["ts"],"exit_timestamp":ts,"entry_price":str(position["entry"]),"exit_price":str(exit_price),"net_pnl":str(net),"exit_reason":reason})
        position = None

    for i, candle in enumerate(candles):
        if pending and pending[0] == "EXIT" and position is not None:
            close(candle.open, candle.timestamp, "opposite_signal")
            pending = None
        if pending and pending[0] in ("LONG", "SHORT") and position is None:
            side, stop, target, signal_close = pending
            raw = candle.open
            # Reject gap-through entries: risk levels must remain on the safe side.
            valid = (raw > stop and raw < target) if side == "LONG" else (raw < stop and raw > target)
            entry = raw * (1+slip if side == "LONG" else 1-slip)
            qty = cfg.stake_quote / entry
            entry_fee = cfg.stake_quote * cfg.fee_rate
            if valid and balance >= cfg.stake_quote + entry_fee:
                balance -= entry_fee
                position = {"side":side,"entry":entry,"qty":qty,"entry_fee":entry_fee,"ts":candle.timestamp,"stop":stop,"target":target}
            pending = None
        if position:
            side = position["side"]
            stop_hit = candle.low <= position["stop"] if side == "LONG" else candle.high >= position["stop"]
            target_hit = candle.high >= position["target"] if side == "LONG" else candle.low <= position["target"]
            if stop_hit:
                close(position["stop"], candle.timestamp, "stop_loss")
            elif target_hit:
                close(position["target"], candle.timestamp, "take_profit")

        if i >= minimum - 1 and i < len(candles)-1:
            try:
                result = analyze_closed_candles(candles[:i+1], cfg.signal)
            except SignalAnalysisError:
                continue
            signal = result["signal"]
            if position and signal in (("SHORT",) if position["side"] == "LONG" else ("LONG",)):
                pending = ("EXIT", None, None, None)
            elif position is None and signal in ("LONG","SHORT"):
                pending = (signal, Decimal(result["reference_stop"]), Decimal(result["reference_target"]), candle.close)

    wins = sum(1 for t in trades if Decimal(t["net_pnl"]) > 0)
    losses = sum(1 for t in trades if Decimal(t["net_pnl"]) < 0)
    net = balance - cfg.starting_balance
    return {"engine":"trend_momentum_v1","mode":"historical_signal_replay_only","candle_count":len(candles),"trade_count":len(trades),"wins":wins,"losses":losses,"win_rate_pct":str(Decimal(wins)/len(trades)*100 if trades else Decimal(0)),"net_pnl":str(net),"ending_balance":str(balance),"open_position_at_end":position is not None,"trades":trades,"warnings":["Signal decisions use only candle prefixes and execute at the next candle open.","OHLCV cannot reveal intrabar price order; stop is assumed before target.","This replay is not proof of profitability and does not model exchange margin or order-book fills."]}
