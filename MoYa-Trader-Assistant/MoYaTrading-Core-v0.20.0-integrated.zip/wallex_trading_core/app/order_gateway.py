"""Execution boundary. Only paper adapter is implemented; live adapter fails closed."""
from abc import ABC, abstractmethod
class ExecutionDisabled(RuntimeError): pass
class OrderGateway(ABC):
    @abstractmethod
    def submit(self, order: dict) -> dict: ...
class PaperOnlyGateway(OrderGateway):
    def submit(self, order: dict) -> dict:
        raise ExecutionDisabled('Use the explicit paper-ledger workflow with an order book; no live orders are sent')
class LiveWallexGateway(OrderGateway):
    def submit(self, order: dict) -> dict:
        raise ExecutionDisabled('Live Wallex execution is not implemented or enabled in this release')
