"""Fixed-grid sensitivity diagnostics for two-sided signal replay.

Compares pre-declared parameter variants. It does not optimize or select a strategy.
"""
from __future__ import annotations
from dataclasses import replace
from decimal import Decimal
from typing import Mapping, Sequence
from .market_data import Candle
from .signal_engine import SignalConfig
from .signal_replay import ReplayConfig, run_signal_replay

class SensitivityError(ValueError):
    pass

def evaluate_sensitivity(markets: Mapping[str, Sequence[Candle]],
                         variants: Mapping[str, SignalConfig],
                         replay_config: ReplayConfig | None = None) -> dict:
    """Evaluate every fixed variant on every supplied market independently."""
    if not markets or not variants:
        raise SensitivityError("At least one market and one parameter variant are required")
    if len(markets) > 30 or len(variants) > 20:
        raise SensitivityError("Maximum 30 markets and 20 variants per run")
    if any(not str(k).strip() for k in (*markets.keys(), *variants.keys())):
        raise SensitivityError("Market and variant names must be non-empty")
    base = replay_config or ReplayConfig()
    base.validate()
    results = []
    for market, candles in markets.items():
        if not candles:
            raise SensitivityError(f"No candles supplied for market {market}")
        for variant, signal_config in variants.items():
            report = run_signal_replay(candles, replace(base, signal=signal_config))
            pnl = Decimal(report["net_pnl"])
            results.append({"market": market, "variant": variant,
                "trade_count": report["trade_count"], "wins": report["wins"],
                "losses": report["losses"], "win_rate_pct": report["win_rate_pct"],
                "net_pnl": str(pnl), "ending_balance": report["ending_balance"],
                "open_position_at_end": report["open_position_at_end"]})
    summaries = []
    for variant in variants:
        rows = [r for r in results if r["variant"] == variant]
        positive = sum(Decimal(r["net_pnl"]) > 0 for r in rows)
        negative = sum(Decimal(r["net_pnl"]) < 0 for r in rows)
        pnls = sorted(Decimal(r["net_pnl"]) for r in rows)
        summaries.append({"variant": variant, "markets_tested": len(rows),
            "markets_positive": positive, "markets_negative": negative,
            "markets_flat": len(rows)-positive-negative,
            "total_trades": sum(r["trade_count"] for r in rows),
            "median_market_pnl": str(pnls[len(pnls)//2] if len(pnls)%2 else (pnls[len(pnls)//2-1]+pnls[len(pnls)//2])/Decimal(2))})
    return {"mode": "fixed_grid_sensitivity_diagnostic",
        "parameter_optimization_performed": False, "strategy_selected": False,
        "market_count": len(markets), "variant_count": len(variants),
        "results": results, "variant_summary": summaries,
        "warnings": ["Variants are pre-declared; no winner is selected.",
            "Each market uses an independent virtual balance.",
            "Results depend on data quality, fees, slippage and sample selection.",
            "This is a robustness diagnostic, not evidence of future profitability."]}
