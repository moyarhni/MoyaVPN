"""Chronological walk-forward evaluation with indicator warm-up only."""
from __future__ import annotations
from decimal import Decimal
from typing import Sequence
from .backtest import BacktestConfig, BacktestError, run_sma_backtest
from .market_data import Candle


class WalkForwardError(ValueError):
    pass


def evaluate_walk_forward(candles: Sequence[Candle], config: BacktestConfig,
                          initial_train_size: int, test_size: int,
                          max_folds: int = 12) -> dict:
    """Evaluate fixed parameters on consecutive unseen test windows.

    The initial window is used only to establish when out-of-sample evaluation
    begins. No parameter fitting occurs. Each fold receives prior candles only
    for indicator warm-up; trading is enabled at the first test candle.
    Folds use independent balances and do not carry positions across boundaries.
    """
    config.validate()
    n = len(candles)
    if n > 100_000:
        raise WalkForwardError("Maximum 100,000 candles per run")
    if initial_train_size < config.slow_period + 2:
        raise WalkForwardError("initial_train_size must exceed indicator warm-up")
    if test_size < 3 or max_folds < 1 or max_folds > 50:
        raise WalkForwardError("test_size must be >= 3 and max_folds must be 1..50")
    if initial_train_size >= n:
        raise WalkForwardError("Initial training window leaves no out-of-sample candles")

    warmup = max((5 * config.slow_period if config.strategy == "ema_crossover" else config.slow_period + 2), config.fast_period + 2)
    folds: list[dict] = []
    all_trades: list[dict] = []
    start = initial_train_size
    while start < n and len(folds) < max_folds:
        end = min(start + test_size, n)
        context_start = max(0, start - warmup)
        window = candles[context_start:end]
        trade_index = start - context_start
        try:
            result = run_sma_backtest(window, config, trade_start_index=trade_index)
        except BacktestError as exc:
            raise WalkForwardError(str(exc)) from exc
        # Only completed trades opened in this fold are counted.
        fold_trades = [t for t in result["trades"] if t["entry_timestamp"] >= candles[start].timestamp]
        all_trades.extend(fold_trades)
        pnl = sum((Decimal(t["net_pnl"]) for t in fold_trades), Decimal(0))
        wins = sum(1 for t in fold_trades if Decimal(t["net_pnl"]) > 0)
        losses = sum(1 for t in fold_trades if Decimal(t["net_pnl"]) < 0)
        folds.append({
            "fold": len(folds) + 1,
            "warmup_start_timestamp": candles[context_start].timestamp,
            "test_start_timestamp": candles[start].timestamp,
            "test_end_timestamp": candles[end - 1].timestamp,
            "test_candles": end - start,
            "completed_trades": len(fold_trades),
            "wins": wins,
            "losses": losses,
            "net_pnl": str(pnl),
            "win_rate_pct": str(Decimal(wins) / len(fold_trades) * 100 if fold_trades else Decimal(0)),
            "open_position_at_fold_end": bool(result["open_position_at_end"]),
            "fold_starting_balance": str(config.starting_balance),
            "fold_return_pct_on_starting_balance": str(pnl / config.starting_balance * 100),
        })
        start = end

    if not folds:
        raise WalkForwardError("No complete walk-forward folds could be evaluated")
    total_pnl = sum((Decimal(t["net_pnl"]) for t in all_trades), Decimal(0))
    total_wins = sum(1 for t in all_trades if Decimal(t["net_pnl"]) > 0)
    total_losses = sum(1 for t in all_trades if Decimal(t["net_pnl"]) < 0)
    return {
        "mode": "historical_walk_forward_only",
        "strategy": config.strategy,
        "parameters_fixed_across_folds": True,
        "parameter_optimization_performed": False,
        "initial_train_candles": initial_train_size,
        "test_candles_per_fold": test_size,
        "fold_count": len(folds),
        "out_of_sample_candles": sum(f["test_candles"] for f in folds),
        "completed_oos_trades": len(all_trades),
        "oos_net_pnl_sum_independent_folds": str(total_pnl),
        "oos_win_rate_pct": str(Decimal(total_wins) / len(all_trades) * 100 if all_trades else Decimal(0)),
        "folds_with_positive_pnl": sum(1 for f in folds if Decimal(f["net_pnl"]) > 0),
        "folds_with_negative_pnl": sum(1 for f in folds if Decimal(f["net_pnl"]) < 0),
        "folds": folds,
        "trades": all_trades,
        "interpretation_warning": (
            "Fixed-parameter walk-forward diagnostic only. No parameter optimization or selection was performed. "
            "Each fold has an independent balance; positions do not carry across folds. "
            "The summed PnL is not a compounded portfolio return. OHLCV slippage and intrabar path remain approximate."
        ),
    }
