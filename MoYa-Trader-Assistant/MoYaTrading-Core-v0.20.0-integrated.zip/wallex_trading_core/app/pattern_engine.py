"""Causal OHLCV pattern detection for research and paper trading.

A pivot is emitted only after `right_bars` candles have closed. No future
candle is used to make a decision at the current candle index.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from typing import Sequence

from .market_data import Candle

D = Decimal

class PatternDetectionError(ValueError):
    pass

@dataclass(frozen=True, slots=True)
class PatternConfig:
    pivot_left: int = 3
    pivot_right: int = 3
    atr_period: int = 14
    volume_period: int = 20
    tolerance_atr: Decimal = D("0.6")
    volume_spike_ratio: Decimal = D("1.8")

    def validate(self) -> None:
        if self.pivot_left < 1 or self.pivot_right < 1:
            raise PatternDetectionError("Pivot windows must be positive")
        if self.atr_period < 2 or self.volume_period < 2:
            raise PatternDetectionError("Indicator periods must be at least 2")
        if self.tolerance_atr <= 0 or self.volume_spike_ratio <= 1:
            raise PatternDetectionError("Pattern thresholds are invalid")


def _validate(candles: Sequence[Candle]) -> None:
    if len(candles) < 5:
        raise PatternDetectionError("At least 5 candles are required")
    if len(candles) > 100_000:
        raise PatternDetectionError("Maximum 100,000 candles per detection")
    for i, c in enumerate(candles):
        if i and c.timestamp <= candles[i-1].timestamp:
            raise PatternDetectionError("Candles must be strictly chronological")
        if min(c.open, c.high, c.low, c.close) <= 0 or c.volume < 0:
            raise PatternDetectionError("Invalid candle values")
        if c.high < max(c.open, c.low, c.close) or c.low > min(c.open, c.high, c.close):
            raise PatternDetectionError("Invalid OHLC range")


def _atr(candles: Sequence[Candle], period: int) -> Decimal | None:
    if len(candles) < period + 1:
        return None
    trs = []
    for i in range(1, len(candles)):
        c, p = candles[i], candles[i-1]
        trs.append(max(c.high-c.low, abs(c.high-p.close), abs(c.low-p.close)))
    return sum(trs[-period:], D(0)) / D(period)


def _confirmed_pivots(candles: Sequence[Candle], left: int, right: int):
    """Return pivots as (kind, source_index, confirmed_index, price)."""
    out = []
    for i in range(left, len(candles)-right):
        window = candles[i-left:i+right+1]
        hi, lo = candles[i].high, candles[i].low
        # Strict centre extremum prevents flat plateaus from creating many pivots.
        if hi == max(x.high for x in window) and sum(x.high == hi for x in window) == 1:
            out.append(("high", i, i+right, hi))
        if lo == min(x.low for x in window) and sum(x.low == lo for x in window) == 1:
            out.append(("low", i, i+right, lo))
    return out


def detect_patterns(candles: Sequence[Candle], config: PatternConfig | None = None) -> dict:
    """Detect supported base patterns using only closed candles in the prefix."""
    cfg = config or PatternConfig(); cfg.validate(); _validate(candles)
    n = len(candles); cur = candles[-1]; atr = _atr(candles, cfg.atr_period)
    tol = (atr or cur.close * D("0.005")) * cfg.tolerance_atr
    pivots = _confirmed_pivots(candles, cfg.pivot_left, cfg.pivot_right)
    # A pivot can only participate after its confirmation candle has closed.
    pivots = [p for p in pivots if p[2] < n]
    highs = [p for p in pivots if p[0] == "high"]
    lows = [p for p in pivots if p[0] == "low"]
    found = []

    def add(pid, slug, direction, score, evidence, confirmation="closed_candle"):
        found.append({"pattern_id":pid,"pattern":slug,"name":slug.replace("_", " ").title(),"direction":direction,
                      "score":int(max(0,min(100,score))),"confidence":"heuristic_not_probability",
                      "confirmed_at":cur.timestamp,"confirmation":confirmation,"evidence":evidence})

    # Candlestick patterns: evaluated only on the last fully closed candle.
    body = abs(cur.close-cur.open); rng = cur.high-cur.low
    prev = candles[-2]
    prev_body = abs(prev.close-prev.open)
    upper = cur.high-max(cur.open,cur.close); lower = min(cur.open,cur.close)-cur.low
    if cur.close > cur.open and prev.close < prev.open and cur.open <= prev.close and cur.close >= prev.open:
        add("PAT-CANDLE-001","bullish_engulfing","bullish",65,{"body_ratio":str(body/rng if rng else D(0))})
    if cur.close < cur.open and prev.close > prev.open and cur.open >= prev.close and cur.close <= prev.open:
        add("PAT-CANDLE-002","bearish_engulfing","bearish",65,{"body_ratio":str(body/rng if rng else D(0))})
    if rng > 0 and lower >= body*2 and upper <= max(body, rng*D("0.15")) and cur.close >= cur.low+rng*D("0.6"):
        add("PAT-CANDLE-003","hammer","bullish",55,{"lower_shadow_to_body":str(lower/max(body,D("0.00000001")))})
    if rng > 0 and upper >= body*2 and lower <= max(body,rng*D("0.15")) and cur.close <= cur.low+rng*D("0.4"):
        add("PAT-CANDLE-004","shooting_star","bearish",55,{"upper_shadow_to_body":str(upper/max(body,D("0.00000001")))})
    if rng > 0 and body/rng <= D("0.1"):
        add("PAT-CANDLE-005","doji","neutral",45,{"body_to_range":str(body/rng)})

    # Trend structure from the latest confirmed alternating swing points.
    swings = sorted(pivots, key=lambda p:p[2])
    if len(swings) >= 4:
        last = swings[-4:]
        if [p[0] for p in last] in (["low","high","low","high"],["high","low","high","low"]):
            hs=[p[3] for p in last if p[0]=="high"]; ls=[p[3] for p in last if p[0]=="low"]
            if len(hs)==2 and len(ls)==2 and hs[1]>hs[0] and ls[1]>ls[0]:
                add("PAT-TREND-001","higher_high_higher_low","bullish",70,{"swing_highs":list(map(str,hs)),"swing_lows":list(map(str,ls))},"confirmed_pivots")
            if len(hs)==2 and len(ls)==2 and hs[1]<hs[0] and ls[1]<ls[0]:
                add("PAT-TREND-002","lower_high_lower_low","bearish",70,{"swing_highs":list(map(str,hs)),"swing_lows":list(map(str,ls))},"confirmed_pivots")

    # Head-and-shoulders: five alternating confirmed pivots, neckline close required.
    if atr and len(swings) >= 5:
        seq = swings[-5:]
        kinds = [p[0] for p in seq]
        if kinds == ["high", "low", "high", "low", "high"]:
            left_shoulder, neck_a, head, neck_b, right_shoulder = [p[3] for p in seq]
            shoulders_close = abs(left_shoulder-right_shoulder) <= tol
            if head > max(left_shoulder,right_shoulder) and shoulders_close:
                neckline = (neck_a+neck_b)/D(2)
                if cur.close < neckline:
                    add("PAT-REV-001","head_and_shoulders","bearish",80,
                        {"left_shoulder":str(left_shoulder),"head":str(head),
                         "right_shoulder":str(right_shoulder),"neckline":str(neckline)},"neckline_close")
        elif kinds == ["low", "high", "low", "high", "low"]:
            left_shoulder, neck_a, head, neck_b, right_shoulder = [p[3] for p in seq]
            shoulders_close = abs(left_shoulder-right_shoulder) <= tol
            if head < min(left_shoulder,right_shoulder) and shoulders_close:
                neckline = (neck_a+neck_b)/D(2)
                if cur.close > neckline:
                    add("PAT-REV-002","inverse_head_and_shoulders","bullish",80,
                        {"left_shoulder":str(left_shoulder),"head":str(head),
                         "right_shoulder":str(right_shoulder),"neckline":str(neckline)},"neckline_close")

    # Double top / bottom from the last two confirmed pivots of the same type.
    if atr and len(highs)>=2:
        a,b=highs[-2:]
        if b[1]-a[1]>=cfg.pivot_left+cfg.pivot_right and abs(a[3]-b[3])<=tol:
            neck=min(c.low for c in candles[a[1]:b[1]+1])
            if cur.close < neck:
                add("PAT-REV-003","double_top","bearish",75,{"tops":[str(a[3]),str(b[3])],"neckline":str(neck)},"neckline_close")
    if atr and len(lows)>=2:
        a,b=lows[-2:]
        if b[1]-a[1]>=cfg.pivot_left+cfg.pivot_right and abs(a[3]-b[3])<=tol:
            neck=max(c.high for c in candles[a[1]:b[1]+1])
            if cur.close > neck:
                add("PAT-REV-004","double_bottom","bullish",75,{"bottoms":[str(a[3]),str(b[3])],"neckline":str(neck)},"neckline_close")


    # Additional swing-structure detectors. All pivots are confirmed before use.
    if atr:
        # Triple top / bottom: three comparable extrema with intervening rejection.
        if len(highs) >= 3:
            a,b,c = highs[-3:]
            if (b[1]-a[1] >= cfg.pivot_left+cfg.pivot_right and
                c[1]-b[1] >= cfg.pivot_left+cfg.pivot_right and
                max(a[3],b[3],c[3])-min(a[3],b[3],c[3]) <= tol):
                neck = min(x.low for x in candles[a[1]:c[1]+1])
                if cur.close < neck:
                    add("PAT-REV-005","triple_top","bearish",78,
                        {"tops":[str(a[3]),str(b[3]),str(c[3])],"neckline":str(neck)},"neckline_close")
        if len(lows) >= 3:
            a,b,c = lows[-3:]
            if (b[1]-a[1] >= cfg.pivot_left+cfg.pivot_right and
                c[1]-b[1] >= cfg.pivot_left+cfg.pivot_right and
                max(a[3],b[3],c[3])-min(a[3],b[3],c[3]) <= tol):
                neck = max(x.high for x in candles[a[1]:c[1]+1])
                if cur.close > neck:
                    add("PAT-REV-006","triple_bottom","bullish",78,
                        {"bottoms":[str(a[3]),str(b[3]),str(c[3])],"neckline":str(neck)},"neckline_close")

        # Consolidation after an impulse. This is a conservative flag/pennant candidate.
        if n >= 12:
            impulse = candles[-12:-6]
            consolidation = candles[-6:-1]
            impulse_move = impulse[-1].close - impulse[0].open
            impulse_range = max(x.high for x in impulse)-min(x.low for x in impulse)
            cons_high=max(x.high for x in consolidation); cons_low=min(x.low for x in consolidation)
            cons_range=cons_high-cons_low
            contracting = cons_range <= impulse_range * D("0.65")
            if impulse_range > 0 and contracting:
                if impulse_move > impulse_range*D("0.45") and cur.close > cons_high:
                    add("PAT-CONT-001","bull_flag","bullish",62,
                        {"impulse_move":str(impulse_move),"consolidation_range":str(cons_range)},"close_above_consolidation")
                elif impulse_move < -impulse_range*D("0.45") and cur.close < cons_low:
                    add("PAT-CONT-002","bear_flag","bearish",62,
                        {"impulse_move":str(impulse_move),"consolidation_range":str(cons_range)},"close_below_consolidation")
                # A pennant requires a contracting high/low envelope.
                highs_cons=[x.high for x in consolidation]; lows_cons=[x.low for x in consolidation]
                upper_contract=highs_cons[-1] < highs_cons[0]
                lower_contract=lows_cons[-1] > lows_cons[0]
                if upper_contract and lower_contract and impulse_move > impulse_range*D("0.45") and cur.close > cons_high:
                    add("PAT-CONT-003","bull_pennant","bullish",64,{"consolidation_range":str(cons_range)},"close_above_pennant")
                elif upper_contract and lower_contract and impulse_move < -impulse_range*D("0.45") and cur.close < cons_low:
                    add("PAT-CONT-004","bear_pennant","bearish",64,{"consolidation_range":str(cons_range)},"close_below_pennant")

        # Three-point boundary geometry for triangles and rectangles.
        if len(highs) >= 3 and len(lows) >= 3:
            h3=highs[-3:]; l3=lows[-3:]
            hflat=max(x[3] for x in h3)-min(x[3] for x in h3) <= tol
            lflat=max(x[3] for x in l3)-min(x[3] for x in l3) <= tol
            falling= h3[0][3] > h3[1][3] > h3[2][3]
            rising= l3[0][3] < l3[1][3] < l3[2][3]
            if hflat and rising and cur.close > max(x[3] for x in h3):
                add("PAT-CONT-005","ascending_triangle","bullish",68,{"resistance":str(sum((x[3] for x in h3),D(0))/3)},"resistance_break")
            elif lflat and falling and cur.close < min(x[3] for x in l3):
                add("PAT-CONT-006","descending_triangle","bearish",68,{"support":str(sum((x[3] for x in l3),D(0))/3)},"support_break")
            elif falling and rising and cur.close > max(x[3] for x in h3):
                add("PAT-CONT-007","symmetrical_triangle","bullish",60,{"boundary":"contracting"},"upper_boundary_break")
            elif falling and rising and cur.close < min(x[3] for x in l3):
                add("PAT-CONT-007","symmetrical_triangle","bearish",60,{"boundary":"contracting"},"lower_boundary_break")
            elif hflat and lflat and cur.close > max(x[3] for x in h3):
                add("PAT-CONT-008","rectangle_range","bullish",60,{"range_high":str(max(x[3] for x in h3))},"range_break")
            elif hflat and lflat and cur.close < min(x[3] for x in l3):
                add("PAT-CONT-008","rectangle_range","bearish",60,{"range_low":str(min(x[3] for x in l3))},"range_break")

        # Cup-and-handle approximation from confirmed low-high-low pivots.
        if len(lows) >= 2 and len(highs) >= 1:
            left = lows[-2]; middle_candidates=[h for h in highs if left[1] < h[1] < lows[-1][1]]
            right = lows[-1]
            if middle_candidates:
                rim = middle_candidates[-1][3]
                depth = rim - min(left[3],right[3])
                handle = min(x.low for x in candles[max(0,n-5):-1])
                if (abs(left[3]-right[3]) <= tol and depth > tol and
                    handle >= right[3] and cur.close > rim):
                    add("PAT-CONT-009","cup_and_handle","bullish",65,
                        {"left_rim":str(left[3]),"right_rim":str(right[3]),"cup_depth":str(depth)},"rim_breakout")

        # Trendline break: line through the last two confirmed pivots.
        for pts, kind, direction in ((highs,"resistance","bullish"),(lows,"support","bearish")):
            if len(pts) >= 2:
                a,b=pts[-2:]
                if b[1] > a[1]:
                    slope=(b[3]-a[3])/D(b[1]-a[1])
                    projected=b[3]+slope*D((n-1)-b[1])
                    crossed=(cur.close > projected) if kind=="resistance" else (cur.close < projected)
                    if crossed and ((kind=="resistance" and slope < 0) or (kind=="support" and slope > 0)):
                        add("PAT-TREND-003","trendline_break",direction,62,
                            {"line_type":kind,"projected_level":str(projected),"slope_per_candle":str(slope)},"closed_candle_cross")

        # Range-to-trend: prior compressed range followed by a close outside it.
        prior_window=candles[-11:-1]
        if len(prior_window) >= 8:
            prior_width=max(x.high for x in prior_window)-min(x.low for x in prior_window)
            if prior_width <= cur.close*D("0.04"):
                if cur.close > max(x.high for x in prior_window):
                    add("PAT-TREND-004","range_to_trend_transition","bullish",60,
                        {"prior_range_width":str(prior_width)},"range_escape")
                elif cur.close < min(x.low for x in prior_window):
                    add("PAT-TREND-004","range_to_trend_transition","bearish",60,
                        {"prior_range_width":str(prior_width)},"range_escape")

    # Breakout / breakdown against the preceding range (current candle excluded).
    lookback=min(20,n-2); prior=candles[-lookback-2:-2]
    resistance=max(c.high for c in prior); support=min(c.low for c in prior)
    if prev.close > resistance and cur.close <= resistance:
        add("PAT-BRK-003","false_breakout","neutral",60,{"resistance":str(resistance),"reentry_close":str(cur.close)},"close_back_inside_range")
    elif prev.close < support and cur.close >= support:
        add("PAT-BRK-003","false_breakout","neutral",60,{"support":str(support),"reentry_close":str(cur.close)},"close_back_inside_range")
    elif cur.close > resistance:
        add("PAT-BRK-001","breakout","bullish",65,{"resistance":str(resistance),"close":str(cur.close)},"close_outside_prior_range")
    elif cur.close < support:
        add("PAT-BRK-002","breakdown","bearish",65,{"support":str(support),"close":str(cur.close)},"close_outside_prior_range")

    # Relative volume spike. Neutral until price context supplies direction.
    vol_window=candles[-min(cfg.volume_period+1,n):-1]
    avg_vol=sum((c.volume for c in vol_window),D(0))/D(len(vol_window)) if vol_window else D(0)
    vol_ratio=cur.volume/avg_vol if avg_vol>0 else None
    if vol_ratio is not None and vol_ratio >= cfg.volume_spike_ratio:
        add("PAT-VOL-001","volume_spike","neutral",60,{"relative_volume":str(vol_ratio),"threshold":str(cfg.volume_spike_ratio)})

    # Price/volume divergence: only a contextual warning, not a reversal signal.
    if len(candles)>=10:
        prior_slice=candles[-10:-1]
        old_high=max(c.high for c in prior_slice); old_low=min(c.low for c in prior_slice)
        old_vol=sum((c.volume for c in prior_slice),D(0))/D(len(prior_slice))
        if cur.high>old_high and avg_vol>0 and cur.volume<old_vol:
            add("PAT-VOL-002","price_volume_divergence","bearish",50,{"context":"higher_high_without_volume_confirmation"})
        elif cur.low<old_low and avg_vol>0 and cur.volume<old_vol:
            add("PAT-VOL-002","price_volume_divergence","bullish",50,{"context":"lower_low_without_volume_confirmation"})

    return {"engine":"moya_pattern_engine_v1","mode":"research_only_no_order_execution",
            "candle_count":n,"last_candle_timestamp":cur.timestamp,
            "patterns_detected":found,"pattern_count":len(found),
            "detector_coverage":{"implemented":["head_and_shoulders","inverse_head_and_shoulders","double_top","double_bottom","triple_top","triple_bottom","bull_flag","bear_flag","bull_pennant","bear_pennant","ascending_triangle","descending_triangle","symmetrical_triangle","rectangle_range","cup_and_handle","higher_high_higher_low","lower_high_lower_low","trendline_break","range_to_trend_transition","bullish_engulfing","bearish_engulfing","hammer","shooting_star","doji","volume_spike","price_volume_divergence","breakout","breakdown","false_breakout"],"library_only_not_yet_detected":[]},
            "safety":{"uses_future_data_for_detection":False,"requires_closed_candles":True,"live_trading_enabled":False},
            "warnings":["Pattern scores are heuristic rankings, not calibrated probabilities.","Patterns are candidates only and must be evaluated out of sample with fees and slippage.","Bearish patterns in spot markets are risk warnings, not short-entry instructions."]}
