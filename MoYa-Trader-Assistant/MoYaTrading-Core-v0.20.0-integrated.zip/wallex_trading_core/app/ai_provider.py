from typing import Protocol, Any

class AIProvider(Protocol):
    async def analyze_market_snapshot(self, snapshot: dict[str, Any]) -> dict[str, Any]:
        ...

class DisabledAIProvider:
    async def analyze_market_snapshot(self, snapshot: dict[str, Any]) -> dict[str, Any]:
        return {
            "enabled": False,
            "status": "not_configured",
            "message": "AI connection is not configured. No market decision was generated.",
        }
