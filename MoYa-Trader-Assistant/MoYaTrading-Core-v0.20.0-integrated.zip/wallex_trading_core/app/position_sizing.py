"""Conservative, exchange-agnostic position sizing for paper/research use.

This module does not place orders and does not model Wallex margin rules.
All monetary inputs must use the same quote currency.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, ROUND_DOWN
from enum import Enum


class SizingError(ValueError):
    pass


class Side(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"


def dec(value: Decimal | str | int, name: str) -> Decimal:
    try:
        out = Decimal(str(value))
    except Exception as exc:
        raise SizingError(f"Invalid {name}") from exc
    if not out.is_finite():
        raise SizingError(f"Invalid {name}")
    return out


@dataclass(frozen=True)
class SizingRequest:
    side: Side
    equity: Decimal
    risk_fraction: Decimal
    entry_price: Decimal
    stop_price: Decimal
    available_collateral: Decimal
    max_leverage: Decimal
    max_notional: Decimal
    current_exposure: Decimal = Decimal("0")
    max_total_exposure: Decimal = Decimal("0")
    liquidity_quantity_cap: Decimal = Decimal("0")
    fee_rate: Decimal = Decimal("0")
    financing_cost_per_unit: Decimal = Decimal("0")
    quantity_step: Decimal = Decimal("0.00000001")
    minimum_quantity: Decimal = Decimal("0")
    minimum_notional: Decimal = Decimal("0")
    liquidation_price: Decimal | None = None


@dataclass(frozen=True)
class SizingDecision:
    accepted: bool
    quantity: Decimal
    risk_budget: Decimal
    estimated_loss_at_stop: Decimal
    notional: Decimal
    collateral_required: Decimal
    limiting_factor: str
    reason: str | None = None


def size_position(req: SizingRequest) -> SizingDecision:
    side = Side(req.side)
    vals = {k: dec(v, k) for k, v in {
        "equity": req.equity, "risk_fraction": req.risk_fraction,
        "entry_price": req.entry_price, "stop_price": req.stop_price,
        "available_collateral": req.available_collateral, "max_leverage": req.max_leverage,
        "max_notional": req.max_notional, "current_exposure": req.current_exposure,
        "max_total_exposure": req.max_total_exposure,
        "liquidity_quantity_cap": req.liquidity_quantity_cap,
        "fee_rate": req.fee_rate, "financing_cost_per_unit": req.financing_cost_per_unit,
        "quantity_step": req.quantity_step, "minimum_quantity": req.minimum_quantity,
        "minimum_notional": req.minimum_notional,
    }.items()}
    equity, risk_fraction = vals["equity"], vals["risk_fraction"]
    entry, stop = vals["entry_price"], vals["stop_price"]
    collateral, leverage = vals["available_collateral"], vals["max_leverage"]
    if equity <= 0 or not (0 < risk_fraction < 1) or entry <= 0 or stop <= 0:
        raise SizingError("Equity, prices and risk fraction must be valid")
    if (side == Side.LONG and stop >= entry) or (side == Side.SHORT and stop <= entry):
        raise SizingError("Stop price is on the wrong side of entry")
    if leverage < 1 or collateral < 0 or vals["max_notional"] <= 0:
        raise SizingError("Invalid leverage, collateral or notional cap")
    if vals["fee_rate"] < 0 or vals["fee_rate"] >= 1 or vals["financing_cost_per_unit"] < 0:
        raise SizingError("Invalid estimated costs")
    step = vals["quantity_step"]
    if step <= 0:
        raise SizingError("Quantity step must be positive")

    liq = req.liquidation_price
    if liq is not None:
        liq = dec(liq, "liquidation_price")
        if liq <= 0 or (side == Side.LONG and liq >= stop) or (side == Side.SHORT and liq <= stop):
            return SizingDecision(False, Decimal(0), equity*risk_fraction, Decimal(0), Decimal(0), Decimal(0), "liquidation_buffer", "Liquidation may occur before the stop")

    risk_budget = equity * risk_fraction
    # Include estimated entry+exit fees and a supplied per-unit financing reserve.
    per_unit_risk = abs(entry-stop) + (entry+stop)*vals["fee_rate"] + vals["financing_cost_per_unit"]
    if per_unit_risk <= 0:
        raise SizingError("Per-unit risk must be positive")
    risk_qty = risk_budget / per_unit_risk
    caps = {
        "risk_budget": risk_qty,
        "max_notional": vals["max_notional"] / entry,
        "collateral": (collateral * leverage) / entry,
    }
    remaining_exposure = vals["max_total_exposure"] - vals["current_exposure"]
    if vals["max_total_exposure"] > 0:
        caps["total_exposure"] = max(Decimal(0), remaining_exposure) / entry
    if vals["liquidity_quantity_cap"] > 0:
        caps["liquidity"] = vals["liquidity_quantity_cap"]
    limiting_factor, raw_qty = min(caps.items(), key=lambda item: item[1])
    qty = (raw_qty / step).to_integral_value(rounding=ROUND_DOWN) * step
    notional = qty * entry
    estimated_loss = qty * per_unit_risk
    collateral_required = notional / leverage
    if qty < vals["minimum_quantity"] or notional < vals["minimum_notional"] or qty <= 0:
        return SizingDecision(False, Decimal(0), risk_budget, Decimal(0), Decimal(0), Decimal(0), limiting_factor, "Size is below exchange minimums")
    if estimated_loss > risk_budget:
        return SizingDecision(False, Decimal(0), risk_budget, Decimal(0), Decimal(0), Decimal(0), limiting_factor, "Rounded size exceeds risk budget")
    return SizingDecision(True, qty, risk_budget, estimated_loss, notional, collateral_required, limiting_factor)
