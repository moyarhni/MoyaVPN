"""Bounded historical candle download and persistence for research backtests."""
from __future__ import annotations
import asyncio
from decimal import Decimal
from sqlalchemy import select
from sqlalchemy.orm import Session
from .db import HistoricalCandle
from .market_data import Candle, normalize_udf_candles, MarketDataError
from .wallex import WallexClient, WallexAPIError

# Wallex UDF has no pagination. Conservative chunk sizes reduce oversized requests.
RESOLUTION_CHUNK_SECONDS = {"1": 10 * 86400, "60": 180 * 86400, "1D": 365 * 86400}
MAX_RANGE_SECONDS = {"1": 90 * 86400, "60": 3 * 365 * 86400, "1D": 10 * 365 * 86400}

class HistoricalDataError(ValueError):
    pass

async def download_and_store(db: Session, client: WallexClient, symbol: str,
                             resolution: str, start: int, end: int) -> dict:
    symbol = symbol.strip().upper()
    if not symbol or len(symbol) > 24 or not symbol.replace("_", "").isalnum():
        raise HistoricalDataError("Invalid symbol")
    if resolution not in RESOLUTION_CHUNK_SECONDS:
        raise HistoricalDataError("Supported resolutions are 1 (1m), 60 (1h), and 1D (1d)")
    if start <= 0 or end <= start:
        raise HistoricalDataError("Invalid time range")
    if end - start > MAX_RANGE_SECONDS[resolution]:
        raise HistoricalDataError("Requested range is too large for one sync operation")

    fetched: dict[int, Candle] = {}
    cursor = start
    while cursor < end:
        chunk_end = min(cursor + RESOLUTION_CHUNK_SECONDS[resolution], end)
        raw = await client.candles(symbol, resolution, cursor, chunk_end)
        try:
            candles = normalize_udf_candles(raw)
        except MarketDataError as exc:
            raise HistoricalDataError(f"Invalid exchange candle data: {exc}") from exc
        for candle in candles:
            if start <= candle.timestamp < end:
                fetched[candle.timestamp] = candle
        cursor = chunk_end
        if cursor < end:
            await asyncio.sleep(0.25)

    inserted = updated = 0
    for candle in sorted(fetched.values(), key=lambda c: c.timestamp):
        row = db.scalar(select(HistoricalCandle).where(
            HistoricalCandle.symbol == symbol,
            HistoricalCandle.resolution == resolution,
            HistoricalCandle.timestamp == candle.timestamp,
        ))
        if row is None:
            row = HistoricalCandle(symbol=symbol, resolution=resolution,
                timestamp=candle.timestamp, open=str(candle.open), high=str(candle.high),
                low=str(candle.low), close=str(candle.close), volume=str(candle.volume))
            db.add(row); inserted += 1
        else:
            row.open, row.high, row.low = str(candle.open), str(candle.high), str(candle.low)
            row.close, row.volume = str(candle.close), str(candle.volume)
            updated += 1
    db.commit()
    return {"symbol": symbol, "resolution": resolution, "fetched": len(fetched),
            "inserted": inserted, "updated": updated, "start": start, "end": end}

def load_stored_candles(db: Session, symbol: str, resolution: str,
                        start: int, end: int) -> list[Candle]:
    rows = db.scalars(select(HistoricalCandle).where(
        HistoricalCandle.symbol == symbol.upper(),
        HistoricalCandle.resolution == resolution,
        HistoricalCandle.timestamp >= start,
        HistoricalCandle.timestamp < end,
    ).order_by(HistoricalCandle.timestamp)).all()
    return [Candle(r.timestamp, Decimal(r.open), Decimal(r.high), Decimal(r.low),
                    Decimal(r.close), Decimal(r.volume)) for r in rows]
