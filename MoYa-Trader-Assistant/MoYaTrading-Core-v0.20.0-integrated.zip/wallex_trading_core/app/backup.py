"""SQLite online backup utility; caller chooses and protects destination path."""
from pathlib import Path
import sqlite3
from .config import settings

def backup_database(destination: str) -> dict:
    if not settings.database_url.startswith('sqlite:///'):
        raise RuntimeError('Built-in backup supports SQLite URLs only')
    source_path = Path(settings.database_url.removeprefix('sqlite:///')).resolve()
    target = Path(destination).expanduser().resolve()
    if source_path == target: raise ValueError('Backup destination must differ from source')
    target.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(source_path) as src, sqlite3.connect(target) as dst:
        src.backup(dst)
    return {'created': target.exists(), 'path': str(target), 'bytes': target.stat().st_size}
