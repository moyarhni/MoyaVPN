"""Transparent, deterministic two-sided market analysis (research-only).

Consumes fully closed OHLCV candles only. It does not place orders and does
not claim profitability. All calculations use Decimal to avoid float drift.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from typing import Sequence

from .market_data import Candle


class SignalAnalysisError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class SignalConfig:
    fast_ema: int = 9
    slow_ema: int = 21
    rsi_period: int = 14
    atr_period: int = 14
    breakout_period: int = 20
    min_atr_pct: Decimal = Decimal("0.001")
    max_atr_pct: Decimal = Decimal("0.05")
    min_score: int = 55
    min_score_gap: int = 15
    stop_atr_multiple: Decimal = Decimal("1.5")
    reward_risk_ratio: Decimal = Decimal("2")

    def validate(self) -> None:
        if self.fast_ema < 2 or self.slow_ema <= self.fast_ema:
            raise SignalAnalysisError("Require 2 <= fast_ema < slow_ema")
        if min(self.rsi_period, self.atr_period, self.breakout_period) < 2:
            raise SignalAnalysisError("Indicator periods must be at least 2")
        if not 0 <= self.min_score <= 100 or not 0 <= self.min_score_gap <= 100:
            raise SignalAnalysisError("Score thresholds must be between 0 and 100")
        if self.min_atr_pct <= 0 or self.max_atr_pct <= self.min_atr_pct:
            raise SignalAnalysisError("Invalid ATR percentage range")
        if self.stop_atr_multiple <= 0 or self.reward_risk_ratio <= 0:
            raise SignalAnalysisError("Stop and reward/risk multipliers must be positive")


def _ema(values: Sequence[Decimal], period: int) -> list[Decimal]:
    alpha = Decimal(2) / Decimal(period + 1)
    out: list[Decimal] = []
    for i, value in enumerate(values):
        out.append(value if i == 0 else alpha * value + (Decimal(1) - alpha) * out[-1])
    return out


def _rsi(values: Sequence[Decimal], period: int) -> Decimal:
    gains: list[Decimal] = []
    losses: list[Decimal] = []
    for previous, current in zip(values[-period-1:-1], values[-period:]):
        change = current - previous
        gains.append(max(change, Decimal(0)))
        losses.append(max(-change, Decimal(0)))
    avg_gain = sum(gains, Decimal(0)) / Decimal(period)
    avg_loss = sum(losses, Decimal(0)) / Decimal(period)
    if avg_loss == 0:
        return Decimal(100) if avg_gain > 0 else Decimal(50)
    rs = avg_gain / avg_loss
    return Decimal(100) - Decimal(100) / (Decimal(1) + rs)


def _atr(candles: Sequence[Candle], period: int) -> Decimal:
    true_ranges: list[Decimal] = []
    for i in range(1, len(candles)):
        c, previous = candles[i], candles[i-1]
        true_ranges.append(max(c.high - c.low, abs(c.high - previous.close), abs(c.low - previous.close)))
    window = true_ranges[-period:]
    if len(window) < period:
        raise SignalAnalysisError("Not enough candles for ATR")
    return sum(window, Decimal(0)) / Decimal(period)


def analyze_closed_candles(candles: Sequence[Candle], config: SignalConfig | None = None) -> dict:
    """Return LONG, SHORT or NO_TRADE with transparent indicator evidence."""
    cfg = config or SignalConfig()
    cfg.validate()
    minimum = max(cfg.slow_ema + 2, cfg.rsi_period + 2, cfg.atr_period + 2, cfg.breakout_period + 1)
    if len(candles) < minimum:
        raise SignalAnalysisError(f"Need at least {minimum} closed candles")
    if len(candles) > 100_000:
        raise SignalAnalysisError("Maximum 100,000 candles per analysis")
    for i, candle in enumerate(candles):
        if i and candle.timestamp <= candles[i-1].timestamp:
            raise SignalAnalysisError("Candles must be strictly chronological")
        if min(candle.open, candle.high, candle.low, candle.close) <= 0 or candle.volume < 0:
            raise SignalAnalysisError("Candle prices must be positive and volume non-negative")
        if candle.high < max(candle.open, candle.low, candle.close) or candle.low > min(candle.open, candle.high, candle.close):
            raise SignalAnalysisError("Invalid OHLC range")

    closes = [c.close for c in candles]
    fast = _ema(closes, cfg.fast_ema)
    slow = _ema(closes, cfg.slow_ema)
    current = candles[-1]
    rsi = _rsi(closes, cfg.rsi_period)
    atr = _atr(candles, cfg.atr_period)
    atr_pct = atr / current.close
    prior = candles[-cfg.breakout_period-1:-1]
    prior_high = max(c.high for c in prior)
    prior_low = min(c.low for c in prior)

    long_score = 0
    short_score = 0
    long_reasons: list[str] = []
    short_reasons: list[str] = []

    if fast[-1] > slow[-1]:
        long_score += 25; long_reasons.append("EMA fast is above EMA slow")
    elif fast[-1] < slow[-1]:
        short_score += 25; short_reasons.append("EMA fast is below EMA slow")
    if current.close > slow[-1]:
        long_score += 15; long_reasons.append("Close is above slow EMA")
    elif current.close < slow[-1]:
        short_score += 15; short_reasons.append("Close is below slow EMA")
    if fast[-1] > fast[-2] and slow[-1] > slow[-2]:
        long_score += 10; long_reasons.append("Both EMAs are rising")
    elif fast[-1] < fast[-2] and slow[-1] < slow[-2]:
        short_score += 10; short_reasons.append("Both EMAs are falling")

    if Decimal(50) < rsi < Decimal(70):
        long_score += 20; long_reasons.append("RSI supports bullish momentum without an extreme reading")
    elif Decimal(30) < rsi < Decimal(50):
        short_score += 20; short_reasons.append("RSI supports bearish momentum without an extreme reading")

    if current.close > prior_high:
        long_score += 20; long_reasons.append("Close broke above the prior range")
    elif current.close < prior_low:
        short_score += 20; short_reasons.append("Close broke below the prior range")

    avg_volume = sum((c.volume for c in prior), Decimal(0)) / Decimal(len(prior))
    volume_ratio = current.volume / avg_volume if avg_volume > 0 else None
    if volume_ratio is not None and volume_ratio >= Decimal("1.2"):
        if current.close > prior_high:
            long_score += 10; long_reasons.append("Upside breakout has above-average volume")
        elif current.close < prior_low:
            short_score += 10; short_reasons.append("Downside breakout has above-average volume")

    volatility_ok = cfg.min_atr_pct <= atr_pct <= cfg.max_atr_pct
    gap = abs(long_score - short_score)
    if not volatility_ok:
        signal = "NO_TRADE"
        decision_reason = "Volatility is outside the configured safe analysis range"
    elif max(long_score, short_score) < cfg.min_score:
        signal = "NO_TRADE"
        decision_reason = "Neither direction reached the minimum score"
    elif gap < cfg.min_score_gap:
        signal = "NO_TRADE"
        decision_reason = "Directional scores are too close"
    else:
        signal = "LONG" if long_score > short_score else "SHORT"
        decision_reason = "Directional score and volatility filters passed"

    stop_price = target_price = None
    if signal == "LONG":
        stop_price = current.close - cfg.stop_atr_multiple * atr
        target_price = current.close + cfg.stop_atr_multiple * atr * cfg.reward_risk_ratio
    elif signal == "SHORT":
        stop_price = current.close + cfg.stop_atr_multiple * atr
        target_price = current.close - cfg.stop_atr_multiple * atr * cfg.reward_risk_ratio

    return {
        "engine": "trend_momentum_v1",
        "mode": "research_only_no_order_execution",
        "signal": signal,
        "scores": {"long": long_score, "short": short_score},
        "confidence_pct": max(long_score, short_score),
        "decision_reason": decision_reason,
        "evidence": {
            "last_candle_timestamp": current.timestamp,
            "last_close": str(current.close),
            "ema_fast": str(fast[-1]), "ema_slow": str(slow[-1]),
            "rsi": str(rsi), "atr": str(atr), "atr_pct": str(atr_pct),
            "volume_ratio": str(volume_ratio) if volume_ratio is not None else None,
            "prior_range_high": str(prior_high), "prior_range_low": str(prior_low),
            "volatility_filter_passed": volatility_ok,
        },
        "long_reasons": long_reasons,
        "short_reasons": short_reasons,
        "reference_stop": str(stop_price) if stop_price is not None else None,
        "reference_target": str(target_price) if target_price is not None else None,
        "assumptions": [
            "All supplied candles must be fully closed; the engine cannot verify exchange candle finality.",
            "Scores are rule weights, not statistically calibrated probabilities.",
            "Reference stop and target are ATR-based research levels, not exchange orders.",
            "This is not a validated profitable strategy and does not place orders.",
        ],
    }
