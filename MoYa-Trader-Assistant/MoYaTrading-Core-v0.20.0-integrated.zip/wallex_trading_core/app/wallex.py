from __future__ import annotations
import httpx
from .config import settings

class WallexAPIError(RuntimeError):
    pass

class WallexClient:
    """Public, read-only Wallex market-data client. No account or order methods."""
    def __init__(self, base_url: str | None = None, timeout: float | None = None):
        self.client = httpx.AsyncClient(
            base_url=(base_url or settings.wallex_base_url).rstrip("/"),
            timeout=timeout or settings.request_timeout_seconds,
            headers={"Accept": "application/json", "User-Agent": "WallexTradingCore/0.2"},
        )

    async def close(self):
        await self.client.aclose()

    async def _get(self, path: str, params: dict | None = None):
        try:
            response = await self.client.get(path, params=params)
            response.raise_for_status()
            data = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise WallexAPIError(f"Wallex request failed: {type(exc).__name__}") from exc
        if isinstance(data, dict) and data.get("success") is False:
            raise WallexAPIError(str(data.get("message", "Wallex returned unsuccessful response")))
        if not isinstance(data, dict):
            raise WallexAPIError("Unexpected Wallex response type")
        return data

    async def markets(self):
        return await self._get("/v1/markets")

    async def depth(self, symbol: str):
        return await self._get("/v1/depth", {"symbol": symbol.upper()})

    async def trades(self, symbol: str):
        return await self._get("/v1/trades", {"symbol": symbol.upper()})

    async def udf_config(self):
        return await self._get("/v1/udf/config")

    async def udf_symbol(self, symbol: str):
        return await self._get("/v1/udf/symbols", {"symbol": symbol.upper()})

    async def candles(self, symbol: str, resolution: str, start: int, end: int):
        if start >= end:
            raise ValueError("start must be earlier than end")
        return await self._get("/v1/udf/history", {
            "symbol": symbol.upper(), "resolution": resolution, "from": start, "to": end
        })
