from dataclasses import dataclass
from decimal import Decimal
from enum import Enum

class Direction(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"

@dataclass(frozen=True)
class TradeIntent:
    symbol: str
    direction: Direction
    quantity: Decimal
    reference_price: Decimal


def validate_trade_intent(intent: TradeIntent) -> None:
    if not intent.symbol or not intent.symbol.strip():
        raise ValueError("symbol is required")
    if intent.quantity <= 0 or intent.reference_price <= 0:
        raise ValueError("quantity and reference_price must be positive")

class EntryCircuitBreaker:
    """Pauses NEW entries after the first realized losing trade.

    This does not close or disable management of existing positions.
    State persistence is intentionally not implemented in this module yet.
    """
    def __init__(self):
        self.paused = False
        self.reason: str | None = None

    def on_trade_closed(self, realized_pnl: Decimal) -> None:
        if realized_pnl < 0:
            self.paused = True
            self.reason = "first_realized_loss"

    def can_open_new_position(self) -> bool:
        return not self.paused
