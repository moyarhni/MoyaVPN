import asyncio, json, logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from decimal import Decimal
from sqlalchemy import select, desc
from .config import settings
from .db import init_db, SessionLocal, MarketEvent, SystemEvent
from .wallex import WallexClient, WallexAPIError
from .collector import MarketCollector
from .market_data import normalize_udf_candles, MarketDataError, Candle
from .backtest import BacktestConfig, BacktestError, run_sma_backtest
from .signal_engine import analyze_closed_candles, SignalAnalysisError
from .pattern_engine import detect_patterns, PatternConfig, PatternDetectionError
from .decision_engine import make_decision
from . import pattern_memory as _pattern_memory
from .pattern_memory import record_observation, resolve_observation, pattern_memory_summary
from .historical import (download_and_store, load_stored_candles, HistoricalDataError)
from .walk_forward import evaluate_walk_forward, WalkForwardError
from .paper import simulate_market_fill, PaperSimulationError
from .paper_ledger import (PaperWallet, PaperPosition, PaperTrade, PaperLedgerError, initialize_wallet, open_position, close_position, wallet_snapshot)
from .security import ApiSecurityMiddleware
from .pattern_archive import PatternArchiveRecord, PatternAggregate, archive_pattern, find_similar_patterns, compact_resolved_observations
from .circuit_breaker import circuit_status

logging.basicConfig(level=logging.INFO)
client = WallexClient()
collector = MarketCollector(client)
async def collection_loop(stop_event: asyncio.Event):
    """Resilient public-data loop with bounded exponential backoff."""
    failures = 0
    while not stop_event.is_set():
        try:
            with SessionLocal() as db:
                result = await collector.collect_once(db)
            failures = 0 if result.get("ok") else min(failures + 1, 6)
            delay = max(5, settings.poll_seconds) if failures == 0 else min(300, max(5, settings.poll_seconds) * (2 ** failures))
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            failures = min(failures + 1, 6)
            collector.last_error = f"{type(exc).__name__}: {exc}"
            logging.exception("Market collection cycle crashed")
            delay = min(300, max(5, settings.poll_seconds) * (2 ** failures))
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=delay)
        except asyncio.TimeoutError:
            continue

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    stop_event = asyncio.Event()
    task = asyncio.create_task(collection_loop(stop_event))
    yield
    stop_event.set()
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass
    await client.close()

app = FastAPI(title="MoYaTrading Core", version="0.20.0",
    description="Research and paper-trading core. Live execution is disabled.", lifespan=lifespan)
app.add_middleware(ApiSecurityMiddleware)

@app.get("/health")
def health():
    return {"service":"wallex-trading-core", "version":"0.20.0",
        "mode":"public-data-only", "trading_enabled":False,
        "last_success_at":collector.last_success_at, "last_error":collector.last_error,
        "last_cycle":collector.last_cycle,
        "poll_seconds":settings.poll_seconds, "symbols":settings.symbol_list, "risk_circuit":circuit_status(),
        "live_trading_enabled":False}

@app.get("/markets")
def markets():
    return {"configured_symbols":settings.symbol_list,
        "found_symbols":{s:{"baseAsset":d.get("baseAsset"),"quoteAsset":d.get("quoteAsset"),
        "tickSize":d.get("tickSize"),"stepSize":d.get("stepSize"),"stats":d.get("stats",{})}
        for s,d in collector.known_symbols.items() if s in settings.symbol_list}}

@app.get("/snapshots")
def snapshots(limit: int = Query(30, ge=1, le=200), symbol: str | None = None):
    with SessionLocal() as db:
        stmt = select(MarketEvent).where(MarketEvent.event_type == "market_snapshot")
        if symbol: stmt = stmt.where(MarketEvent.symbol == symbol.upper())
        rows = db.scalars(stmt.order_by(desc(MarketEvent.id)).limit(limit)).all()
        return [{"symbol":r.symbol,"received_at":r.received_at.isoformat() if r.received_at else None,
            "data":json.loads(r.payload)} for r in rows]

@app.get("/market-data/config")
async def market_data_config():
    try:
        return await client.udf_config()
    except WallexAPIError as exc:
        raise HTTPException(status_code=502, detail=str(exc))

@app.get("/market-data/symbol/{symbol}")
async def market_data_symbol(symbol: str):
    try:
        return await client.udf_symbol(symbol)
    except WallexAPIError as exc:
        raise HTTPException(status_code=502, detail=str(exc))

@app.get("/candles/{symbol}")
async def candles(symbol: str, resolution: str, start: int, end: int):
    try:
        raw = await client.candles(symbol, resolution, start, end)
        normalized = normalize_udf_candles(raw)
        return {
            "symbol": symbol.upper(),
            "resolution": resolution,
            "count": len(normalized),
            "candles": [
                {"timestamp": c.timestamp, "open": str(c.open), "high": str(c.high),
                 "low": str(c.low), "close": str(c.close), "volume": str(c.volume)}
                for c in normalized
            ],
        }
    except MarketDataError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except WallexAPIError as exc:
        raise HTTPException(status_code=502, detail=str(exc))

class BacktestCandleInput(BaseModel):
    timestamp: int = Field(gt=0)
    open: Decimal = Field(gt=0)
    high: Decimal = Field(gt=0)
    low: Decimal = Field(gt=0)
    close: Decimal = Field(gt=0)
    volume: Decimal = Field(ge=0)

class MarketAnalysisRequest(BaseModel):
    candles: list[BacktestCandleInput] = Field(min_length=25, max_length=100000)
    last_candle_closed: bool


@app.post("/patterns/detect")
def detect_market_patterns(request: MarketAnalysisRequest):
    """Detect causal chart patterns from fully closed candles; research only."""
    if not request.last_candle_closed:
        raise HTTPException(status_code=422, detail="The final candle must be fully closed")
    candles = [Candle(timestamp=c.timestamp, open=c.open, high=c.high, low=c.low,
                      close=c.close, volume=c.volume) for c in request.candles]
    try:
        return detect_patterns(candles, PatternConfig())
    except PatternDetectionError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@app.post("/analysis/run")
def run_market_analysis(request: MarketAnalysisRequest):
    """Analyze fully closed candles for LONG, SHORT or NO_TRADE. Never places orders."""
    if not request.last_candle_closed:
        raise HTTPException(status_code=422, detail="The final candle must be fully closed")
    candles = [Candle(timestamp=c.timestamp, open=c.open, high=c.high, low=c.low,
                      close=c.close, volume=c.volume) for c in request.candles]
    try:
        return analyze_closed_candles(candles)
    except SignalAnalysisError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


class DecisionRequest(MarketAnalysisRequest):
    symbol: str = Field(min_length=2, max_length=30)
    quote_balance: Decimal = Field(default=Decimal("0"), ge=0)
    base_quantity: Decimal = Field(default=Decimal("0"), ge=0)
    entry_paused: bool = False

@app.post("/decision/run")
def run_decision(request: DecisionRequest):
    """Combine indicator and pattern evidence. Research/paper only; never submits orders."""
    if not request.last_candle_closed:
        raise HTTPException(status_code=422, detail="The final candle must be fully closed")
    candles = [Candle(timestamp=c.timestamp, open=c.open, high=c.high, low=c.low,
                      close=c.close, volume=c.volume) for c in request.candles]
    try:
        return make_decision(candles, symbol=request.symbol, quote_balance=request.quote_balance,
                             base_quantity=request.base_quantity, entry_paused=request.entry_paused)
    except (ValueError, SignalAnalysisError, PatternDetectionError) as exc:
        raise HTTPException(status_code=422, detail=str(exc))


class PatternMemoryRequest(BaseModel):
    pattern_key: str = Field(min_length=1, max_length=120)
    symbol: str = Field(min_length=2, max_length=30)
    direction: str
    score: int = Field(ge=0, le=100)
    timeframe: str = Field(default="unknown", max_length=16)
    features: dict = Field(default_factory=dict)

@app.post("/patterns/memory/observations")
def create_pattern_observation(request: PatternMemoryRequest):
    try:
        observation_id = record_observation(pattern_key=request.pattern_key, symbol=request.symbol,
            direction=request.direction, score=request.score, timeframe=request.timeframe, features=request.features)
        return {"observation_id": observation_id, "stored": True}
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

@app.post("/patterns/memory/observations/{observation_id}/resolve")
def finish_pattern_observation(observation_id: int, outcome: str = Query(...)):
    try:
        resolve_observation(observation_id, outcome)
        return {"observation_id": observation_id, "outcome": outcome, "resolved": True}
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

@app.get("/patterns/memory/summary")
def get_pattern_memory(symbol: str | None = None, limit: int = Query(100, ge=1, le=1000)):
    return pattern_memory_summary(symbol=symbol, limit=limit)


class BacktestRequest(BaseModel):
    candles: list[BacktestCandleInput] = Field(min_length=2, max_length=100000)
    fast_period: int = Field(default=9, ge=2, le=500)
    slow_period: int = Field(default=21, ge=3, le=2000)
    starting_balance: Decimal = Field(default=Decimal("10000"), gt=0)
    stake_quote: Decimal = Field(default=Decimal("100"), gt=0)
    leverage: Decimal = Field(default=Decimal("1"), ge=1, le=10)
    fee_rate: Decimal = Field(default=Decimal("0.001"), ge=0, lt=1)
    slippage_bps: Decimal = Field(default=Decimal("5"), ge=0, le=5000)
    stop_loss_pct: Decimal | None = Field(default=Decimal("0.02"), gt=0, lt=1)
    take_profit_pct: Decimal | None = Field(default=None, gt=0, lt=1)
    allow_short: bool = True
    strategy: str = Field(default="sma_crossover", pattern="^(sma_crossover|ema_crossover|donchian_breakout)$")

@app.post("/backtest/run")
@app.post("/backtest/sma")
def backtest_sma(request: BacktestRequest):
    """Run a historical-only baseline strategy test. Does not place orders."""
    candles = [Candle(c.timestamp, c.open, c.high, c.low, c.close, c.volume) for c in request.candles]
    config = BacktestConfig(
        fast_period=request.fast_period, slow_period=request.slow_period,
        starting_balance=request.starting_balance, stake_quote=request.stake_quote,
        leverage=request.leverage, fee_rate=request.fee_rate,
        slippage_bps=request.slippage_bps, stop_loss_pct=request.stop_loss_pct,
        take_profit_pct=request.take_profit_pct, allow_short=request.allow_short, strategy=request.strategy,
    )
    try:
        return run_sma_backtest(candles, config)
    except BacktestError as exc:
        raise HTTPException(status_code=422, detail=str(exc))



class HistoricalSyncRequest(BaseModel):
    resolution: str = Field(pattern="^(1|60|1D)$")
    start: int = Field(gt=0)
    end: int = Field(gt=0)

@app.post("/history/sync/{symbol}")
async def history_sync(symbol: str, request: HistoricalSyncRequest):
    """Download bounded public OHLCV history and upsert it into local storage."""
    with SessionLocal() as db:
        try:
            result = await download_and_store(db, client, symbol, request.resolution,
                                              request.start, request.end)
            return {"mode":"historical_data_only", "exchange_order_submitted":False, **result}
        except HistoricalDataError as exc:
            raise HTTPException(status_code=422, detail=str(exc))
        except WallexAPIError as exc:
            raise HTTPException(status_code=502, detail=f"Wallex history request failed: {exc}")

@app.get("/history/{symbol}")
def history_read(symbol: str, resolution: str = Query(..., pattern="^(1|60|1D)$"),
                 start: int = Query(..., gt=0), end: int = Query(..., gt=0),
                 limit: int = Query(5000, ge=1, le=20000)):
    if end <= start:
        raise HTTPException(status_code=422, detail="end must be greater than start")
    with SessionLocal() as db:
        candles = load_stored_candles(db, symbol, resolution, start, end)
        candles = candles[:limit]
        return {"symbol":symbol.upper(), "resolution":resolution, "count":len(candles),
            "candles":[{"timestamp":c.timestamp,"open":str(c.open),"high":str(c.high),
                "low":str(c.low),"close":str(c.close),"volume":str(c.volume)} for c in candles]}

class StoredBacktestRequest(BaseModel):
    resolution: str = Field(pattern="^(1|60|1D)$")
    start: int = Field(gt=0)
    end: int = Field(gt=0)
    train_fraction: Decimal = Field(default=Decimal("0.70"), gt=Decimal("0.50"), lt=Decimal("0.90"))
    fast_period: int = Field(default=9, ge=2, le=500)
    slow_period: int = Field(default=21, ge=3, le=2000)
    starting_balance: Decimal = Field(default=Decimal("10000"), gt=0)
    stake_quote: Decimal = Field(default=Decimal("100"), gt=0)
    fee_rate: Decimal = Field(default=Decimal("0.001"), ge=0, lt=1)
    slippage_bps: Decimal = Field(default=Decimal("5"), ge=0, le=5000)
    stop_loss_pct: Decimal | None = Field(default=Decimal("0.02"), gt=0, lt=1)
    take_profit_pct: Decimal | None = Field(default=None, gt=0, lt=1)
    allow_short: bool = True
    strategy: str = Field(default="sma_crossover", pattern="^(sma_crossover|ema_crossover|donchian_breakout)$")

@app.post("/backtest/stored/{symbol}")
@app.post("/backtest/sma/stored/{symbol}")
def backtest_sma_stored(symbol: str, request: StoredBacktestRequest):
    """Chronological train/test split. Parameters are fixed; no optimization occurs."""
    if request.end <= request.start:
        raise HTTPException(status_code=422, detail="end must be greater than start")
    with SessionLocal() as db:
        candles = load_stored_candles(db, symbol, request.resolution, request.start, request.end)
    if len(candles) < request.slow_period * 2 + 4:
        raise HTTPException(status_code=422, detail="Not enough stored candles for train/test evaluation")
    split = int(len(candles) * float(request.train_fraction))
    if split < request.slow_period + 2 or len(candles) - split < request.slow_period + 2:
        raise HTTPException(status_code=422, detail="Train or test segment is too short for selected periods")
    config = BacktestConfig(fast_period=request.fast_period, slow_period=request.slow_period,
        starting_balance=request.starting_balance, stake_quote=request.stake_quote,
        fee_rate=request.fee_rate, slippage_bps=request.slippage_bps,
        stop_loss_pct=request.stop_loss_pct, take_profit_pct=request.take_profit_pct,
        allow_short=request.allow_short, strategy=request.strategy)
    try:
        train = run_sma_backtest(candles[:split], config)
        test = run_sma_backtest(candles[split:], config)
    except BacktestError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return {"symbol":symbol.upper(), "resolution":request.resolution,
        "total_candles":len(candles), "train_candles":split,
        "test_candles":len(candles)-split, "split_timestamp":candles[split].timestamp,
        "method":"chronological_holdout_no_parameter_optimization", "strategy":request.strategy,
        "train":train, "out_of_sample_test":test,
        "warning":"Train and test are independent simulations with separate starting balances. This is a first holdout check, not proof of strategy robustness; parameters are not optimized or validated."}


class WalkForwardRequest(BaseModel):
    resolution: str = Field(pattern="^(1|60|1D)$")
    start: int = Field(gt=0)
    end: int = Field(gt=0)
    initial_train_candles: int = Field(default=500, ge=30, le=50000)
    test_candles: int = Field(default=100, ge=3, le=20000)
    max_folds: int = Field(default=12, ge=1, le=50)
    fast_period: int = Field(default=9, ge=2, le=500)
    slow_period: int = Field(default=21, ge=3, le=2000)
    starting_balance: Decimal = Field(default=Decimal("10000"), gt=0)
    stake_quote: Decimal = Field(default=Decimal("100"), gt=0)
    fee_rate: Decimal = Field(default=Decimal("0.001"), ge=0, lt=1)
    slippage_bps: Decimal = Field(default=Decimal("5"), ge=0, le=5000)
    stop_loss_pct: Decimal | None = Field(default=Decimal("0.02"), gt=0, lt=1)
    take_profit_pct: Decimal | None = Field(default=None, gt=0, lt=1)
    allow_short: bool = True
    strategy: str = Field(default="sma_crossover", pattern="^(sma_crossover|ema_crossover|donchian_breakout)$")

@app.post("/backtest/walk-forward/{symbol}")
def backtest_walk_forward_stored(symbol: str, request: WalkForwardRequest):
    """Evaluate fixed strategy parameters over sequential unseen windows."""
    if request.end <= request.start:
        raise HTTPException(status_code=422, detail="end must be greater than start")
    with SessionLocal() as db:
        candles = load_stored_candles(db, symbol, request.resolution, request.start, request.end)
    config = BacktestConfig(fast_period=request.fast_period, slow_period=request.slow_period,
        starting_balance=request.starting_balance, stake_quote=request.stake_quote,
        fee_rate=request.fee_rate, slippage_bps=request.slippage_bps,
        stop_loss_pct=request.stop_loss_pct, take_profit_pct=request.take_profit_pct,
        allow_short=request.allow_short, strategy=request.strategy)
    try:
        result = evaluate_walk_forward(candles, config, request.initial_train_candles,
                                       request.test_candles, request.max_folds)
    except (WalkForwardError, BacktestError) as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return {"symbol":symbol.upper(), "resolution":request.resolution,
            "total_candles":len(candles), "exchange_order_submitted":False, **result}


@app.get("/events/errors")
def errors(limit: int = Query(20, ge=1, le=100)):
    with SessionLocal() as db:
        rows = db.scalars(select(SystemEvent).order_by(desc(SystemEvent.id)).limit(limit)).all()
        return [{"level":r.level,"message":r.message,"created_at":r.created_at.isoformat()} for r in rows]

@app.get("/trading/status")
def trading_status():
    return {"enabled":False,"reason":"execution adapter not implemented; read-only milestone"}


class PaperSimulationRequest(BaseModel):
    side: str = Field(pattern="^(BUY|SELL)$")
    quantity: Decimal = Field(gt=0)
    fee_rate: Decimal = Field(default=Decimal("0.001"), ge=0, lt=1)
    max_slippage_bps: Decimal = Field(default=Decimal("100"), ge=0, le=5000)


@app.post("/paper/simulate/{symbol}")
async def paper_simulate(symbol: str, request: PaperSimulationRequest):
    """Simulate a market fill against current public L2 depth. Never places orders."""
    try:
        symbol = symbol.upper()
        book = await client.depth(symbol)
        fill = simulate_market_fill(
            book, request.side, request.quantity,
            fee_rate=request.fee_rate,
            max_slippage_bps=request.max_slippage_bps,
        )
    except WallexAPIError as exc:
        raise HTTPException(status_code=502, detail=f"Market data unavailable: {exc}")
    except PaperSimulationError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return {
        "mode": "paper_only",
        "exchange_order_submitted": False,
        "symbol": symbol.upper(),
        "side": fill.side.value,
        "status": fill.status,
        "requested_quantity": str(fill.requested_quantity),
        "filled_quantity": str(fill.filled_quantity),
        "unfilled_quantity": str(fill.unfilled_quantity),
        "average_price": str(fill.average_price) if fill.average_price is not None else None,
        "quote_value": str(fill.quote_value),
        "estimated_fee_quote": str(fill.fee_quote),
        "slippage_bps": str(fill.slippage_bps) if fill.slippage_bps is not None else None,
        "levels_consumed": fill.levels_consumed,
        "disclaimer": "Visible order-book simulation only; not a guaranteed fill or a live order.",
    }


class PaperWalletInitRequest(BaseModel):
    initial_balance: Decimal = Field(gt=0)
    quote_asset: str = Field(default="USDT", min_length=2, max_length=16, pattern="^[A-Za-z0-9]+$")

class PaperPositionOpenRequest(BaseModel):
    direction: str = Field(pattern="^(LONG|SHORT)$")
    quantity: Decimal = Field(gt=0)
    leverage: Decimal = Field(default=Decimal("1"), ge=1, le=10)
    fee_rate: Decimal = Field(default=Decimal("0.001"), ge=0, lt=1)
    max_slippage_bps: Decimal = Field(default=Decimal("100"), ge=0, le=5000)
    idempotency_key: str = Field(min_length=8, max_length=96)

class PaperPositionCloseRequest(BaseModel):
    fee_rate: Decimal = Field(default=Decimal("0.001"), ge=0, lt=1)
    max_slippage_bps: Decimal = Field(default=Decimal("100"), ge=0, le=5000)
    idempotency_key: str = Field(min_length=8, max_length=96)

@app.post("/paper/account/init")
def paper_account_init(request: PaperWalletInitRequest):
    with SessionLocal() as db:
        try:
            wallet = initialize_wallet(db, request.initial_balance, request.quote_asset)
            return wallet_snapshot(db)
        except PaperLedgerError as exc:
            raise HTTPException(status_code=422, detail=str(exc))

@app.get("/paper/account")
def paper_account():
    with SessionLocal() as db:
        try:
            return wallet_snapshot(db)
        except PaperLedgerError as exc:
            raise HTTPException(status_code=404, detail=str(exc))

@app.get("/paper/positions")
def paper_positions(status: str = Query("OPEN", pattern="^(OPEN|CLOSED|ALL)$")):
    with SessionLocal() as db:
        stmt = select(PaperPosition).order_by(desc(PaperPosition.opened_at))
        if status != "ALL":
            stmt = stmt.where(PaperPosition.status == status)
        rows = db.scalars(stmt.limit(200)).all()
        return [{"id":p.id,"symbol":p.symbol,"direction":p.direction,"quantity":p.quantity,
            "entry_price":p.entry_price,"collateral":p.collateral,"leverage":p.leverage,
            "entry_fee":p.entry_fee,"status":p.status,"opened_at":p.opened_at.isoformat(),
            "closed_at":p.closed_at.isoformat() if p.closed_at else None} for p in rows]

@app.get("/paper/trades")
def paper_trades(limit: int = Query(50, ge=1, le=200)):
    with SessionLocal() as db:
        rows = db.scalars(select(PaperTrade).order_by(desc(PaperTrade.id)).limit(limit)).all()
        return [{"position_id":t.position_id,"symbol":t.symbol,"direction":t.direction,
            "quantity":t.quantity,"entry_price":t.entry_price,"exit_price":t.exit_price,
            "gross_pnl":t.gross_pnl,"entry_fee":t.entry_fee,"exit_fee":t.exit_fee,
            "realized_pnl":t.realized_pnl,"closed_at":t.closed_at.isoformat()} for t in rows]

@app.post("/paper/positions/open/{symbol}")
async def paper_position_open(symbol: str, request: PaperPositionOpenRequest):
    try:
        book = await client.depth(symbol.upper())
        with SessionLocal() as db:
            position, fill, replayed = open_position(db, symbol=symbol, direction=request.direction,
                quantity=request.quantity, leverage=request.leverage, book=book,
                idempotency_key=request.idempotency_key, fee_rate=request.fee_rate,
                max_slippage_bps=request.max_slippage_bps)
            return {"mode":"paper_only","exchange_order_submitted":False,"replayed":replayed,
                "position_id":position.id,"symbol":position.symbol,"direction":position.direction,
                "quantity":position.quantity,"entry_price":position.entry_price,
                "collateral":position.collateral,"entry_fee":position.entry_fee,
                "status":position.status,"fill_status":fill.status if fill else "replayed"}
    except WallexAPIError as exc:
        raise HTTPException(status_code=502, detail=f"Market data unavailable: {exc}")
    except (PaperSimulationError, PaperLedgerError) as exc:
        raise HTTPException(status_code=422, detail=str(exc))

@app.post("/paper/positions/{position_id}/close")
async def paper_position_close(position_id: str, request: PaperPositionCloseRequest):
    try:
        with SessionLocal() as db:
            position = db.get(PaperPosition, position_id)
            if position is None:
                raise HTTPException(status_code=404, detail="Paper position not found")
            position_symbol = position.symbol
        book = await client.depth(position_symbol)
        with SessionLocal() as db:
            trade, fill, replayed = close_position(db, position_id=position_id, book=book,
                idempotency_key=request.idempotency_key, fee_rate=request.fee_rate,
                max_slippage_bps=request.max_slippage_bps)
            return {"mode":"paper_only","exchange_order_submitted":False,"replayed":replayed,
                "position_id":trade.position_id,"exit_price":trade.exit_price,
                "gross_pnl":trade.gross_pnl,"entry_fee":trade.entry_fee,
                "exit_fee":trade.exit_fee,"realized_pnl":trade.realized_pnl,
                "entry_paused_after_close":wallet_snapshot(db)["entry_paused"],
                "fill_status":fill.status if fill else "replayed"}
    except WallexAPIError as exc:
        raise HTTPException(status_code=502, detail=f"Market data unavailable: {exc}")
    except (PaperSimulationError, PaperLedgerError) as exc:
        raise HTTPException(status_code=422, detail=str(exc))


class PatternArchiveRequest(BaseModel):
    pattern_key: str = Field(min_length=1, max_length=120)
    features: dict = Field(default_factory=dict)
    schema_version: str = Field(default="1.0.0", max_length=24)
    provenance: dict = Field(default_factory=dict)

@app.post("/patterns/archive")
def create_pattern_archive(request: PatternArchiveRequest):
    return archive_pattern(request.pattern_key, request.features, schema_version=request.schema_version, provenance=request.provenance)

@app.get("/patterns/archive/{pattern_key}")
def read_pattern_archive(pattern_key: str, limit: int = Query(50, ge=1, le=500)):
    return {"items": find_similar_patterns(pattern_key, limit=limit)}

@app.post("/patterns/memory/compact")
def compact_pattern_memory():
    return compact_resolved_observations()

@app.get("/risk/circuit")
def read_risk_circuit():
    return circuit_status()

@app.get("/risk/status")
def risk_status():
    """Expose persistent circuit state and paper-account risk state."""
    with SessionLocal() as db:
        try:
            account = wallet_snapshot(db)
        except PaperLedgerError:
            account = None
    circuit = circuit_status()
    return {"circuit": circuit, "paper_account": account,
            "new_entries_allowed": not circuit["entries_paused"] and bool(account),
            "position_closing_allowed": True, "live_trading_enabled": False}

@app.get("/paper/portfolio")
def paper_portfolio():
    """Return persistent paper ledger totals and open-position inventory."""
    with SessionLocal() as db:
        try:
            snapshot = wallet_snapshot(db)
        except PaperLedgerError as exc:
            raise HTTPException(status_code=404, detail=str(exc))
        positions = db.scalars(select(PaperPosition).where(PaperPosition.status == "OPEN")).all()
        return {**snapshot, "positions": [
            {"id": p.id, "symbol": p.symbol, "direction": p.direction,
             "quantity": p.quantity, "entry_price": p.entry_price,
             "collateral": p.collateral, "leverage": p.leverage,
             "opened_at": p.opened_at.isoformat() if p.opened_at else None}
            for p in positions]}

@app.get("/system/capabilities")
def system_capabilities():
    return {"version":"0.20.0", "market_data":"wallex_public_read_only",
        "paper_trading":True, "live_trading":False, "withdrawals":False,
        "futures_execution":False, "api_bearer_auth_configured":bool(settings.moya_api_token),
        "android_client":"starter_scaffold_only"}
