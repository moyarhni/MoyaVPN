"""Deterministic paper-fill simulator. This module never submits exchange orders."""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from enum import Enum
from typing import Any


class PaperSimulationError(ValueError):
    pass


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


def D(value: Any, field: str) -> Decimal:
    try:
        out = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise PaperSimulationError(f"Invalid {field}") from exc
    if not out.is_finite():
        raise PaperSimulationError(f"Non-finite {field}")
    return out


@dataclass(frozen=True, slots=True)
class FillLevel:
    price: Decimal
    quantity: Decimal


@dataclass(frozen=True, slots=True)
class PaperFill:
    side: Side
    requested_quantity: Decimal
    filled_quantity: Decimal
    average_price: Decimal | None
    quote_value: Decimal
    fee_quote: Decimal
    unfilled_quantity: Decimal
    slippage_bps: Decimal | None
    status: str
    levels_consumed: int


def normalize_book_side(raw_levels: Any, *, side: Side) -> list[FillLevel]:
    if not isinstance(raw_levels, list):
        raise PaperSimulationError("Order book side must be a list")
    levels: list[FillLevel] = []
    for raw in raw_levels:
        if not isinstance(raw, dict):
            raise PaperSimulationError("Invalid order book level")
        price = D(raw.get("price"), "book price")
        quantity = D(raw.get("quantity"), "book quantity")
        if price <= 0 or quantity < 0:
            raise PaperSimulationError("Order book price must be positive and quantity non-negative")
        if quantity == 0:
            continue
        levels.append(FillLevel(price, quantity))
    expected = sorted(levels, key=lambda x: x.price, reverse=(side == Side.SELL))
    if levels != expected:
        raise PaperSimulationError("Order book levels are not sorted best-to-worst")
    return levels


def simulate_market_fill(
    book: dict[str, Any], side: Side | str, quantity: Decimal | str,
    fee_rate: Decimal | str = Decimal("0.001"), max_slippage_bps: Decimal | str = Decimal("100"),
) -> PaperFill:
    """Walk visible L2 depth; stop before exceeding the slippage cap.

    BUY consumes asks; SELL consumes bids. Fees apply to filled quote notional.
    This is a conservative estimate, not a guarantee of executable fills.
    """
    try:
        side = Side(side)
    except ValueError as exc:
        raise PaperSimulationError("side must be BUY or SELL") from exc
    requested = D(quantity, "quantity")
    fee = D(fee_rate, "fee_rate")
    cap = D(max_slippage_bps, "max_slippage_bps")
    if requested <= 0 or fee < 0 or fee >= 1 or cap < 0:
        raise PaperSimulationError("Invalid quantity, fee rate, or slippage cap")
    if not isinstance(book, dict):
        raise PaperSimulationError("Order book must be an object")
    result = book.get("result", book)
    if not isinstance(result, dict):
        raise PaperSimulationError("Invalid order book result")
    key = "ask" if side == Side.BUY else "bid"
    levels = normalize_book_side(result.get(key), side=side)
    if not levels:
        raise PaperSimulationError("No visible liquidity on required book side")

    best = levels[0].price
    max_price = best * (Decimal(1) + cap / Decimal(10000)) if side == Side.BUY else best * (Decimal(1) - cap / Decimal(10000))
    remaining = requested
    notional = Decimal(0)
    filled = Decimal(0)
    consumed = 0
    for level in levels:
        if side == Side.BUY and level.price > max_price:
            break
        if side == Side.SELL and level.price < max_price:
            break
        take = min(remaining, level.quantity)
        if take <= 0:
            continue
        filled += take
        notional += take * level.price
        remaining -= take
        consumed += 1
        if remaining == 0:
            break

    average = notional / filled if filled else None
    slippage = None
    if average is not None:
        raw = (average - best) / best * Decimal(10000)
        slippage = raw if side == Side.BUY else -raw
    status = "filled" if remaining == 0 else ("partial" if filled > 0 else "rejected_slippage_or_liquidity")
    return PaperFill(
        side=side, requested_quantity=requested, filled_quantity=filled,
        average_price=average, quote_value=notional, fee_quote=notional * fee,
        unfilled_quantity=remaining, slippage_bps=slippage, status=status,
        levels_consumed=consumed,
    )
