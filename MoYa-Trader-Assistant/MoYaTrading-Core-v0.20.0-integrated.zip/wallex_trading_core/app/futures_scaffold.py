"""Futures domain contracts only. No exchange execution or liquidation claims."""
from dataclasses import dataclass
from decimal import Decimal
@dataclass(frozen=True)
class FuturesRiskInput:
    equity: Decimal
    entry: Decimal
    stop: Decimal
    leverage: Decimal
    maintenance_margin_rate: Decimal
    def validate(self):
        if min(self.equity, self.entry, self.stop, self.maintenance_margin_rate) <= 0:
            raise ValueError('All monetary and maintenance inputs must be positive')
        if not Decimal('1') <= self.leverage <= Decimal('10'):
            raise ValueError('Leverage must be between 1 and 10 in scaffold')
        if self.stop == self.entry: raise ValueError('Stop must differ from entry')

def estimate_notional(equity: Decimal, leverage: Decimal) -> Decimal:
    if equity <= 0 or not Decimal('1') <= leverage <= Decimal('10'):
        raise ValueError('Invalid equity or leverage')
    return equity * leverage
