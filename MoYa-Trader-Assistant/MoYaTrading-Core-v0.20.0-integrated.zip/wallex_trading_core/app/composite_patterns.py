"""Deterministic, explainable combinations of base pattern detections."""
from __future__ import annotations
from typing import Any

# Rules use detector slugs, not presentation labels.
RULES = (
    ("bullish_reversal_confirmation", {"double_bottom", "inverse_head_and_shoulders"}, "bullish"),
    ("bearish_reversal_confirmation", {"double_top", "head_and_shoulders"}, "bearish"),
    ("bullish_breakout_confirmation", {"higher_high_higher_low", "breakout", "volume_spike"}, "bullish"),
    ("bearish_breakdown_confirmation", {"lower_high_lower_low", "breakdown", "volume_spike"}, "bearish"),
    ("bullish_continuation_confirmation", {"bull_flag", "bull_pennant", "ascending_triangle"}, "bullish"),
    ("bearish_continuation_confirmation", {"bear_flag", "bear_pennant", "descending_triangle"}, "bearish"),
)

def combine_patterns(detections: dict[str, Any], *, indicator_signal: str | None = None) -> dict[str, Any]:
    found = detections.get("patterns_detected", []) if isinstance(detections, dict) else []
    if not isinstance(found, list):
        raise ValueError("patterns_detected must be a list")
    slug_aliases = {"Breakout":"breakout", "Volume Spike":"volume_spike",
                    "Higher High / Higher Low":"higher_high_higher_low",
                    "Lower High / Lower Low":"lower_high_lower_low",
                    "Double Bottom":"double_bottom", "Inverse Head and Shoulders":"inverse_head_and_shoulders",
                    "Double Top":"double_top", "Head and Shoulders":"head_and_shoulders"}
    by_slug = {}
    for item in found:
        if not isinstance(item, dict):
            continue
        slug = item.get("pattern") or slug_aliases.get(item.get("name"))
        if slug:
            by_slug[slug] = item
    combos = []
    for name, required, direction in RULES:
        matched = sorted(slug for slug in required if slug in by_slug)
        if len(matched) >= 2:
            aligned = indicator_signal in ({"BUY", "BULLISH", "LONG"} if direction == "bullish" else {"SELL", "BEARISH", "SHORT"})
            component_score = sum(int(by_slug[x].get("score", 0)) for x in matched) // len(matched)
            score = min(100, component_score + (10 if aligned else 0))
            combos.append({"name": name, "direction": direction, "matched": matched,
                           "score": score, "indicator_aligned": aligned})
    return {"combinations": combos, "count": len(combos), "scores_are_probabilities": False}
