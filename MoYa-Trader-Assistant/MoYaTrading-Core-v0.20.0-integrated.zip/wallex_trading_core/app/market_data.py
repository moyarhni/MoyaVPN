"""Strict normalization and validation for Wallex UDF candle responses."""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any


class MarketDataError(ValueError):
    """Raised when exchange market data is incomplete or unsafe to consume."""


@dataclass(frozen=True, slots=True)
class Candle:
    timestamp: int  # Unix seconds, candle open time
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal


def _decimal(value: Any, field: str) -> Decimal:
    try:
        number = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise MarketDataError(f"Invalid {field} value") from exc
    if not number.is_finite():
        raise MarketDataError(f"Non-finite {field} value")
    return number


def normalize_udf_candles(payload: dict[str, Any]) -> list[Candle]:
    """Convert TradingView UDF history arrays into validated candles.

    Expected shape: {s: 'ok', t: [...], o: [...], h: [...], l: [...], c: [...], v: [...]}.
    A `no_data` response is valid and returns an empty list.
    """
    if not isinstance(payload, dict):
        raise MarketDataError("Candle response must be an object")

    status = payload.get("s")
    if status == "no_data":
        return []
    if status != "ok":
        raise MarketDataError(f"Unexpected candle status: {status!r}")

    fields = ("t", "o", "h", "l", "c", "v")
    arrays: dict[str, list] = {}
    for field in fields:
        value = payload.get(field)
        if not isinstance(value, list):
            raise MarketDataError(f"Missing or invalid candle array: {field}")
        arrays[field] = value

    lengths = {len(value) for value in arrays.values()}
    if len(lengths) != 1:
        raise MarketDataError("Candle arrays have different lengths")
    if not arrays["t"]:
        return []

    candles: list[Candle] = []
    previous_ts: int | None = None
    for index, raw_ts in enumerate(arrays["t"]):
        if isinstance(raw_ts, bool) or not isinstance(raw_ts, (int, float)):
            raise MarketDataError("Invalid candle timestamp")
        timestamp = int(raw_ts)
        if timestamp <= 0 or timestamp != raw_ts:
            raise MarketDataError("Candle timestamp must be a positive integer")
        if previous_ts is not None and timestamp <= previous_ts:
            raise MarketDataError("Candle timestamps must be strictly increasing")
        previous_ts = timestamp

        o = _decimal(arrays["o"][index], "open")
        h = _decimal(arrays["h"][index], "high")
        low = _decimal(arrays["l"][index], "low")
        c = _decimal(arrays["c"][index], "close")
        v = _decimal(arrays["v"][index], "volume")
        if min(o, h, low, c) <= 0:
            raise MarketDataError("OHLC prices must be positive")
        if h < max(o, low, c) or low > min(o, h, c):
            raise MarketDataError("Invalid OHLC price range")
        if v < 0:
            raise MarketDataError("Volume cannot be negative")
        candles.append(Candle(timestamp, o, h, low, c, v))

    return candles

@dataclass(frozen=True, slots=True)
class TickerSnapshot:
    last_price: Decimal
    bid_price: Decimal | None
    ask_price: Decimal | None
    volume_24h: Decimal | None
    quote_volume_24h: Decimal | None


def normalize_ticker_snapshot(stats: dict[str, Any]) -> TickerSnapshot:
    """Validate the essential ticker fields before they enter the event store."""
    if not isinstance(stats, dict):
        raise MarketDataError("Ticker stats must be an object")

    last = _decimal(stats.get("lastPrice"), "lastPrice")
    if last <= 0:
        raise MarketDataError("lastPrice must be positive")

    def optional_nonnegative(key: str) -> Decimal | None:
        value = stats.get(key)
        if value is None or value == "":
            return None
        number = _decimal(value, key)
        if number < 0 or (key in ("bidPrice", "askPrice") and number == 0):
            raise MarketDataError(f"{key} is outside its valid range")
        return number

    bid = optional_nonnegative("bidPrice")
    ask = optional_nonnegative("askPrice")
    volume = optional_nonnegative("24h_volume")
    quote_volume = optional_nonnegative("24h_quoteVolume")
    if bid is not None and ask is not None and bid > ask:
        raise MarketDataError("bidPrice cannot exceed askPrice")
    return TickerSnapshot(last, bid, ask, volume, quote_volume)
