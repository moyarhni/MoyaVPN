import asyncio
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.collector import MarketCollector
from app.db import Base, MarketEvent
from app.config import settings


class FakeWallex:
    def __init__(self):
        self.market_payload = {"result": {"symbols": {}}}
        for index, symbol in enumerate(settings.symbol_list):
            stats = {"lastPrice": "100", "bidPrice": "99", "askPrice": "101"}
            if index == 0:
                stats["lastPrice"] = "NaN"
            self.market_payload["result"]["symbols"][symbol] = {"stats": stats}

    async def markets(self):
        return self.market_payload

    async def depth(self, symbol):
        return {"result": {"bids": [], "asks": []}}

    async def trades(self, symbol):
        return {"result": []}


def test_collector_isolates_bad_symbol_and_continues():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    client = FakeWallex()
    collector = MarketCollector(client)

    with Session() as db:
        result = asyncio.run(collector.collect_once(db))
        rows = db.scalars(select(MarketEvent)).all()

    assert result["ok"] is False
    assert len(result["symbols_invalid"]) == 1
    assert len(result["symbols_ok"]) == max(0, len(settings.symbol_list) - 1)
    assert any(row.event_type == "market_invalid" for row in rows)
    assert len([row for row in rows if row.event_type == "market_snapshot"]) == max(0, len(settings.symbol_list) - 1)
    engine.dispose()
