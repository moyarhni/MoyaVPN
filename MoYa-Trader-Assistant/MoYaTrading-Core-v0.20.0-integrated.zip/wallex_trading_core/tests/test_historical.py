import asyncio
from decimal import Decimal
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
import pytest
from app.db import Base, HistoricalCandle
from app.historical import download_and_store, load_stored_candles, HistoricalDataError
from app.market_data import Candle

class FakeClient:
    def __init__(self): self.calls = 0
    async def candles(self, symbol, resolution, start, end):
        self.calls += 1
        return {"s":"ok", "t":[start], "o":["10"], "h":["11"],
                "l":["9"], "c":["10.5"], "v":["20"]}

@pytest.fixture
def session():
    engine = create_engine("sqlite://", connect_args={"check_same_thread":False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    with Session() as db:
        yield db
    engine.dispose()

def test_history_sync_persists_and_updates_without_duplicates(session):
    client = FakeClient()
    first = asyncio.run(download_and_store(session, client, "btcusdt", "1", 1000, 1001))
    second = asyncio.run(download_and_store(session, client, "BTCUSDT", "1", 1000, 1001))
    rows = session.scalars(select(HistoricalCandle)).all()
    assert first["inserted"] == 1 and first["updated"] == 0
    assert second["inserted"] == 0 and second["updated"] == 1
    assert len(rows) == 1
    loaded = load_stored_candles(session, "BTCUSDT", "1", 999, 1002)
    assert loaded[0].close == Decimal("10.5")

def test_history_sync_rejects_unsupported_resolution_and_large_window(session):
    client = FakeClient()
    with pytest.raises(HistoricalDataError):
        asyncio.run(download_and_store(session, client, "BTCUSDT", "15", 1000, 2000))
    with pytest.raises(HistoricalDataError):
        asyncio.run(download_and_store(session, client, "BTCUSDT", "1", 1000, 1000 + 91*86400))
    assert client.calls == 0
