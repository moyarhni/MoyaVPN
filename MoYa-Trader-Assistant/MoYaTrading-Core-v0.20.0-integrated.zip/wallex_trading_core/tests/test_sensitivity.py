from decimal import Decimal
import pytest
from app.market_data import Candle
from app.signal_engine import SignalConfig
from app.sensitivity import SensitivityError, evaluate_sensitivity

def candles(n=100):
    out=[]; price=Decimal("100")
    for i in range(n):
        price += Decimal("0.25") if i % 7 else Decimal("-0.4")
        out.append(Candle(timestamp=i+1, open=price, high=price+Decimal("1"),
            low=price-Decimal("1"), close=price, volume=Decimal(100+i)))
    return out

def test_sensitivity_evaluates_each_market_and_variant():
    report=evaluate_sensitivity({"BTC-USDT":candles(),"ETH-USDT":candles()},
        {"base":SignalConfig(),"strict":SignalConfig(min_score=65)})
    assert report["market_count"] == 2
    assert report["variant_count"] == 2
    assert len(report["results"]) == 4
    assert report["parameter_optimization_performed"] is False
    assert report["strategy_selected"] is False

def test_sensitivity_rejects_empty_inputs():
    with pytest.raises(SensitivityError):
        evaluate_sensitivity({}, {"base":SignalConfig()})
