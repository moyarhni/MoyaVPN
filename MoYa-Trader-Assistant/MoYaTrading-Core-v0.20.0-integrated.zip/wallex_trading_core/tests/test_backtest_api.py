from fastapi.testclient import TestClient
from app import main


def test_backtest_endpoint_is_historical_only(monkeypatch):
    async def idle_loop(stop_event):
        await stop_event.wait()

    monkeypatch.setattr(main, "init_db", lambda: None)
    monkeypatch.setattr(main, "collection_loop", idle_loop)
    candles = []
    closes = [10, 10, 10, 12, 14, 12, 10, 8, 10, 12, 14, 16]
    for i, close in enumerate(closes):
        candles.append({
            "timestamp": 1700000000 + i * 60,
            "open": str(close), "high": str(close + 1),
            "low": str(close - 1), "close": str(close), "volume": "100",
        })
    with TestClient(main.app) as client:
        response = client.post("/backtest/sma", json={
            "candles": candles, "fast_period": 2, "slow_period": 3,
            "fee_rate": "0.001", "slippage_bps": "5",
        })
    assert response.status_code == 200
    data = response.json()
    assert data["mode"] == "historical_backtest_only"
    assert data["candle_count"] == len(candles)
    assert "trades" in data
    assert "exchange_order_submitted" not in data


def test_backtest_endpoint_rejects_invalid_sma_periods(monkeypatch):
    async def idle_loop(stop_event):
        await stop_event.wait()

    monkeypatch.setattr(main, "init_db", lambda: None)
    monkeypatch.setattr(main, "collection_loop", idle_loop)
    candles = [
        {"timestamp": 1700000000 + i * 60, "open": "10", "high": "11",
         "low": "9", "close": "10", "volume": "100"}
        for i in range(8)
    ]
    with TestClient(main.app) as client:
        response = client.post("/backtest/sma", json={
            "candles": candles, "fast_period": 5, "slow_period": 5,
        })
    assert response.status_code == 422


def test_stored_backtest_reports_chronological_holdout(monkeypatch):
    from decimal import Decimal
    from app.market_data import Candle
    async def idle_loop(stop_event):
        await stop_event.wait()
    monkeypatch.setattr(main, "init_db", lambda: None)
    monkeypatch.setattr(main, "collection_loop", idle_loop)
    candles = [Candle(1700000000+i*60, Decimal("10") if i < 30 else Decimal(str(10+i/10)),
                      (Decimal("10") if i < 30 else Decimal(str(10+i/10))) + Decimal("1"),
                      Decimal("9"), Decimal("10") if i < 30 else Decimal(str(10+i/10)), Decimal("100"))
               for i in range(60)]
    monkeypatch.setattr(main, "load_stored_candles", lambda *args: candles)
    with TestClient(main.app) as client:
        response = client.post("/backtest/sma/stored/BTCUSDT", json={
            "resolution":"60", "start":1700000000, "end":1700005000,
            "fast_period":2, "slow_period":3, "train_fraction":"0.7",
        })
    assert response.status_code == 200
    data = response.json()
    assert data["method"] == "chronological_holdout_no_parameter_optimization"
    assert data["train_candles"] == 42
    assert data["test_candles"] == 18
    assert "out_of_sample_test" in data


def test_stored_walk_forward_endpoint_is_historical_only(monkeypatch):
    from decimal import Decimal
    from app.market_data import Candle
    async def idle_loop(stop_event):
        await stop_event.wait()
    monkeypatch.setattr(main, "init_db", lambda: None)
    monkeypatch.setattr(main, "collection_loop", idle_loop)
    candles = []
    for i in range(180):
        close = Decimal(str(100 + ((i % 24) - 12) * (1 if (i // 24) % 2 == 0 else -1)))
        candles.append(Candle(1700000000+i*60, close, close+2, close-2, close, Decimal("1000")))
    monkeypatch.setattr(main, "load_stored_candles", lambda *args: candles)
    with TestClient(main.app) as client:
        response = client.post("/backtest/walk-forward/BTCUSDT", json={
            "resolution":"60", "start":1700000000, "end":1700020000,
            "initial_train_candles":60, "test_candles":30, "max_folds":4,
            "fast_period":2, "slow_period":5,
        })
    assert response.status_code == 200
    data = response.json()
    assert data["mode"] == "historical_walk_forward_only"
    assert data["fold_count"] == 4
    assert data["exchange_order_submitted"] is False
    assert data["parameter_optimization_performed"] is False
