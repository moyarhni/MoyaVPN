from decimal import Decimal
import pytest
from app.backtest import BacktestConfig, BacktestError, run_sma_backtest
from app.market_data import Candle


def make_candles(closes):
    result = []
    for i, raw in enumerate(closes):
        c = Decimal(str(raw))
        result.append(Candle(1700000000 + i * 60, c, c * Decimal("1.01"), c * Decimal("0.99"), c, Decimal("100")))
    return result


def test_sma_backtest_executes_only_after_signal_candle_and_accounts_for_fees():
    candles = make_candles([10, 10, 10, 12, 14, 12, 10, 8, 10, 12, 14, 16])
    result = run_sma_backtest(candles, BacktestConfig(
        fast_period=2, slow_period=3, starting_balance=Decimal("1000"),
        stake_quote=Decimal("100"), fee_rate=Decimal("0.001"),
        slippage_bps=Decimal("0"), stop_loss_pct=None, take_profit_pct=None,
    ))
    assert result["mode"] == "historical_backtest_only"
    assert result["candle_count"] == len(candles)
    assert result["trade_count"] >= 1
    trade = result["trades"][0]
    assert trade["entry_timestamp"] > candles[0].timestamp
    assert Decimal(trade["entry_fee"]) > 0
    assert Decimal(trade["exit_fee"]) > 0
    assert result["assumptions"]


def test_stop_loss_wins_when_stop_and_target_both_touch_same_candle():
    candles = make_candles([10, 10, 10, 12, 14, 12, 10, 8, 10, 12, 14])
    # Widen the high/low range after an entry so both barriers are crossed.
    candles = list(candles)
    candles[5] = Candle(candles[5].timestamp, Decimal("12"), Decimal("20"), Decimal("1"), Decimal("12"), Decimal("100"))
    result = run_sma_backtest(candles, BacktestConfig(
        fast_period=2, slow_period=3, fee_rate=Decimal("0"), slippage_bps=Decimal("0"),
        stop_loss_pct=Decimal("0.02"), take_profit_pct=Decimal("0.02"),
    ))
    assert any(t["exit_reason"] == "stop_loss" for t in result["trades"])


def test_rejects_invalid_periods_and_bad_ohlc():
    with pytest.raises(BacktestError):
        run_sma_backtest(make_candles([1, 2, 3, 4]), BacktestConfig(fast_period=3, slow_period=3))
    candles = make_candles([10, 10, 10, 12, 14])
    candles[2] = Candle(candles[2].timestamp, Decimal("10"), Decimal("9"), Decimal("8"), Decimal("10"), Decimal("1"))
    with pytest.raises(BacktestError):
        run_sma_backtest(candles, BacktestConfig(fast_period=2, slow_period=3))


def test_requires_enough_candles():
    with pytest.raises(BacktestError):
        run_sma_backtest(make_candles([1, 2, 3]), BacktestConfig(fast_period=2, slow_period=3))

@pytest.mark.parametrize("strategy", ["sma_crossover", "ema_crossover", "donchian_breakout"])
def test_all_baseline_strategies_run_without_future_data(strategy):
    closes = [10, 10, 10, 12, 14, 12, 10, 8, 10, 12, 14, 16, 18, 15, 12, 9, 8, 11, 14, 17]
    candles = make_candles(closes)
    result = run_sma_backtest(candles, BacktestConfig(
        fast_period=2, slow_period=3, strategy=strategy, fee_rate=Decimal("0"),
        slippage_bps=Decimal("0"), stop_loss_pct=None, take_profit_pct=None,
    ))
    assert result["strategy"] == strategy
    assert result["mode"] == "historical_backtest_only"
    assert result["candle_count"] == len(candles)


def test_rejects_unknown_strategy():
    with pytest.raises(BacktestError):
        run_sma_backtest(make_candles([10, 11, 12, 13, 14, 15]),
                         BacktestConfig(fast_period=2, slow_period=3, strategy="future_peeking"))
