from decimal import Decimal
import pytest
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.db import Base
from app.paper_ledger import (
    PaperLedgerError, PaperPosition, PaperTrade, PaperWallet,
    initialize_wallet, open_position, close_position, wallet_snapshot,
)

BOOK = {"result": {
    "ask": [{"price": "101", "quantity": "20"}],
    "bid": [{"price": "100", "quantity": "20"}],
}}

@pytest.fixture
def db():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, expire_on_commit=False)
    with Session() as session:
        yield session
    Base.metadata.drop_all(engine)
    engine.dispose()


def test_wallet_and_long_lifecycle_records_net_loss_and_pauses_entries(db):
    initialize_wallet(db, "1000", "USDT")
    pos, fill, replay = open_position(db, symbol="BTCUSDT", direction="LONG", quantity="1",
        leverage="1", book=BOOK, idempotency_key="open-key-0001", fee_rate="0")
    assert not replay and fill.status == "filled"
    assert Decimal(wallet_snapshot(db)["available_balance"]) == Decimal("899")
    trade, exit_fill, replay = close_position(db, position_id=pos.id,
        book={"result":{"ask":[{"price":"90","quantity":"20"}],"bid":[{"price":"89","quantity":"20"}]}},
        idempotency_key="close-key-0001", fee_rate="0")
    assert not replay and exit_fill.status == "filled"
    assert Decimal(trade.realized_pnl) == Decimal("-12")
    snap = wallet_snapshot(db)
    assert snap["entry_paused"] is True
    assert snap["pause_reason"] == "first_realized_loss"
    assert db.scalar(select(PaperTrade).where(PaperTrade.position_id == pos.id)) is not None
    with pytest.raises(PaperLedgerError, match="paused"):
        open_position(db, symbol="BTCUSDT", direction="LONG", quantity="1", leverage="1",
            book=BOOK, idempotency_key="open-key-0002", fee_rate="0")


def test_short_pnl_and_idempotent_open_and_close(db):
    initialize_wallet(db, "1000")
    pos, fill, replay = open_position(db, symbol="BTCUSDT", direction="SHORT", quantity="1",
        leverage="2", book=BOOK, idempotency_key="open-key-1001", fee_rate="0")
    assert not replay and fill.side.value == "SELL"
    same, no_fill, replay = open_position(db, symbol="BTCUSDT", direction="SHORT", quantity="1",
        leverage="2", book=BOOK, idempotency_key="open-key-1001", fee_rate="0")
    assert replay and same.id == pos.id and no_fill is None
    trade, fill, replay = close_position(db, position_id=pos.id,
        book={"result":{"ask":[{"price":"95","quantity":"20"}],"bid":[{"price":"94","quantity":"20"}]}},
        idempotency_key="close-key-1001", fee_rate="0")
    assert Decimal(trade.realized_pnl) == Decimal("5")
    same_trade, no_fill, replay = close_position(db, position_id=pos.id, book=BOOK,
        idempotency_key="close-key-1001", fee_rate="0")
    assert replay and same_trade.id == trade.id and no_fill is None
    assert db.get(PaperPosition, pos.id).status == "CLOSED"


def test_requires_full_fill_and_prevents_overdraft(db):
    initialize_wallet(db, "10")
    with pytest.raises(PaperLedgerError, match="Insufficient"):
        open_position(db, symbol="BTCUSDT", direction="LONG", quantity="1", leverage="1",
            book=BOOK, idempotency_key="open-key-2001", fee_rate="0")
    with pytest.raises(PaperLedgerError, match="full simulated fill"):
        open_position(db, symbol="BTCUSDT", direction="LONG", quantity="30", leverage="1",
            book=BOOK, idempotency_key="open-key-2002", fee_rate="0")


def test_existing_positions_can_still_close_after_entry_lock(db):
    initialize_wallet(db, "2000")
    first, _, _ = open_position(db, symbol="BTCUSDT", direction="LONG", quantity="1", leverage="1",
        book=BOOK, idempotency_key="open-key-3001", fee_rate="0")
    second, _, _ = open_position(db, symbol="BTCUSDT", direction="LONG", quantity="1", leverage="1",
        book=BOOK, idempotency_key="open-key-3002", fee_rate="0")
    close_position(db, position_id=first.id,
        book={"result":{"ask":[{"price":"90","quantity":"20"}],"bid":[{"price":"89","quantity":"20"}]}},
        idempotency_key="close-key-3001", fee_rate="0")
    assert wallet_snapshot(db)["entry_paused"] is True
    trade, _, _ = close_position(db, position_id=second.id,
        book={"result":{"ask":[{"price":"110","quantity":"20"}],"bid":[{"price":"109","quantity":"20"}]}},
        idempotency_key="close-key-3002", fee_rate="0")
    assert Decimal(trade.realized_pnl) == Decimal("8")
    assert db.get(PaperPosition, second.id).status == "CLOSED"
    assert wallet_snapshot(db)["entry_paused"] is True


def test_first_loss_persists_central_circuit_in_same_transaction(db):
    from app.circuit_breaker import RiskCircuitState
    initialize_wallet(db, "1000", "USDT")
    pos, _, _ = open_position(db, symbol="BTCUSDT", direction="LONG", quantity="1",
        leverage="1", book=BOOK, idempotency_key="open-key-central-1", fee_rate="0")
    close_position(db, position_id=pos.id,
        book={"result":{"ask":[{"price":"90","quantity":"20"}],"bid":[{"price":"89","quantity":"20"}]}},
        idempotency_key="close-key-central-1", fee_rate="0")
    state = db.get(RiskCircuitState, 1)
    assert state is not None and state.entries_paused is True
    assert state.reason == "first_realized_loss"


def test_central_circuit_blocks_entries_even_if_wallet_flag_is_stale(db):
    from app.circuit_breaker import pause_entries_in_session
    initialize_wallet(db, "1000", "USDT")
    pause_entries_in_session(db, "operator_pause")
    db.commit()
    with pytest.raises(PaperLedgerError, match="paused"):
        open_position(db, symbol="BTCUSDT", direction="LONG", quantity="1",
            leverage="1", book=BOOK, idempotency_key="open-key-central-2", fee_rate="0")
