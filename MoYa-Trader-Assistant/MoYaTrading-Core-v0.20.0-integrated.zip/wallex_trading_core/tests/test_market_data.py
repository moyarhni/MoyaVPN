import pytest
from decimal import Decimal
from app.market_data import MarketDataError, normalize_udf_candles


def sample(**updates):
    data = {"s": "ok", "t": [1700000000, 1700000060],
            "o": ["10", "11"], "h": ["12", "13"],
            "l": ["9", "10"], "c": ["11", "12"],
            "v": ["100", "120"]}
    data.update(updates)
    return data


def test_normalizes_udf_arrays_to_decimal_candles():
    candles = normalize_udf_candles(sample())
    assert len(candles) == 2
    assert candles[0].timestamp == 1700000000
    assert candles[0].open == Decimal("10")
    assert candles[1].volume == Decimal("120")


def test_no_data_is_valid_empty_result():
    assert normalize_udf_candles({"s": "no_data"}) == []


@pytest.mark.parametrize("payload", [
    {"s": "error"},
    sample(c=["11"]),
    sample(t=[1700000060, 1700000000]),
    sample(h=["10", "13"]),
    sample(v=["-1", "120"]),
    sample(c=["NaN", "12"]),
])
def test_rejects_bad_candle_payloads(payload):
    with pytest.raises(MarketDataError):
        normalize_udf_candles(payload)


def test_empty_ok_arrays_are_valid():
    assert normalize_udf_candles({"s": "ok", "t": [], "o": [], "h": [], "l": [], "c": [], "v": []}) == []

from app.market_data import normalize_ticker_snapshot


def test_normalizes_valid_ticker_fields():
    ticker = normalize_ticker_snapshot({
        "lastPrice": "100.25", "bidPrice": "100.20", "askPrice": "100.30",
        "24h_volume": "12.5", "24h_quoteVolume": "1253.125",
    })
    assert ticker.last_price == Decimal("100.25")
    assert ticker.bid_price == Decimal("100.20")
    assert ticker.volume_24h == Decimal("12.5")


@pytest.mark.parametrize("stats", [
    {},
    {"lastPrice": "0"},
    {"lastPrice": "NaN"},
    {"lastPrice": "10", "bidPrice": "11", "askPrice": "10"},
    {"lastPrice": "10", "24h_volume": "-1"},
])
def test_rejects_invalid_ticker_fields(stats):
    with pytest.raises(MarketDataError):
        normalize_ticker_snapshot(stats)


def test_ticker_accepts_optional_missing_bid_ask():
    ticker = normalize_ticker_snapshot({"lastPrice": "10"})
    assert ticker.bid_price is None
    assert ticker.ask_price is None


def test_live_style_udf_payload_with_all_arrays():
    payload = {
        "s": "ok", "t": [1794936240, 1794936300],
        "o": ["64046.84", "63874.68"],
        "h": ["64100", "63900"],
        "l": ["63800", "63700"],
        "c": ["63874.68", "63853.53"],
        "v": ["0.25", "1.75"],
    }
    candles = normalize_udf_candles(payload)
    assert len(candles) == 2
    assert candles[0].timestamp == 1794936240
    assert candles[1].close == Decimal("63853.53")
