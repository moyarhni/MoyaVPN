import asyncio
import httpx
from app.wallex import WallexClient


def test_udf_config_and_symbol_requests_use_expected_paths_and_params():
    seen = []
    def handler(request):
        seen.append((request.url.path, dict(request.url.params)))
        if request.url.path.endswith("/config"):
            return httpx.Response(200, json={"supported_resolutions": ["1", "15", "60"]})
        return httpx.Response(200, json={"name": "BTCUSDT", "ticker": "BTCUSDT"})

    async def run():
        client = WallexClient(base_url="https://unit.test")
        await client.client.aclose()
        client.client = httpx.AsyncClient(base_url="https://unit.test", transport=httpx.MockTransport(handler))
        try:
            config = await client.udf_config()
            symbol = await client.udf_symbol("btcusdt")
            return config, symbol
        finally:
            await client.close()

    config, symbol = asyncio.run(run())
    assert config["supported_resolutions"] == ["1", "15", "60"]
    assert symbol["ticker"] == "BTCUSDT"
    assert seen == [("/v1/udf/config", {}), ("/v1/udf/symbols", {"symbol": "BTCUSDT"})]
