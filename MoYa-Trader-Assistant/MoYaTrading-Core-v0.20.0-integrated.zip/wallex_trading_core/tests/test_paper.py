from decimal import Decimal
import pytest
from app.paper import Side, PaperSimulationError, simulate_market_fill

BOOK = {"result": {
    "ask": [{"price": "101", "quantity": "2"}, {"price": "102", "quantity": "3"}, {"price": "104", "quantity": "5"}],
    "bid": [{"price": "100", "quantity": "1"}, {"price": "99", "quantity": "4"}, {"price": "97", "quantity": "5"}],
}}

def test_buy_walks_asks_and_computes_vwap_and_fee():
    fill = simulate_market_fill(BOOK, Side.BUY, "3", fee_rate="0.001", max_slippage_bps="200")
    assert fill.status == "filled"
    assert fill.filled_quantity == Decimal("3")
    assert fill.quote_value == Decimal("304")
    assert fill.average_price == Decimal("304") / Decimal("3")
    assert fill.fee_quote == Decimal("0.304")
    assert fill.levels_consumed == 2

def test_sell_walks_bids():
    fill = simulate_market_fill(BOOK, Side.SELL, "3", fee_rate="0.001", max_slippage_bps="200")
    assert fill.status == "filled"
    assert fill.quote_value == Decimal("298")
    assert fill.average_price == Decimal("298") / Decimal("3")

def test_slippage_cap_prevents_worse_levels_and_reports_partial():
    fill = simulate_market_fill(BOOK, "BUY", "4", max_slippage_bps="50")
    assert fill.status == "partial"
    assert fill.filled_quantity == Decimal("2")
    assert fill.unfilled_quantity == Decimal("2")

def test_rejects_unsorted_or_invalid_book():
    with pytest.raises(PaperSimulationError):
        simulate_market_fill({"ask": list(reversed(BOOK["result"]["ask"])), "bid": BOOK["result"]["bid"]}, "BUY", "1")
    with pytest.raises(PaperSimulationError):
        simulate_market_fill(BOOK, "BUY", "NaN")

def test_no_liquidity_is_rejected():
    with pytest.raises(PaperSimulationError):
        simulate_market_fill({"ask": [], "bid": []}, "BUY", "1")


def test_api_paper_endpoint_is_explicitly_non_executing(monkeypatch):
    import asyncio
    from app import main

    async def fake_depth(symbol):
        assert symbol == "BTCUSDT"
        return BOOK

    monkeypatch.setattr(main.client, "depth", fake_depth)
    response = asyncio.run(main.paper_simulate(
        "btcusdt", main.PaperSimulationRequest(side="BUY", quantity=Decimal("1"))
    ))
    assert response["mode"] == "paper_only"
    assert response["exchange_order_submitted"] is False
    assert response["filled_quantity"] == "1"
