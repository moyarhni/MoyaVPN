from app.composite_patterns import combine_patterns

def test_bullish_composite_requires_two_matching_patterns():
    result = combine_patterns({"patterns_detected": [
        {"name": "Breakout", "direction": "bullish"},
        {"name": "Volume Spike", "direction": "bullish"}]}, indicator_signal="BUY")
    assert result["count"] == 1
    assert result["combinations"][0]["direction"] == "bullish"
    assert result["scores_are_probabilities"] is False

def test_no_composite_from_single_pattern():
    assert combine_patterns({"patterns_detected": [{"name": "Breakout", "direction": "bullish"}]})["count"] == 0
