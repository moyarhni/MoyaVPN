from decimal import Decimal as D
import pytest
from app.position_sizing import Side, SizingRequest, SizingError, size_position


def request(**kw):
    base = dict(side=Side.LONG, equity=D("10000"), risk_fraction=D("0.01"),
        entry_price=D("100"), stop_price=D("95"), available_collateral=D("1000"),
        max_leverage=D("3"), max_notional=D("5000"), quantity_step=D("0.01"),
        minimum_quantity=D("0.01"), minimum_notional=D("1"), fee_rate=D("0.001"))
    base.update(kw)
    return SizingRequest(**base)


def test_long_size_respects_risk_budget_and_costs():
    d = size_position(request())
    assert d.accepted and d.quantity > 0
    assert d.estimated_loss_at_stop <= d.risk_budget
    assert d.notional <= D("5000")


def test_short_sizing_works_symmetrically():
    d = size_position(request(side=Side.SHORT, stop_price=D("105")))
    assert d.accepted and d.quantity > 0


def test_wrong_side_stop_rejected():
    with pytest.raises(SizingError):
        size_position(request(stop_price=D("101")))


def test_liquidation_before_stop_rejects():
    d = size_position(request(liquidation_price=D("96")))
    assert not d.accepted and d.limiting_factor == "liquidation_buffer"


def test_total_exposure_cap_applies():
    d = size_position(request(current_exposure=D("4900"), max_total_exposure=D("5000")))
    assert d.accepted and d.notional <= D("100")


def test_insufficient_collateral_caps_quantity():
    d = size_position(request(available_collateral=D("10")))
    assert d.accepted and d.collateral_required <= D("10")


def test_below_exchange_minimum_rejected():
    d = size_position(request(max_notional=D("0.5")))
    assert not d.accepted and d.quantity == 0
