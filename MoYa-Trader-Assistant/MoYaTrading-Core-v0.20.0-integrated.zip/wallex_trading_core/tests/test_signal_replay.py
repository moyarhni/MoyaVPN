from decimal import Decimal
import pytest
from app.market_data import Candle
from app.signal_replay import ReplayConfig, SignalReplayError, run_signal_replay


def candles_from(closes):
    out=[]
    for i, raw in enumerate(closes):
        c=Decimal(str(raw))
        out.append(Candle(1700000000+i*60,c,c*Decimal('1.01'),c*Decimal('.99'),c,Decimal('100')))
    return out


def test_signal_replay_is_research_only_and_uses_two_sided_engine():
    prices = [100 + i*.8 for i in range(80)] + [164 - i*.9 for i in range(80)] + [92 + i*.7 for i in range(80)]
    result = run_signal_replay(candles_from(prices))
    assert result['engine'] == 'trend_momentum_v1'
    assert result['mode'] == 'historical_signal_replay_only'
    assert result['candle_count'] == len(prices)
    assert result['trade_count'] == len(result['trades'])
    assert 'does not model exchange margin' in result['warnings'][-1]


def test_signal_replay_rejects_non_chronological_candles():
    data=candles_from([100+i for i in range(80)])
    data[5]=Candle(data[4].timestamp,*[data[5].open,data[5].high,data[5].low,data[5].close,data[5].volume])
    with pytest.raises(SignalReplayError):
        run_signal_replay(data)


def test_signal_replay_rejects_too_short_history():
    with pytest.raises(SignalReplayError):
        run_signal_replay(candles_from([100+i for i in range(20)]))
