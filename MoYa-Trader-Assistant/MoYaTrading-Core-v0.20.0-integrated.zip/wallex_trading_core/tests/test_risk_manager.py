from decimal import Decimal as D
from app.risk_manager import size_spot_position

def test_spot_position_respects_risk_and_cap():
    result = size_spot_position(quote_balance=D("10000"), entry=D("100"), stop=D("95"))
    assert result["allowed"] is True
    assert D(result["position_value"]) <= D("2500")

def test_daily_loss_limit_blocks_new_risk():
    result = size_spot_position(quote_balance=D("10000"), entry=D("100"), stop=D("95"), daily_realized_loss=D("300"))
    assert result["allowed"] is False
    assert result["reason"] == "daily_loss_limit_reached"
