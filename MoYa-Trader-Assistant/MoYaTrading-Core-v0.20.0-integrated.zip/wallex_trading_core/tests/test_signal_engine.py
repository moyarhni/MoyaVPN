from decimal import Decimal
import pytest
from app.market_data import Candle
from app.signal_engine import analyze_closed_candles, SignalAnalysisError, SignalConfig


def make_candles(closes, volumes=None):
    volumes = volumes or [Decimal("100")] * len(closes)
    out = []
    for i, (close, volume) in enumerate(zip(closes, volumes)):
        close = Decimal(str(close))
        out.append(Candle(i + 1, close, close * Decimal("1.01"), close * Decimal("0.99"), close, Decimal(str(volume))))
    return out


def test_uptrend_generates_long_candidate():
    closes = [100 + i * 2 for i in range(45)]
    result = analyze_closed_candles(make_candles(closes))
    assert result["signal"] == "LONG"
    assert result["reference_stop"] is not None
    assert result["reference_target"] is not None
    assert result["mode"] == "research_only_no_order_execution"


def test_downtrend_generates_short_candidate():
    closes = [200 - i * 2 for i in range(45)]
    result = analyze_closed_candles(make_candles(closes))
    assert result["signal"] == "SHORT"
    assert result["reference_stop"] is not None
    assert result["reference_target"] is not None


def test_insufficient_candles_rejected():
    with pytest.raises(SignalAnalysisError):
        analyze_closed_candles(make_candles([100, 101, 102]))


def test_non_chronological_candles_rejected():
    candles = make_candles([100 + i for i in range(45)])
    candles[10] = Candle(1, candles[10].open, candles[10].high, candles[10].low, candles[10].close, candles[10].volume)
    with pytest.raises(SignalAnalysisError):
        analyze_closed_candles(candles)


def test_invalid_volatility_config_rejected():
    with pytest.raises(SignalAnalysisError):
        analyze_closed_candles(make_candles([100 + i for i in range(45)]), SignalConfig(min_atr_pct=Decimal("0.1"), max_atr_pct=Decimal("0.01")))
