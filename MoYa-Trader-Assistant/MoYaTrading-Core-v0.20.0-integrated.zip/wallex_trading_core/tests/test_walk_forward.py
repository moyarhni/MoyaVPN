from decimal import Decimal
import pytest
from app.market_data import Candle
from app.backtest import BacktestConfig
from app.walk_forward import evaluate_walk_forward, WalkForwardError


def series(n=180):
    out=[]
    for i in range(n):
        # Repeating waves with enough crossovers for deterministic tests.
        close = Decimal(str(100 + ((i % 24) - 12) * (1 if (i // 24) % 2 == 0 else -1)))
        out.append(Candle(1_700_000_000+i*60, close, close+2, close-2, close, Decimal("1000")))
    return out


def test_walk_forward_has_non_overlapping_oos_folds_and_fixed_parameters():
    candles=series()
    result=evaluate_walk_forward(candles, BacktestConfig(fast_period=2, slow_period=5),
                                 initial_train_size=60, test_size=30, max_folds=4)
    assert result["fold_count"] == 4
    assert result["parameters_fixed_across_folds"] is True
    assert result["parameter_optimization_performed"] is False
    assert result["out_of_sample_candles"] == 120
    for a,b in zip(result["folds"], result["folds"][1:]):
        assert a["test_end_timestamp"] < b["test_start_timestamp"]


def test_walk_forward_requires_sufficient_initial_history():
    with pytest.raises(WalkForwardError):
        evaluate_walk_forward(series(), BacktestConfig(fast_period=2, slow_period=10),
                              initial_train_size=8, test_size=20)


def test_warmup_does_not_create_pre_oos_trades():
    candles=series()
    config=BacktestConfig(fast_period=2, slow_period=5, stop_loss_pct=None)
    from app.backtest import run_sma_backtest
    result=run_sma_backtest(candles[:80], config, trade_start_index=40)
    assert all(t["entry_timestamp"] >= candles[40].timestamp for t in result["trades"])
