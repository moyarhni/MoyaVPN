from decimal import Decimal as D
import pytest
from app.market_data import Candle
from app.pattern_engine import detect_patterns, PatternConfig, PatternDetectionError


def series(rows):
    out=[]
    for i,(o,h,l,c,v) in enumerate(rows):
        out.append(Candle(i+1,*map(D,map(str,(o,h,l,c,v)))))
    return out


def test_detects_doji_only_after_closed_candle():
    data=series([(10,11,9,10,100)]*10+[(10,11,9,10.01,100)])
    result=detect_patterns(data)
    assert any(p['pattern']=='doji' for p in result['patterns_detected'])
    assert result['safety']['uses_future_data_for_detection'] is False


def test_detects_bullish_engulfing():
    rows=[(10,11,9,10,100)]*10+[(10,10.2,8.8,9,100),(8.8,10.5,8.7,10.3,120)]
    result=detect_patterns(series(rows))
    assert any(p['pattern']=='bullish_engulfing' for p in result['patterns_detected'])


def test_detects_volume_spike():
    rows=[(10,10.2,9.8,10,100)]*20+[(10,10.2,9.8,10.1,250)]
    result=detect_patterns(series(rows))
    assert any(p['pattern']=='volume_spike' for p in result['patterns_detected'])


def test_rejects_non_chronological_data():
    data=series([(10,11,9,10,100)]*8)
    data[4]=Candle(1,data[4].open,data[4].high,data[4].low,data[4].close,data[4].volume)
    with pytest.raises(PatternDetectionError):
        detect_patterns(data)


def test_pivot_is_not_available_until_right_side_bars_close():
    # The candidate high at index 4 is not confirmed until three later bars exist.
    data=series([(10,11,9,10,100),(10,12,9,11,100),(11,13,10,12,100),
                 (12,14,11,13,100),(13,20,12,14,100),(14,15,11,12,100)])
    result=detect_patterns(data,PatternConfig(pivot_left=2,pivot_right=3))
    # There is no future leakage: a pivot at the final source index is never confirmed.
    assert result['safety']['uses_future_data_for_detection'] is False


def test_catalog_contains_29_patterns_and_marks_live_disabled():
    from app.pattern_catalog import PATTERNS, IMPLEMENTED
    assert len(PATTERNS) == 29
    assert len(IMPLEMENTED) >= 15


def test_detector_exposes_catalog_only_patterns_separately():
    result=detect_patterns(series([(10,11,9,10,100)]*30))
    assert "cup_and_handle" in result["detector_coverage"]["implemented"]
    assert result["detector_coverage"]["library_only_not_yet_detected"] == []
    assert result["safety"]["live_trading_enabled"] is False
