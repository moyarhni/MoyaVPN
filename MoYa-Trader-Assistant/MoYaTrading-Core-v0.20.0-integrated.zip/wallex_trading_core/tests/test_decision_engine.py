from decimal import Decimal as D
import pytest
from app.decision_engine import make_decision, DecisionConfig
from app.market_data import Candle


def sample_candles():
    out=[]
    price=D("100")
    for i in range(80):
        # Persistent, modest uptrend with valid OHLC and deterministic volume.
        close=price + D("0.25")
        out.append(Candle(i+1, price, close+D("0.2"), price-D("0.1"), close, D("1000")))
        price=close
    return out


def test_decision_is_research_only_and_never_submits_orders():
    result=make_decision(sample_candles(), symbol="btc-usdt", quote_balance=D("1000"))
    assert result["symbol"] == "BTC-USDT"
    assert result["safety"]["live_trading_enabled"] is False
    assert result["safety"]["orders_submitted"] is False
    assert result["action"] in {"BUY", "SELL", "HOLD", "NO_TRADE"}


def test_circuit_breaker_blocks_new_buy():
    result=make_decision(sample_candles(), symbol="BTCUSDT", quote_balance=D("1000"), entry_paused=True)
    assert result["action"] == "NO_TRADE"
    assert result["position"]["suggested_buy_quantity"] == "0"


def test_spot_never_opens_short():
    result=make_decision(sample_candles(), symbol="BTCUSDT", quote_balance=D("1000"), base_quantity=D("0"))
    assert result["action"] != "SHORT"
    assert result["safety"]["spot_shorting_disabled"] is True


def test_invalid_balance_rejected():
    with pytest.raises(ValueError):
        make_decision(sample_candles(), symbol="BTCUSDT", quote_balance=D("-1"))


def test_config_risk_cap():
    with pytest.raises(ValueError):
        DecisionConfig(max_risk_fraction=D("0.10")).validate()
