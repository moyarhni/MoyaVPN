from decimal import Decimal
import pytest
from fastapi import HTTPException
from app.main import MarketAnalysisRequest, run_market_analysis, detect_market_patterns


def payload(last_candle_closed=True):
    candles = []
    for i in range(45):
        close = Decimal(100 + i * 2)
        candles.append({"timestamp": i + 1, "open": close, "high": close * Decimal("1.01"),
                        "low": close * Decimal("0.99"), "close": close, "volume": Decimal(100)})
    return MarketAnalysisRequest(candles=candles, last_candle_closed=last_candle_closed)


def test_analysis_api_returns_two_sided_research_signal():
    result = run_market_analysis(payload())
    assert result["signal"] == "LONG"
    assert result["mode"] == "research_only_no_order_execution"


def test_analysis_api_rejects_unclosed_final_candle():
    with pytest.raises(HTTPException) as exc:
        run_market_analysis(payload(False))
    assert exc.value.status_code == 422



def test_pattern_detection_endpoint_is_research_only():
    candles = [{"timestamp":i+1,"open":"10","high":"11","low":"9","close":"10","volume":"100"} for i in range(30)]
    result = detect_market_patterns(MarketAnalysisRequest(candles=candles,last_candle_closed=True))
    assert result["engine"] == "moya_pattern_engine_v1"
    assert result["mode"] == "research_only_no_order_execution"
    assert result["safety"]["live_trading_enabled"] is False


def test_pattern_detection_endpoint_rejects_open_last_candle():
    candles = [{"timestamp":i+1,"open":"10","high":"11","low":"9","close":"10","volume":"100"} for i in range(30)]
    with pytest.raises(HTTPException) as exc:
        detect_market_patterns(MarketAnalysisRequest(candles=candles,last_candle_closed=False))
    assert exc.value.status_code == 422
