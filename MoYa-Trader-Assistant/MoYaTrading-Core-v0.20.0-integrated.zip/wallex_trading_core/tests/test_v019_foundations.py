from decimal import Decimal
import pytest
from app.futures_scaffold import estimate_notional, FuturesRiskInput
from app.order_gateway import LiveWallexGateway, ExecutionDisabled

def test_futures_scaffold_is_bounded_and_math_only():
    assert estimate_notional(Decimal('100'), Decimal('2')) == Decimal('200')
    with pytest.raises(ValueError): estimate_notional(Decimal('100'), Decimal('20'))

def test_live_gateway_fails_closed():
    with pytest.raises(ExecutionDisabled): LiveWallexGateway().submit({'side':'BUY'})

def test_futures_risk_input_validation():
    FuturesRiskInput(Decimal('100'), Decimal('10'), Decimal('9'), Decimal('2'), Decimal('.005')).validate()
    with pytest.raises(ValueError):
        FuturesRiskInput(Decimal('100'), Decimal('10'), Decimal('9'), Decimal('20'), Decimal('.005')).validate()
