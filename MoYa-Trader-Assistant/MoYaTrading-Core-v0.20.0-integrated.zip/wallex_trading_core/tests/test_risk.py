from decimal import Decimal
import pytest
from app.risk import TradeIntent, Direction, validate_trade_intent, EntryCircuitBreaker

def test_valid_long_and_short_intents():
    for direction in (Direction.LONG, Direction.SHORT):
        validate_trade_intent(TradeIntent("BTCUSDT", direction, Decimal("0.01"), Decimal("60000")))

@pytest.mark.parametrize("qty,price", [("0","10"), ("1","0"), ("-1","10")])
def test_rejects_non_positive_values(qty, price):
    with pytest.raises(ValueError):
        validate_trade_intent(TradeIntent("BTCUSDT", Direction.LONG, Decimal(qty), Decimal(price)))

def test_first_realized_loss_pauses_new_entries():
    breaker = EntryCircuitBreaker()
    assert breaker.can_open_new_position()
    breaker.on_trade_closed(Decimal("-0.01"))
    assert not breaker.can_open_new_position()
    assert breaker.reason == "first_realized_loss"

def test_profit_does_not_pause_entries():
    breaker = EntryCircuitBreaker()
    breaker.on_trade_closed(Decimal("1.25"))
    assert breaker.can_open_new_position()
