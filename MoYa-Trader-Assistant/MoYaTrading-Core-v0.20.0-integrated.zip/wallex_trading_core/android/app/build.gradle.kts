plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "ir.moyatrading.app"; compileSdk = 35
    defaultConfig { applicationId = "ir.moyatrading.app"; minSdk = 26; targetSdk = 35; versionCode = 19; versionName = "0.19.0" }
}
