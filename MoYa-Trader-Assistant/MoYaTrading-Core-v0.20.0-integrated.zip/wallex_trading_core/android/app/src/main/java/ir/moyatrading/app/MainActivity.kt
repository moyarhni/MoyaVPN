package ir.moyatrading.app

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

/** Starter shell only. Configure a trusted HTTPS API endpoint before use. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val status = TextView(this).apply {
            text = "MoYaTrading 0.19.0\n\nClient scaffold ready.\nLive trading: DISABLED\nConfigure a trusted HTTPS server before connecting."
            textSize = 18f
            setPadding(32, 48, 32, 32)
        }
        setContentView(status)
    }
}
