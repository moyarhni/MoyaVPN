import os, tempfile
import pytest
from app.wallex_trade import WallexSpotTrader, WallexTradeError
from app.live_guard import LiveGuard, ENABLE_PHRASE
from app.order_gateway import LiveWallexGateway, ExecutionDisabled


class Fake:
    def __init__(self, status=201, success=True):
        self.calls, self.status, self.success = [], status, success
    def __call__(self, method, url, headers, body):
        self.calls.append((method, url, headers, body))
        return self.status, {"success": self.success, "message": "m", "result": {"clientOrderId": "c1"}}


def _guard():
    return LiveGuard(os.path.join(tempfile.mkdtemp(), "g.db"))


def test_place_order_request_shape_and_hidden_key():
    f = Fake()
    t = WallexSpotTrader("SECRETKEY", requester=f)
    res = t.place_limit_order("btcusdt", "buy", "65000.5", "0.001", "c1")
    method, url, headers, body = f.calls[0]
    assert (method, url) == ("POST", "https://api.wallex.ir/v1/account/orders")
    assert headers["x-api-key"] == "SECRETKEY"
    assert body == {"client_id": "c1", "symbol": "BTCUSDT", "side": "BUY", "type": "LIMIT",
                    "price": "65000.5", "quantity": "0.001"}
    assert res["clientOrderId"] == "c1"
    assert "SECRETKEY" not in repr(t)


@pytest.mark.parametrize("kw", [
    dict(symbol="BTC/USDT", side="BUY", price="1", quantity="1", client_id="a"),
    dict(symbol="BTCUSDT", side="SHORT", price="1", quantity="1", client_id="a"),
    dict(symbol="BTCUSDT", side="BUY", price="0", quantity="1", client_id="a"),
    dict(symbol="BTCUSDT", side="BUY", price="1", quantity="-1", client_id="a"),
    dict(symbol="BTCUSDT", side="BUY", price="NaN", quantity="1", client_id="a"),
    dict(symbol="BTCUSDT", side="BUY", price="1", quantity="1", client_id="bad id!"),
])
def test_invalid_orders_rejected_before_any_request(kw):
    f = Fake()
    with pytest.raises(WallexTradeError):
        WallexSpotTrader("k", requester=f).place_limit_order(**kw)
    assert f.calls == []


def test_failures_raise_and_key_required():
    with pytest.raises(WallexTradeError):
        WallexSpotTrader("k", requester=Fake(status=400)).place_limit_order("BTCUSDT", "BUY", "1", "1", "a")
    with pytest.raises(WallexTradeError):
        WallexSpotTrader("k", requester=Fake(success=False)).place_limit_order("BTCUSDT", "BUY", "1", "1", "a")
    with pytest.raises(WallexTradeError):
        WallexSpotTrader("  ")


def test_get_and_cancel_paths():
    f = Fake(status=200)
    t = WallexSpotTrader("k", requester=f)
    t.get_order("c1"); t.cancel_order("c1")
    assert [(c[0], c[1]) for c in f.calls] == [("GET", "https://api.wallex.ir/v1/account/orders/c1"),
                                               ("DELETE", "https://api.wallex.ir/v1/account/orders/c1")]


def test_gateway_sends_only_when_guard_allows_and_close_always_passes():
    f, g = Fake(), _guard()
    gw = LiveWallexGateway(g, WallexSpotTrader("k", requester=f))
    order = {"symbol": "BTCUSDT", "side": "BUY", "price": "1", "quantity": "1", "client_id": "o1"}
    with pytest.raises(ExecutionDisabled):  # default: disabled
        gw.submit(order)
    assert f.calls == []
    g.enable(ENABLE_PHRASE)
    assert gw.submit(order)["clientOrderId"] == "c1" and len(f.calls) == 1
    g.record_realized_pnl("t1", "-1")  # first loss -> locked
    with pytest.raises(ExecutionDisabled, match="locked"):
        gw.submit(dict(order, client_id="o2"))
    assert len(f.calls) == 1
    sell = dict(order, side="SELL", client_id="o3", intent="close")
    gw.submit(sell)
    assert len(f.calls) == 2
