from decimal import Decimal
from app.market_data import Candle
from app.regime import classify_regime
from app.adaptive import ForecastOutcome, DriftMonitor, expected_calibration_error, walk_forward_splits
from app.economic import evaluate_trade_economics, estimate_first_passage_probability
from app.execution_sim import simulate_execution


def candles(prices):
    return [Candle(timestamp=(i+1)*60, open=Decimal(str(p)), high=Decimal(str(p*1.01)),
                   low=Decimal(str(p*.99)), close=Decimal(str(p)), volume=Decimal("10"))
            for i,p in enumerate(prices)]


def test_regime_is_causal_and_returns_metadata():
    result = classify_regime(candles([100+i for i in range(50)]))
    assert result["status"] == "classified"
    assert result["regime"] in {"TRENDING", "RANGING", "HIGH_VOLATILITY"}
    assert result["data_cutoff_timestamp"] == 3000


def test_drift_monitor_blocks_model_change_not_auto_promote():
    monitor = DriftMonitor(baseline_size=20, recent_size=10, min_samples=10)
    for i in range(20): monitor.add(ForecastOutcome(i+1, .5, 1))
    for i in range(10): monitor.add(ForecastOutcome(i+21, .99, 0))
    status = monitor.status()
    assert status["drift_detected"] is True
    assert status["action"] == "BLOCK_NEW_ENTRIES_AND_RETRAIN_CHALLENGER"


def test_walk_forward_splits_are_ordered_and_purged():
    splits = walk_forward_splits(100, min_train=40, test_size=10, purge=3)
    assert splits[0] == (40, 43, 53)
    assert all(a < b < c for a,b,c in splits)


def test_calibration_error_and_trade_economics():
    rows = [ForecastOutcome(i+1, .9, 0) for i in range(20)]
    assert expected_calibration_error(rows) > .8
    economics = evaluate_trade_economics(entry="100", target="110", stop="95")
    assert Decimal(economics["net_reward_risk_ratio"]) > 1
    assert economics["win_probability"] is None


def test_first_passage_same_bar_tie_is_loss():
    rows = [Candle(timestamp=60, open=Decimal("100"), high=Decimal("100"), low=Decimal("100"), close=Decimal("100"), volume=Decimal("1")),
            Candle(timestamp=120, open=Decimal("100"), high=Decimal("103"), low=Decimal("98"), close=Decimal("101"), volume=Decimal("1"))]
    result = estimate_first_passage_probability(rows, target_pct=".02", stop_pct=".01", horizon_bars=1, min_samples=10)
    assert result["status"] == "insufficient_first_passage_samples"


def test_execution_stale_book_rejected_without_order():
    result = simulate_execution({}, "BUY", "1", latency_ms=2000, stale_after_ms=1000)
    assert result["status"] == "rejected_stale_book"
    assert result["orders_submitted"] is False
