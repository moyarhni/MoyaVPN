import os, tempfile
import pytest
from decimal import Decimal
from app.live_guard import LiveGuard, LiveTradingBlocked, ENABLE_PHRASE, UNLOCK_PHRASE
from app.order_gateway import LiveWallexGateway, ExecutionDisabled


def _path():
    d = tempfile.mkdtemp()
    return os.path.join(d, "guard.db")


def test_default_is_disabled_and_blocks_open():
    g = LiveGuard(_path())
    s = g.status()
    assert s["live_enabled"] is False and s["new_live_entries_allowed"] is False
    with pytest.raises(LiveTradingBlocked):
        g.assert_can_open()


def test_enable_requires_exact_phrase():
    g = LiveGuard(_path())
    with pytest.raises(LiveTradingBlocked):
        g.enable("yes")
    assert g.enable(ENABLE_PHRASE)["new_live_entries_allowed"] is True


def test_first_loss_locks_persistently_across_restart():
    p = _path()
    g = LiveGuard(p)
    g.enable(ENABLE_PHRASE)
    g.record_realized_pnl("t1", "-0.01")
    g2 = LiveGuard(p)  # simulated restart
    s = g2.status()
    assert s["locked"] and not s["live_enabled"] and s["closing_allowed"]
    with pytest.raises(LiveTradingBlocked):
        g2.enable(ENABLE_PHRASE)


def test_profit_and_zero_do_not_lock():
    g = LiveGuard(_path())
    g.enable(ENABLE_PHRASE)
    g.record_realized_pnl("a", "1.5")
    g.record_realized_pnl("b", "0")
    assert g.status()["new_live_entries_allowed"] is True


def test_unlock_needs_phrase_and_leaves_live_disabled():
    g = LiveGuard(_path())
    g.enable(ENABLE_PHRASE)
    g.record_realized_pnl("t1", Decimal("-5"))
    with pytest.raises(LiveTradingBlocked):
        g.unlock("please")
    s = g.unlock(UNLOCK_PHRASE)
    assert not s["locked"] and not s["live_enabled"]


def test_record_is_idempotent_and_validates_input():
    g = LiveGuard(_path())
    g.record_realized_pnl("t1", "2")
    g.record_realized_pnl("t1", "-100")  # same id: ignored
    assert g.status()["locked"] is False
    with pytest.raises(ValueError):
        g.record_realized_pnl("", "1")
    with pytest.raises(ValueError):
        g.record_realized_pnl("x", "abc")
    with pytest.raises(ValueError):
        g.record_realized_pnl("y", "NaN")


def test_gateway_blocks_open_by_default_and_never_sends_even_when_enabled():
    g = LiveGuard(_path())
    gw = LiveWallexGateway(g)
    with pytest.raises(ExecutionDisabled, match="disabled"):
        gw.submit({"intent": "open"})
    g.enable(ENABLE_PHRASE)
    with pytest.raises(ExecutionDisabled, match="not configured"):
        gw.submit({"intent": "open"})
    g.record_realized_pnl("t1", "-1")
    with pytest.raises(ExecutionDisabled, match="locked"):
        gw.submit({"intent": "open"})
    with pytest.raises(ExecutionDisabled):  # close passes the guard, no trader configured
        gw.submit({"intent": "close"})
