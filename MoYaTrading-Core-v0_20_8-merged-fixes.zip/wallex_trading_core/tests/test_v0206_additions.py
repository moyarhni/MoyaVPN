from decimal import Decimal
import pytest
from app.risk_manager import check_portfolio_risk
from app.wallex_private import WallexAccountClient


def test_portfolio_risk_blocks_excess_exposure_and_daily_loss():
    result = check_portfolio_risk(equity=Decimal("1000"), open_position_values=[Decimal("600")])
    assert result["allowed"] is False
    assert "total_exposure_limit_reached" in result["reasons"]
    loss = check_portfolio_risk(equity=Decimal("1000"), open_position_values=[], daily_realized_loss=Decimal("40"))
    assert loss["allowed"] is False


def test_private_wallex_client_requires_key():
    with pytest.raises(ValueError, match="WALLEX_API_KEY"):
        WallexAccountClient(api_key="")


def test_private_client_has_no_order_mutation_methods():
    client = WallexAccountClient(api_key="test-key", base_url="https://example.invalid")
    try:
        assert hasattr(client, "balances")
        assert hasattr(client, "open_orders")
        assert not hasattr(client, "submit_order")
        assert not hasattr(client, "cancel_order")
    finally:
        import asyncio
        asyncio.run(client.close())
