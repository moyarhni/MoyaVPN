from app.automation import closed_candles


def test_closed_candles_excludes_current_forming_interval():
    now = 10_000
    payload = {
        "s": "ok",
        "t": [now - 180, now - 120, now - 30],
        "o": ["10", "10", "10"], "h": ["11", "11", "11"],
        "l": ["9", "9", "9"], "c": ["10", "10", "10"],
        "v": ["1", "1", "1"],
    }
    result = closed_candles(payload, "1", now)
    assert [c.timestamp for c in result] == [now - 180, now - 120]


def test_closed_candles_rejects_unknown_resolution():
    import pytest
    with pytest.raises(ValueError):
        closed_candles({"s": "no_data"}, "2", 10_000)
