from decimal import Decimal
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
from app.db import Base, ForecastAuditRecord
from app.forecast_audit import record_and_resolve
from app.market_data import Candle


def test_forecast_is_persisted_and_only_labelled_after_horizon():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, expire_on_commit=False)
    with Session() as db:
        c0 = Candle(timestamp=100, open=Decimal("100"), high=Decimal("101"), low=Decimal("99"), close=Decimal("100"), volume=Decimal("10"))
        forecast = {"timeframes": [{"timeframe":"1", "status":"calibrated",
            "last_candle_timestamp":100, "last_close":"100", "direction":"BULLISH",
            "calibrated_bullish_probability_pct":85, "success_probability_pct":80,
            "horizon_bars":2, "regime":{"regime":"TRENDING"}}]}
        result = record_and_resolve(db, symbol="BTCUSDT", resolution="1", forecast=forecast,
            candles=[c0], duration_seconds=60)
        row = db.scalar(select(ForecastAuditRecord))
        assert row is not None and row.outcome is None
        assert result["recorded"] == 1
        c1 = Candle(timestamp=160, open=Decimal("100"), high=Decimal("101"), low=Decimal("99"), close=Decimal("100.5"), volume=Decimal("10"))
        c2 = Candle(timestamp=220, open=Decimal("100.5"), high=Decimal("102"), low=Decimal("100"), close=Decimal("101"), volume=Decimal("10"))
        result = record_and_resolve(db, symbol="BTCUSDT", resolution="1", forecast=None,
            candles=[c0,c1,c2], duration_seconds=60)
        db.refresh(row)
        assert row.outcome == 1
        assert row.resolved_timestamp == 220
        assert result["newly_resolved"] == 1
    Base.metadata.drop_all(engine)
    engine.dispose()
