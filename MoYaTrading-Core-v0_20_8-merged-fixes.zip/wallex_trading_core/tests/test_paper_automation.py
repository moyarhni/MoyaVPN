from decimal import Decimal
from sqlalchemy import create_engine, select
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool
import pytest

from app.db import Base
from app.market_data import Candle
from app.paper_ledger import initialize_wallet, PaperPosition, PaperTrade, PaperPositionPlan
from app.paper_automation import process_symbol_paper_cycle
from app.config import settings

BOOK = {"result": {"ask": [{"price": "101", "quantity": "100"}],
                    "bid": [{"price": "100", "quantity": "100"}]}}

class FakeClient:
    async def depth(self, symbol):
        return BOOK

@pytest.fixture
def db():
    engine = create_engine("sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, expire_on_commit=False)
    with Session() as session:
        yield session
    Base.metadata.drop_all(engine)
    engine.dispose()

@pytest.mark.asyncio
async def test_automatic_paper_entry_and_stop_exit(db, monkeypatch):
    monkeypatch.setattr(settings, "paper_auto_trading_enabled", True)
    initialize_wallet(db, "10000", "USDT")
    decision = {"action": "BUY", "position": {"suggested_buy_quantity": "1"},
                "levels": {"reference_price": "100", "stop_loss": "95", "take_profit": "110"}}
    forecast = {"integrated_decision": {"action": "BUY_CANDIDATE"}}
    entry_candle = Candle(timestamp=100, open=Decimal("99"), high=Decimal("101"), low=Decimal("98"), close=Decimal("100"), volume=Decimal("10"))
    opened = await process_symbol_paper_cycle(FakeClient(), db, "BTCUSDT", entry_candle, decision, forecast)
    assert opened["actions"][0]["action"] == "OPEN"
    position = db.scalar(select(PaperPosition).where(PaperPosition.status == "OPEN"))
    assert position is not None
    plan = db.get(PaperPositionPlan, position.id)
    assert plan.stop_loss == "95" and plan.take_profit == "110"

    stop_candle = Candle(timestamp=200, open=Decimal("99"), high=Decimal("100"), low=Decimal("94"), close=Decimal("96"), volume=Decimal("10"))
    closed = await process_symbol_paper_cycle(FakeClient(), db, "BTCUSDT", stop_candle, decision, forecast)
    assert closed["actions"][0]["action"] == "CLOSE"
    assert closed["actions"][0]["reason"] == "stop_loss"
    assert db.get(PaperPosition, position.id).status == "CLOSED"
    trade = db.scalar(select(PaperTrade).where(PaperTrade.position_id == position.id))
    assert trade is not None

@pytest.mark.asyncio
async def test_automation_disabled_by_default_does_not_touch_wallet(db, monkeypatch):
    monkeypatch.setattr(settings, "paper_auto_trading_enabled", False)
    candle = Candle(timestamp=100, open=Decimal("99"), high=Decimal("101"), low=Decimal("98"), close=Decimal("100"), volume=Decimal("10"))
    result = await process_symbol_paper_cycle(FakeClient(), db, "BTCUSDT", candle,
        {"action":"BUY"}, {"integrated_decision":{"action":"BUY_CANDIDATE"}})
    assert result["enabled"] is False
    assert db.scalar(select(PaperPosition)) is None

@pytest.mark.asyncio
async def test_closed_position_cannot_reopen_on_same_candle_after_repeat_cycle(db, monkeypatch):
    monkeypatch.setattr(settings, "paper_auto_trading_enabled", True)
    initialize_wallet(db, "10000", "USDT")
    decision = {"action": "BUY", "position": {"suggested_buy_quantity": "1"},
                "levels": {"reference_price": "100", "stop_loss": "95", "take_profit": "110"}}
    forecast = {"integrated_decision": {"action": "BUY_CANDIDATE"}}
    first = Candle(timestamp=100, open=Decimal("99"), high=Decimal("101"), low=Decimal("98"), close=Decimal("100"), volume=Decimal("10"))
    opened = await process_symbol_paper_cycle(FakeClient(), db, "BTCUSDT", first, decision, forecast)
    position_id = opened["actions"][0]["position_id"]
    next_bar = Candle(timestamp=200, open=Decimal("99"), high=Decimal("100"), low=Decimal("94"), close=Decimal("96"), volume=Decimal("10"))
    closed = await process_symbol_paper_cycle(FakeClient(), db, "BTCUSDT", next_bar, decision, forecast)
    assert closed["entry"] == "closed_this_cycle_no_reentry"
    repeated = await process_symbol_paper_cycle(FakeClient(), db, "BTCUSDT", next_bar, decision, forecast)
    assert repeated["entry"] == "closed_on_this_candle_no_reentry"
    assert db.get(PaperPosition, position_id).status == "CLOSED"
    assert len(db.scalars(select(PaperPosition).where(PaperPosition.status == "OPEN")).all()) == 0
