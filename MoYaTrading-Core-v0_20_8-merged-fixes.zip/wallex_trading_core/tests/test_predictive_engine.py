from decimal import Decimal as D
import math

from app.market_data import Candle
from app.predictive_engine import ForecastConfig, forecast_market, forecast_timeframe


def candles_from_returns(n=900, drift=0.001, volatility=0.003, phase=0.0):
    out = []
    price = 100.0
    for i in range(n):
        change = drift + volatility * math.sin(i * 1.73 + phase) + volatility * 0.45 * math.sin(i * 0.37)
        next_price = price * (1.0 + change)
        high = max(price, next_price) * 1.001
        low = min(price, next_price) * 0.999
        out.append(Candle(i + 1, D(str(price)), D(str(high)), D(str(low)), D(str(next_price)), D("1000") * D(str(1 + 0.2 * math.sin(i * .2)))))
        price = next_price
    return out


def test_forecast_refuses_short_history():
    result = forecast_timeframe(candles_from_returns(80), "5")
    assert result["status"] in {"insufficient_training_data", "insufficient_oos_data"}
    assert result.get("success_probability_pct") is None


def test_forecast_is_research_only_and_exposes_oos_metrics():
    data = candles_from_returns()
    result = forecast_timeframe(data, "60", ForecastConfig(min_training_samples=80, min_oos_samples=20,
                                                               min_local_calibration_samples=10))
    assert result["status"] in {"calibrated", "calibration_sample_too_small"}
    assert result["training_samples"] >= 80
    assert result["oos_samples"] >= 20
    assert 0 <= result["oos_brier_score"] <= 1
    assert result["direction"] in {"BULLISH", "BEARISH"}
    scenarios = result["scenarios"]
    assert abs(sum(scenarios.values()) - 100) < 0.1


def test_market_gate_never_claims_live_execution():
    result = forecast_market({"5": candles_from_returns(850), "15": candles_from_returns(850, phase=.2),
                              "60": candles_from_returns(850, phase=.4)}, symbol="BTCUSDT",
                             cfg=ForecastConfig(min_training_samples=80, min_oos_samples=20,
                                                min_local_calibration_samples=10))
    assert result["live_trading_enabled"] is False
    assert result["orders_submitted"] is False
    assert result["action"] in {"BUY_CANDIDATE", "REDUCE_RISK_OR_EXIT", "NO_TRADE"}
    if result["entry_gate_passed"]:
        assert result["direction"] == "BULLISH"
        assert result["conservative_success_probability_pct"] > 80


def test_forecast_api_requires_explicitly_closed_timeframes():
    import pytest
    from fastapi import HTTPException
    from app.main import ForecastRequest, run_market_forecast
    candles = [{"timestamp": i + 1, "open": "100", "high": "102", "low": "99",
                "close": str(100 + i * .1), "volume": "1000"} for i in range(80)]
    request = ForecastRequest(symbol="BTCUSDT", timeframes={"60": candles}, last_candles_closed=False)
    with pytest.raises(HTTPException) as exc:
        run_market_forecast(request)
    assert exc.value.status_code == 422


def test_optimized_features_match_full_history_reference():
    from app.predictive_engine import _features, _ema
    data = candles_from_returns(120)
    for index in (30, 31, 45, 80, 119):
        window = data[:index + 1]
        closes = [float(c.close) for c in window]
        current = window[-1]
        returns = [closes[-1] / closes[-1 - n] - 1.0 for n in (1, 3, 6, 12)]
        fast = _ema(closes[-min(len(closes), 9):], 9)
        slow = _ema(closes[-min(len(closes), 21):], 21)
        gains, losses = [], []
        for previous, value in zip(closes[-15:-1], closes[-14:]):
            change = value - previous
            gains.append(max(change, 0.0))
            losses.append(max(-change, 0.0))
        avg_gain, avg_loss = sum(gains) / 14.0, sum(losses) / 14.0
        rsi = 100.0 if avg_loss == 0 and avg_gain > 0 else 50.0 if avg_loss == 0 else 100.0 - 100.0 / (1.0 + avg_gain / avg_loss)
        true_ranges = []
        for prev, cur in zip(window[-15:-1], window[-14:]):
            prev_close = float(prev.close)
            true_ranges.append(max(float(cur.high) - float(cur.low), abs(float(cur.high) - prev_close), abs(float(cur.low) - prev_close)))
        atr_pct = (sum(true_ranges) / max(1, len(true_ranges))) / float(current.close)
        prior_volumes = [float(c.volume) for c in window[-21:-1]]
        avg_volume = sum(prior_volumes) / len(prior_volumes) if prior_volumes else 0.0
        volume_ratio = min(5.0, float(current.volume) / avg_volume) if avg_volume > 0 else 1.0
        candle_range = max(float(current.high) - float(current.low), 1e-12)
        body_ratio = (float(current.close) - float(current.open)) / candle_range
        expected = [max(-5.0, min(5.0, x)) for x in returns + [fast / slow - 1.0, rsi / 100.0, atr_pct, volume_ratio, body_ratio]]
        assert _features(data, index) == expected


def test_isotonic_calibration_avoids_extreme_probabilities_for_tiny_blocks():
    from app.predictive_engine import _calibrate
    assert 0.0 < _calibrate(0.2, [[0.2, 0.2, 0.0, 1]]) < 1.0
    assert 0.0 < _calibrate(0.8, [[0.8, 0.8, 1.0, 1]]) < 1.0


def test_reported_calibration_samples_count_the_calibration_segment_not_the_holdout():
    from app.predictive_engine import _dataset
    data = candles_from_returns()
    cfg = ForecastConfig(min_training_samples=80, min_oos_samples=20, min_local_calibration_samples=10)
    result = forecast_timeframe(data, "60", cfg)
    rows, labels, indices = _dataset(data, cfg)
    fit_end, cal_end = int(len(rows) * 0.60), int(len(rows) * 0.80)
    rel_start = indices[cal_end]
    expected_cal = sum(1 for j in range(fit_end, cal_end)
                       if indices[j] + cfg.horizon_bars < rel_start and labels[j] != -1)
    expected_oos = sum(1 for j in range(cal_end, len(rows)) if labels[j] != -1)
    assert result["calibration_samples"] == expected_cal
    assert result["oos_samples"] == expected_oos
