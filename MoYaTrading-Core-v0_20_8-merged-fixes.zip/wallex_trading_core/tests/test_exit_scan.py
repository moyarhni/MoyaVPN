from decimal import Decimal as D
from app.market_data import Candle
from app.exit_scan import find_exit


def c(ts, low, high):
    return Candle(ts, D("100"), D(str(high)), D(str(low)), D("100"), D("1"))


def test_detects_stop_breached_in_an_earlier_candle_not_only_the_newest():
    candles = [c(1, 99, 101), c(2, 94, 101), c(3, 99, 101)]  # stop 95 breached on ts=2; newest is calm
    assert find_exit(candles, "95", "110", after_ts=1) == ("stop_loss", 2)


def test_ignores_candles_at_or_before_last_check_and_none_when_no_trigger():
    candles = [c(1, 90, 101), c(2, 99, 101)]
    assert find_exit(candles, "95", "110", after_ts=1) is None


def test_stop_wins_tie_in_same_candle_and_earlier_target_wins_over_later_stop():
    assert find_exit([c(2, 94, 111)], "95", "110", 1) == ("stop_loss", 2)
    assert find_exit([c(2, 99, 111), c(3, 90, 101)], "95", "110", 1) == ("take_profit", 2)


def test_unsorted_input_is_handled():
    assert find_exit([c(3, 90, 101), c(2, 99, 111)], "95", "110", 1) == ("take_profit", 2)
