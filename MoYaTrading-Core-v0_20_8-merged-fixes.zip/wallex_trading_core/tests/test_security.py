import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.security import ApiSecurityMiddleware
from app.config import settings


@pytest.fixture
def secured_app():
    app = FastAPI()
    app.add_middleware(ApiSecurityMiddleware)

    @app.get("/health")
    def health():
        return {"ok": True}

    @app.get("/private")
    def private():
        return {"secret": True}

    return app


def test_health_is_public_but_private_route_fails_closed_without_token(secured_app, monkeypatch):
    monkeypatch.setattr(settings, "moya_api_token", "")
    with TestClient(secured_app) as client:
        assert client.get("/health").status_code == 200
        response = client.get("/private")
        assert response.status_code == 503


def test_private_route_requires_bearer_token(secured_app, monkeypatch):
    monkeypatch.setattr(settings, "moya_api_token", "correct-token")
    with TestClient(secured_app) as client:
        assert client.get("/private").status_code == 401
        assert client.get("/private", headers={"Authorization": "Basic correct-token"}).status_code == 401
        assert client.get("/private", headers={"Authorization": "Bearer wrong"}).status_code == 401
        assert client.get("/private", headers={"Authorization": "Bearer correct-token"}).status_code == 200


def test_docs_and_openapi_are_not_special_auth_exemptions(secured_app, monkeypatch):
    monkeypatch.setattr(settings, "moya_api_token", "correct-token")
    with TestClient(secured_app) as client:
        # Unknown paths still pass through auth before route resolution.
        assert client.get("/docs").status_code == 401
        assert client.get("/openapi.json").status_code == 401
