# MoYaTrading Core — v0.20.7

A Wallex market-data and research core with a persistent paper portfolio and historical research/backtest tools. Optional private account access is read-only. **Live trading is disabled.** No order-placement, cancellation, or withdrawal methods are present.

## Pattern recognition v1
- Versioned catalog of 29 candidate patterns in `pattern_library.json`.
- Causal detector in `app/pattern_engine.py`; confirmed pivots are not available until the configured right-side candles have closed.
- First detector pass supports 16 patterns: Head & Shoulders, inverse Head & Shoulders, double top/bottom, HH/HL, LH/LL, bullish/bearish engulfing, hammer, shooting star, doji, breakout, breakdown, false breakout, volume spike and price/volume divergence.
- All 29 catalog entries have deterministic detector implementations. New formation detectors use conservative OHLCV/pivot approximations and remain research candidates.
- New research endpoint: `POST /patterns/detect`, requiring `last_candle_closed: true`. It never places orders.
- Pattern scores are heuristic rankings, not probabilities. Live trading remains disabled for all patterns.

Example request shape:
```json
{"last_candle_closed":true,"candles":[{"timestamp":1700000000,"open":"100","high":"102","low":"99","close":"101","volume":"120"}]}
```
Supply at least five chronological candles. The example shows the request shape only; a useful detection needs a longer history.

## Included
- Public Wallex markets, depth, trades and UDF candle-history client. Optional read-only private balance/open-order endpoints require a least-privilege `WALLEX_API_KEY`.
- Background market collector with SQLite event storage and per-symbol failure isolation.
- Decimal-based ticker and OHLCV normalization.
- Paper L2 fill estimator that walks visible asks/bids and applies configurable fees and slippage caps.
- Persistent paper wallet, simulated positions, closed-trade records and realized PnL. Automated paper mode opens SPOT LONG positions only.
- Idempotency keys for paper position open/close requests, plus persistent stop/target plans for opt-in automated paper execution.
- Persistent global entry circuit for a future live execution layer. Paper losses do not disable continued paper research; closing positions is always permitted.
- Three candle-based backtest baselines: SMA crossover, EMA crossover and Donchian breakout.
- Transparent two-sided trend/momentum analysis endpoint (`/analysis/run`) with EMA, RSI, ATR, breakout and volume evidence; returns LONG, SHORT or NO_TRADE and reference risk levels.
- Bounded historical candle download and SQLite storage, with deduplication and validation.
- Chronological train/test holdout reports using fixed strategy parameters.
- Fixed-parameter walk-forward evaluation over consecutive, non-overlapping out-of-sample folds, with indicator warm-up separated from tradable candles.
- Chronological replay harness for `trend_momentum_v1`; signals use candle prefixes only and execute at the next candle open.

## Run

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Set MOYA_API_TOKEN in .env to a long random secret before starting the API.
uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Open `/docs` for API documentation. Run tests with `python -m pytest -q`.

## Historical data workflow

All times are Unix seconds. The historical downloader accepts these conservative UDF resolutions only:

| Resolution | Meaning | Maximum per sync request |
|---|---:|---:|
| `1` | 1 minute | 90 days |
| `60` | 1 hour | 3 years |
| `1D` | 1 day | 10 years |

1. Download and store public candles:

```http
POST /history/sync/BTCUSDT
Content-Type: application/json

{"resolution":"60","start":1700000000,"end":1701000000}
```

2. Read locally stored candles:

```http
GET /history/BTCUSDT?resolution=60&start=1700000000&end=1701000000
```

3. Run a chronological holdout evaluation. Default split is 70% training / 30% test. The selected strategy and its parameters remain fixed; this endpoint does not optimize parameters:

```http
POST /backtest/stored/BTCUSDT
Content-Type: application/json

{
  "resolution":"60",
  "start":1700000000,
  "end":1701000000,
  "train_fraction":"0.70",
  "strategy":"ema_crossover",
  "fast_period":9,
  "slow_period":21,
  "fee_rate":"0.001",
  "slippage_bps":"5"
}
```

Available strategy values: `sma_crossover`, `ema_crossover`, `donchian_breakout`. The generic endpoint `/backtest/run` accepts candle arrays directly; the older `/backtest/sma` route remains available for compatibility.

## Walk-forward evaluation

After syncing enough candles, run consecutive out-of-sample folds with fixed parameters:

```http
POST /backtest/walk-forward/BTCUSDT
Content-Type: application/json

{
  "resolution": "60",
  "start": 1700000000,
  "end": 1710000000,
  "initial_train_candles": 500,
  "test_candles": 100,
  "max_folds": 12,
  "strategy": "ema_crossover",
  "fast_period": 9,
  "slow_period": 21
}
```

The initial history window sets the point where out-of-sample folds begin. Parameters remain fixed; this endpoint does not fit or optimize them. Each fold has an independent starting balance, positions do not carry between folds, and the reported sum of fold PnL is not a compounded portfolio return. Warm-up candles provide indicator history but cannot open trades before each fold starts. The result is a diagnostic, not proof of robustness or profitability.

## Two-sided signal replay

The Python function `app.signal_replay.run_signal_replay` replays the two-sided `trend_momentum_v1` engine over historical candles. It uses only candles available at each decision point, schedules entries/exits for the next candle open, rejects gap-through entries, and reports trade-level results. This is research-only; it does not model exchange margin, financing, liquidation, or historical order-book execution.

## Two-sided signal analysis

`POST /analysis/run` accepts a chronological OHLCV candle list and requires `last_candle_closed: true`. It returns a research-only LONG, SHORT or NO_TRADE assessment using EMA alignment/slope, RSI, prior-range breakout, relative volume and an ATR volatility filter. The score weights are rule-based, not calibrated probabilities. ATR stop/target values are reference levels only. The engine cannot independently verify that the supplied final candle is closed. It does not submit orders or establish profitability.

## Backtest assumptions and limitations

- Signals use a fully closed candle. Entries and signal-based exits execute at the next candle open.
- Fees apply on entry and exit. Slippage is a fixed adverse basis-point estimate, not historical order-book replay.
- If stop-loss and take-profit both fit inside one candle, stop-loss is assumed to happen first.
- An open final position is reported but not forcibly liquidated.
- Maximum drawdown is calculated from realized-balance snapshots; unrealized price movement is excluded.
- The simple train/test split is a first chronological holdout. The walk-forward endpoint adds repeated fixed-parameter out-of-sample windows, but each fold still starts with a separate virtual balance and no position carries across folds.
- SMA, EMA and Donchian are generic research baselines. None is a validated production strategy and no profitability is claimed.

See [Freqtrade backtesting assumptions](https://www.freqtrade.io/en/stable/backtesting/) and [lookahead analysis](https://www.freqtrade.io/en/stable/lookahead-analysis/) for further discussion of fill assumptions and future-data leakage.

## Paper portfolio limitations

The paper portfolio is a research ledger, not a replica of Wallex margin trading. It uses simplified collateral and LONG/SHORT PnL formulas. It does not yet model Wallex financing/loan fees, collateral rules, liquidation prices, margin calls, maximum position age, exchange-specific rounding, borrow costs, liquidation execution, or unrealized PnL from live prices. The virtual balance has no connection to a real account.

## Safety boundary

- Live trading is disabled. No live order endpoints exist.
- No private account keys are accepted or stored.
- All API routes except `/health` require a Bearer token. `/docs` and `/openapi.json` are protected too. If `MOYA_API_TOKEN` is empty, protected routes fail closed with HTTP 503. Generate a long random token and keep it out of source control.
- Use HTTPS at the reverse proxy. The middleware does not provide TLS, rate limiting, user roles, or token rotation.
- Paper simulation reads public order-book data only. It does not submit or reserve orders, and visible depth does not guarantee execution.

### Position sizing (research-only)
The `app.position_sizing` module calculates a conservative LONG/SHORT quantity from an equity risk budget and stop distance. It applies estimated round-trip fees and a caller-supplied per-unit financing reserve, then caps size by collateral/leverage, notional, optional total exposure, optional visible liquidity and exchange quantity increments/minimums. A supplied liquidation price must leave the stop on the safe side. The module is not connected to order execution and must be paired with Wallex `dry-run` and exchange-specific rule validation before any future live use.


## Decision engine and supporting engines (v0.17.0)

`POST /decision/run` combines the existing indicator analysis with detected pattern evidence and returns `BUY`, `SELL`, `HOLD`, or `NO_TRADE`. The endpoint requires fully closed candles. Spot mode never opens short positions: bearish evidence can only recommend selling an available base-asset balance or holding when no base asset is supplied.

The decision layer is research/paper-only. It does not submit exchange orders. Suggested size uses a conservative risk budget and a position-value cap; it is a research estimate and does not replace exchange precision, minimum-notional, liquidity, or fee validation.


## v0.17.0 implementation update
- Added deterministic composite-pattern rules in `app/composite_patterns.py`.
- Added spot risk sizing and daily-loss guard in `app/risk_manager.py`.
- Integrated composite evidence and risk checks into the decision engine.
- Added persistent pattern observation memory in `app/pattern_memory.py` with record, resolve and summary APIs.
- Memory records observations only. It does not modify live strategy parameters or place orders.
- Live trading remains disabled.


## v0.18.0 update
- Implemented all 29 catalog detectors.
- Fixed composite matching to use stable pattern slugs, with legacy display-name compatibility.
- Full test suite: 89 passed. Live trading remains disabled.

## v0.20.0 additions
- Versioned pattern archive with SHA-256 feature fingerprints and provenance metadata (`/patterns/archive`).
- Pattern-memory compaction rebuilds aggregate counters from immutable source observations; it does not delete observations (`POST /patterns/memory/compact`).
- Risk circuit status endpoint (`GET /risk/circuit`) and a durable circuit-state table. The global circuit is a separate persistent guard for future live entries. Paper losses do not trip this circuit or disable continued paper research.
- Optional Bearer-token API guard. Set `MOYA_API_TOKEN` to a long random secret before network exposure. `/health` remains public for service checks. Use HTTPS at the reverse proxy; this middleware does not provide TLS.
- SQLite online backup helper (`app.backup.backup_database(destination)`). Protect backup files as financial data.
- Execution gateway boundary. Live Wallex order submission deliberately fails closed. No withdrawal method or exchange private-key storage exists.
- Futures risk-domain scaffold only. It is not connected to an exchange, does not estimate liquidation price, and cannot place futures orders.
- Android starter project in `android/`. It is a UI shell, not a complete trading client. HTTPS API integration, secure token storage, charting and operational validation remain to be implemented.

Run `pytest -q` from the project root. Live trading remains disabled regardless of configuration.


## Automatic market analysis (v0.20.3 baseline)

The service can scan configured Wallex symbols after each successful public market-data collection cycle.
Set `AUTO_ANALYSIS_ENABLED=true` to enable the background scanner (default). The scanner downloads
closed candles at `ANALYSIS_RESOLUTION`, excludes the still-forming interval, and sends the candles
through the existing indicator, pattern, composite-pattern, decision, and spot-risk engines.

- `POST /automation/run` runs one immediate scan.
- `GET /automation/status` returns recent persisted analysis results.
- `ANALYSIS_RESOLUTION` supports `1`, `3`, `5`, `15`, `30`, `60`, `120`, `240`, `1D`, and `1W`.
- `ANALYSIS_LOOKBACK_CANDLES` controls the requested history depth (100–1000 effective range).

This release performs automatic market observation and analysis only. It does not submit paper or live
orders automatically. Live Wallex account access and order execution remain unimplemented and disabled.
Set `MOYA_API_TOKEN` before exposing protected API routes outside a trusted local environment.


## Predictive Intelligence v1 (introduced in v0.20.5)

- Added `app/predictive_engine.py`: a regularized logistic model over lagged OHLCV features, with a chronological fit/calibration/reliability partitions, a horizon purge to reduce label leakage, isotonic calibration on the middle partition, and a 95% Wilson lower bound measured on a later untouched reliability partition.
- Supports multi-timeframe forecasts (`5`, `15`, `60`, `240`, `1D`) and reports bullish/bearish scenarios, opposing timeframe votes, data sufficiency, OOS Brier score, and the conservative minimum lower-bound among aligned calibrated timeframes.
- The entry gate requires at least three calibrated aligned timeframes and a conservative lower bound strictly greater than 80%. If evidence is insufficient or mixed, the output is `NO_TRADE`. Bearish spot forecasts are exit/reduce-risk warnings only; they never open shorts.
- `POST /forecast/run` accepts closed OHLCV arrays for up to five timeframes. The caller must explicitly set `last_candles_closed: true`.
- The automatic scanner fetches configured timeframes (default `5,15,60,240,1D`) every `FORECAST_REFRESH_SECONDS` (default 300 seconds) and adds forecast results to `/automation/status`.
- The model does not place orders. Automatic paper-order execution is not enabled. Live trading remains disabled. A probability gate is not a guarantee and does not establish profitability; the reported threshold is a conservative OOS precision bound, not a universal probability of future profit.

Configuration: `FORECAST_ENABLED`, `FORECAST_TIMEFRAMES`, `FORECAST_LOOKBACK_CANDLES`, and `FORECAST_REFRESH_SECONDS`.


## Predictive Intelligence v1.1 (introduced in v0.20.5)
- Bounded rolling feature extraction to the latest 21 candles, avoiding repeated scans of the full history.
- Brier score now measures calibrated out-of-sample probabilities.
- Isotonic calibration uses Beta(1,1) smoothing to reduce extreme probabilities from small blocks.
- Regression tests cover feature equivalence and calibration smoothing.


## Predictive, risk and execution hardening (v0.20.7)
- Added causal market-regime classification (`TRENDING`, `RANGING`, `HIGH_VOLATILITY`) using only the latest closed candles. High-volatility and uncertain-calibration states block predictive entry candidates.
- Added ECE beside calibrated OOS Brier score. Calibration uncertainty is explicit and can force `NO_TRADE`.
- Added first-passage target-before-stop estimation. Same-candle target/stop ambiguity is counted as a loss. The estimate is informational only. It is not an independent deployment holdout and does not authorize entries.
- Added persistent delayed forecast labels and drift monitoring by symbol/timeframe. Drift blocks new paper entries; it never silently replaces the active model. Automatic challenger retraining and promotion remain disabled.
- Added portfolio exposure and daily-loss checks at `POST /risk/portfolio-check`.
- Added latency, stale-book, partial-liquidity and slippage stress simulation at `POST /paper/execution-stress`.
- Added trade-economics calculation at `POST /risk/trade-economics`. Win probability is not fabricated by this endpoint.
- Added first-passage estimation endpoint `POST /forecast/first-passage`.
- Added optional authenticated read-only Wallex account endpoints for balances and open orders. They have no order submission, cancellation, or withdrawal methods. Store `WALLEX_API_KEY` in the server environment only.
- Updated the Android dashboard. It checks HTTPS health and, with the bearer token, reads automation status and system capabilities. The token is kept in memory only; the server URL is saved locally.
- Automatic SPOT-LONG paper execution is available as an opt-in feature and remains disabled by default. Live order execution remains disabled.

## v0.20.7 limitations
- Regime thresholds are transparent heuristics and require walk-forward evaluation for the target market/timeframes.
- First-passage probability is a historical OHLC estimate, not a guarantee; intrabar sequencing is unknown, so same-bar target/stop hits count as losses. It is informational only.
- Drift labels are persisted and resolved after the forecast horizon. Challenger retraining and model promotion are not automatic.
- Private Wallex access is read-only. No real order can be sent by this release.
- Paper exits are simulated against current visible order-book depth. This is not exchange-side stop execution. Production server deployment and operational alerting still require infrastructure and credentials.


## v0.20.7 completion notes

- Opt-in automatic SPOT-LONG paper execution is available with `PAPER_AUTO_TRADING_ENABLED=true`; it remains disabled by default.
- Paper positions receive persistent stop/target plans. OHLC bars that touch both levels are treated as stop-loss first. Exits use current public order-book depth and may remain open if a full simulated fill is unavailable.
- Paper losses do not trip the persistent live-entry circuit breaker. The first-realized-loss circuit is reserved for a future live execution layer.
- Forecasts are stored and labelled only after their forecast horizon has elapsed. Drift monitoring uses calibrated directional probabilities and blocks new paper entries when a measured drift alert occurs. Neutral labels are excluded, matching the model's training policy.
- The historical first-passage estimate is informational only. It is not an independent deployment holdout and does not authorize live trades.
- The Android shell now checks the server health endpoint over HTTPS. It does not store exchange API credentials or submit orders.
- Live trading, exchange order submission, cancellation, and withdrawals remain unavailable.
