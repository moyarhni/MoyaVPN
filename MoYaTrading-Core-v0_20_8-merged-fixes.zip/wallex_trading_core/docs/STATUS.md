# MoYaTrading Core v0.20.7

## Automatic market-analysis pipeline
- Added `app/automation.py` to fetch Wallex UDF candles for configured symbols.
- Candles are normalized and validated using the existing market-data layer.
- The still-forming candle is excluded using the configured interval duration.
- Closed candles flow into the existing indicator, pattern, composite-pattern, decision, and spot-risk engines.
- Each result is persisted as a structured `SystemEvent` for later review.
- Background scanning runs after successful market-data collection when `AUTO_ANALYSIS_ENABLED=true`.
- Added `POST /automation/run` for an immediate scan and `GET /automation/status` for recent results.
- The analysis endpoint reports the selected decision and risk evidence. It does not submit an exchange order.

## Safety and execution boundary
- Live Wallex execution remains unimplemented and disabled.
- Automatic paper position management is opt-in and disabled by default. It can open SPOT LONG paper positions and manage stop/target exits. It never submits exchange orders.
- Optional authenticated private account endpoints can read Wallex balances and open orders. If a paper wallet exists, its available quote balance and open spot quantity are used as decision inputs; otherwise the engine receives zero balances and cannot produce a sized BUY.
- The app cannot guarantee candle finality from the exchange beyond excluding the interval that has not elapsed.
- Spot SELL means reducing an existing spot asset; no short position is opened by this decision pipeline.

## Configuration
- `AUTO_ANALYSIS_ENABLED=true`
- `ANALYSIS_RESOLUTION=60`
- `ANALYSIS_LOOKBACK_CANDLES=250`
- Supported resolutions: 1, 3, 5, 15, 30, 60, 120, 240 minutes, 1D, 1W.
- Configure `MOYA_API_TOKEN` before exposing the API. Only `/health` is public.

## Verification
Run from this directory:

```bash
PYTHONPATH=. pytest -q
python -m compileall -q app
```

## Remaining work before any automatic order execution
- Implement live order submission only after a separate safety review, exchange precision/minimum-notional validation, exchange-side stop/target reconciliation, and integration tests with least-privilege credentials. This is intentionally not implemented in v0.20.7.
- Deploy the server and configure monitoring/alerts on user-approved infrastructure.
- Build a richer Android portfolio and chart interface.
- Keep live trading disabled until these checks and explicit user approval are complete.


## Predictive Intelligence v1
- Added `app/predictive_engine.py`, a regularized logistic directional model using lagged OHLCV features.
- Training, isotonic calibration, and reliability evaluation use chronological partitions. Forward-label windows are purged at partition boundaries to reduce leakage.
- Bullish, bearish, and neutral scenario estimates are reported. Neutral outcomes are retained in the holdout and reduce the conservative success estimate.
- The reported success threshold uses the 95% Wilson lower bound of local directional precision on an untouched reliability holdout, multiplied by one minus the holdout neutral rate. It is a conservative research estimate, not a guarantee.
- Multi-timeframe aggregation requires at least three calibrated timeframes to agree and a conservative estimate strictly above 80%; otherwise the action is `NO_TRADE`.
- Added `POST /forecast/run`. The automatic scanner fetches the configured timeframes on a five-minute default refresh and attaches forecast output to the stored analysis event.
- Bearish Spot forecasts only warn to reduce risk or exit existing holdings. The model never opens short positions.
- No automatic paper orders or live exchange orders are submitted.

## Predictive configuration
- `FORECAST_ENABLED=true`
- `FORECAST_TIMEFRAMES=5,15,60,240,1D`
- `FORECAST_LOOKBACK_CANDLES=1000`
- `FORECAST_REFRESH_SECONDS=300`


## Predictive Intelligence v1.1 optimization (v0.20.5)
- Reduced historical feature extraction from repeated full-prefix scans to a bounded 21-candle window. The selected features only depend on the latest 21 candles, so outputs remain equivalent while work per training row is bounded.
- Corrected the out-of-sample Brier score to evaluate calibrated probabilities, matching the probabilities exposed by the forecast response.
- Added Beta(1,1) smoothing to isotonic calibration outputs to avoid exact 0%/100% probabilities from tiny calibration blocks.
- Added regression tests for feature parity and calibration smoothing.
- Verification: 112 tests passed; Python compilation passed.


## v0.20.7 implementation status
Implemented: causal regime classifier; ECE and uncertainty guard; persistent delayed forecast outcome records; per-symbol/timeframe drift monitoring; opt-in SPOT-LONG paper entry and stop/target exit lifecycle; portfolio exposure and daily-loss guard; execution stress simulator; informational first-passage estimator; read-only Wallex balances/open-orders endpoints; HTTPS Android health and authenticated status/capability requests; atomic paper-wallet debit and position-close claims.

Not implemented: automatic model retraining/challenger promotion; real exchange order submission/cancellation; exchange-side protective-order reconciliation; production server deployment/alerting; full Android charts and portfolio controls. Live trading remains disabled.

Verification: `python -m compileall -q app tests` passed; `PYTHONPATH=. pytest -q` passed (126 tests). API smoke checks returned HTTP 200 for health and authenticated status/capabilities, and HTTP 401 without a bearer token.

## v0.20.7
- Added opt-in automatic SPOT-LONG paper execution, persistent stop/target plans, conservative same-candle stop precedence, idempotent paper entry/exit keys, fee and slippage settings.
- Paper loss no longer disables further paper research. The persistent global circuit remains a separate control for any future live-entry layer.
- Added persistent delayed forecast outcome records and drift monitoring by symbol/timeframe. Drift blocks paper entries; no model weights are changed automatically.
- Corrected drift confidence to use calibrated directional probability, not the Wilson lower confidence bound.
- Removed the in-sample first-passage estimate from entry authorization. It is informational only.
- Reduced serial dependence in first-passage sampling by using non-overlapping horizons.
- Android dashboard now performs an HTTPS health check and stores only the server URL.
- Live order execution remains disabled.

## v0.20.8 review fixes and merge
- Fixed: `predictive_engine` reported the reliability-holdout size as `calibration_samples` (variable shadowing). Regression test added; confirmed it fails on the old code.
- Fixed: paper stop/target management only inspected the newest candle, so a stop breached during a gap (restart, skipped cycle) was missed. New pure helper `app/exit_scan.py` scans all closed candles since the last check; `process_symbol_paper_cycle` takes an optional `candles` list (backward compatible). The DB-backed integration was NOT executed here; CI must confirm.
- Added `app/wallex_trade.py` (LIMIT place/get/cancel, no withdrawals) built from the official docs; `LiveWallexGateway(guard, trader=None)` sends nothing unless deployment code injects a trader AND the persistent guard allows it. Never run against the real API. See `docs/WALLEX_API_NOTES.md`.
- Offline verification only: 98 dependency-free tests passed with a minimal pytest stand-in; 12 test files that need fastapi/sqlalchemy/httpx were not run here.
- Design caveat: the forecast gate requires (Wilson lower bound x (1 - neutral rate)) > 80%. With a 0.25% move threshold over 3 bars the neutral rate is often large, so the gate will rarely open. That is conservative, not a bug, but expect mostly NO_TRADE.
