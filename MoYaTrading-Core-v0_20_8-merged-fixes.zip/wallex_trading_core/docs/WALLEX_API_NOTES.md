# Wallex API notes (what is verified and what is not)

Official docs portal: https://developers.wallex.ir (older: https://api-docs.wallex.ir).
Auth for private spot endpoints: `x-api-key` header. Base URL: `https://api.wallex.ir`.

## Seen in the official docs (search snippets, 2026-11)
| Action | Request |
|---|---|
| Create order (spot) | `POST /v1/account/orders` body: `client_id, price, quantity, side, symbol, type` (+ stop price for stop orders); success = HTTP 201; response `{success, message, result{clientOrderId, status, executedQty, fee, fills[]...}}` |
| Get order | `GET /v1/account/orders/{client_id}` |
| Cancel order | `DELETE /v1/account/orders/{client_id}` |
| List orders | `GET /v1/account/orders?from&to&market&page&per_page&side&type` |
| OTC instant order | separate endpoint, not used by this project |

## Used by the read-only client (`wallex_private.py`), NOT checked by me against the docs
`GET /v1/account/balances`, `GET /v1/account/openOrders`.

## Not verified (must be tested with a minimal-permission key and a tiny order)
- Exact accepted `type` values (the code sends `LIMIT`), `side` casing (code sends `BUY`/`SELL`).
- The docs sample shows an oddly cased `stop_Price` field; stop orders are not implemented here.
- Price/quantity precision, minimum notional, rate limits, error body format.
- Whether the key can be restricted to "trade only" without withdrawal in the Wallex panel.

The `apis.io` / `docs.wallex.asia` results are a DIFFERENT company (Singapore payments) and are unrelated.
