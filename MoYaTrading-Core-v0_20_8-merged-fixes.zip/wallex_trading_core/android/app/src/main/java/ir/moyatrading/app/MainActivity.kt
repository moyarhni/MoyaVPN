package ir.moyatrading.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL

/** HTTPS health dashboard. It never stores API credentials or submits orders. */
class MainActivity : Activity() {
    private lateinit var endpoint: EditText
    private lateinit var status: TextView
    private lateinit var apiToken: EditText

    private fun label(text: String, size: Float, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(0xFF172033.toInt())
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(20, 14, 20, 14)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("moya_dashboard", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 20, 16, 20)
            setBackgroundColor(0xFFF4F6FA.toInt())
        }
        root.addView(label("MoYaTrading Core 0.20.7", 24f, true))
        root.addView(label("اتصال امن به سرور", 18f, true))
        endpoint = EditText(this).apply {
            hint = "https://your-server.example"
            setSingleLine(true)
            setText(prefs.getString("endpoint", "") ?: "")
        }
        root.addView(endpoint, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        apiToken = EditText(this).apply {
            hint = "توکن سرور (MOYA_API_TOKEN)"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        root.addView(apiToken, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val connect = Button(this).apply {
            text = "بررسی اتصال"
            setOnClickListener { checkHealth() }
        }
        root.addView(connect)
        status = label("وضعیت: هنوز متصل نشده است", 16f)
        root.addView(status)
        root.addView(label(
            "تحلیل و پیش‌بینی: سمت سرور\n" +
            "معاملات آزمایشی: فقط با فعال‌سازی PAPER_AUTO_TRADING_ENABLED\n" +
            "معاملات واقعی: غیرفعال\n" +
            "کلید API والکس در برنامه ذخیره نمی‌شود.", 15f))
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun checkHealth() {
        val base = endpoint.text.toString().trim().trimEnd('/')
        if (!base.startsWith("https://") || base.length < 12) {
            status.text = "نشانی نامعتبر است. از HTTPS استفاده کنید."
            return
        }
        getSharedPreferences("moya_dashboard", MODE_PRIVATE).edit()
            .putString("endpoint", base).apply()
        val token = apiToken.text.toString().trim()
        status.text = "در حال بررسی اتصال..."
        Thread {
            var connection: HttpURLConnection? = null
            val result = try {
                connection = (URL("$base/health").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 7000
                    readTimeout = 7000
                    setRequestProperty("Accept", "application/json")
                }
                val healthCode = connection.responseCode
                val healthBody = (if (healthCode in 200..299) connection.inputStream else connection.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: "بدون پاسخ"
                connection.disconnect()
                connection = null
                if (healthCode !in 200..299) "Health HTTP $healthCode\n$healthBody"
                else if (token.isEmpty()) "اتصال HTTPS برقرار است\n$healthBody\nبرای داشبورد، توکن سرور را وارد کنید."
                else {
                    fun protectedGet(path: String): String {
                        val api = URL("$base$path").openConnection() as HttpURLConnection
                        try {
                            api.requestMethod = "GET"
                            api.connectTimeout = 7000
                            api.readTimeout = 7000
                            api.setRequestProperty("Accept", "application/json")
                            api.setRequestProperty("Authorization", "Bearer $token")
                            val code = api.responseCode
                            val body = (if (code in 200..299) api.inputStream else api.errorStream)
                                ?.bufferedReader()?.use { it.readText() } ?: "بدون پاسخ"
                            return "HTTP $code\n$body"
                        } finally {
                            api.disconnect()
                        }
                    }
                    "Health OK\nتحلیل بازار:\n${protectedGet("/automation/status?limit=5")}\n" +
                        "حساب آزمایشی:\n${protectedGet("/paper/account")}\n" +
                        "قابلیت‌های سامانه:\n${protectedGet("/system/capabilities")}"
                }
            } catch (e: Exception) {
                "خطای اتصال: ${e.javaClass.simpleName}"
            } finally {
                connection?.disconnect()
            }
            runOnUiThread { status.text = result }
        }.start()
    }
}
