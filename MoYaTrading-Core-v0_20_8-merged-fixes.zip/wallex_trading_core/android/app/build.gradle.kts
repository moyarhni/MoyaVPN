plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "ir.moyatrading.app"; compileSdk = 35
    defaultConfig { applicationId = "ir.moyatrading.app"; minSdk = 26; targetSdk = 35; versionCode = 22; versionName = "0.20.7" }
}
