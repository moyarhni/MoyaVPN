"""Execution boundary. Only paper adapter is implemented; live adapter fails closed."""
from abc import ABC, abstractmethod
from .live_guard import LiveGuard, LiveTradingBlocked


class ExecutionDisabled(RuntimeError): pass
class OrderGateway(ABC):
    @abstractmethod
    def submit(self, order: dict) -> dict: ...
class PaperOnlyGateway(OrderGateway):
    def submit(self, order: dict) -> dict:
        raise ExecutionDisabled('Use the explicit paper-ledger workflow with an order book; no live orders are sent')
class LiveWallexGateway(OrderGateway):
    """Checks the persistent live guard first. Without an injected trader nothing is ever sent."""
    def __init__(self, guard: LiveGuard | None = None, trader=None):
        self.guard = guard or LiveGuard()
        self.trader = trader  # WallexSpotTrader, injected only by deployment code
    def submit(self, order: dict) -> dict:
        if order.get('intent') != 'close':
            try:
                self.guard.assert_can_open()  # needs explicit enable and no realized-loss lock
            except LiveTradingBlocked as exc:
                raise ExecutionDisabled(str(exc)) from exc
        if self.trader is None:
            raise ExecutionDisabled('Live Wallex trader is not configured; no order was sent')
        from .wallex_trade import WallexTradeError
        try:
            return self.trader.place_limit_order(order.get('symbol'), order.get('side'), order.get('price'),
                                                 order.get('quantity'), order.get('client_id'))
        except WallexTradeError as exc:
            raise ExecutionDisabled(str(exc)) from exc
