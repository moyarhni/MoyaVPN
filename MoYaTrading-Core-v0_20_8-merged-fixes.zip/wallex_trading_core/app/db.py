from datetime import datetime, timezone
from sqlalchemy import create_engine, String, DateTime, Text, Integer, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from .config import settings

connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

class Base(DeclarativeBase):
    pass

class MarketEvent(Base):
    __tablename__ = "market_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    symbol: Mapped[str] = mapped_column(String(24), index=True)
    event_type: Mapped[str] = mapped_column(String(32), index=True)
    exchange_ts: Mapped[str | None] = mapped_column(String(64), nullable=True)
    received_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), index=True)
    payload: Mapped[str] = mapped_column(Text)

class SystemEvent(Base):
    __tablename__ = "system_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    level: Mapped[str] = mapped_column(String(16))
    message: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

def init_db():
    Base.metadata.create_all(bind=engine)


class HistoricalCandle(Base):
    __tablename__ = "historical_candles"
    __table_args__ = (UniqueConstraint("symbol", "resolution", "timestamp", name="uq_historical_candle"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    symbol: Mapped[str] = mapped_column(String(24), index=True)
    resolution: Mapped[str] = mapped_column(String(8), index=True)
    timestamp: Mapped[int] = mapped_column(Integer, index=True)
    open: Mapped[str] = mapped_column(String(64))
    high: Mapped[str] = mapped_column(String(64))
    low: Mapped[str] = mapped_column(String(64))
    close: Mapped[str] = mapped_column(String(64))
    volume: Mapped[str] = mapped_column(String(64))

class ForecastAuditRecord(Base):
    """Persistent, delayed labels for previously emitted OOS forecasts."""
    __tablename__ = "forecast_audit_records"
    __table_args__ = (UniqueConstraint("symbol", "resolution", "forecast_timestamp", name="uq_forecast_audit_key"),)
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    symbol: Mapped[str] = mapped_column(String(24), index=True)
    resolution: Mapped[str] = mapped_column(String(8), index=True)
    forecast_timestamp: Mapped[int] = mapped_column(Integer, index=True)
    due_timestamp: Mapped[int] = mapped_column(Integer, index=True)
    entry_price: Mapped[str] = mapped_column(String(48))
    direction: Mapped[str] = mapped_column(String(8))
    confidence: Mapped[str] = mapped_column(String(24))
    min_move_pct: Mapped[str] = mapped_column(String(24), default="0.0025")
    regime: Mapped[str] = mapped_column(String(32), default="UNKNOWN")
    outcome: Mapped[int | None] = mapped_column(Integer, nullable=True)
    resolved_timestamp: Mapped[int | None] = mapped_column(Integer, nullable=True)
