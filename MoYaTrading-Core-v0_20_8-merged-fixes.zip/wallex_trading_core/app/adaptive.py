"""Safe model monitoring. Records outcomes; never changes the active model."""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass
from math import sqrt
from typing import Iterable

@dataclass(frozen=True)
class ForecastOutcome:
    timestamp: int
    probability: float
    outcome: int
    regime: str = "UNKNOWN"
    timeframe: str = "UNKNOWN"

    def validate(self):
        if self.timestamp <= 0 or not 0 <= self.probability <= 1 or self.outcome not in (0, 1):
            raise ValueError("Invalid forecast outcome")


def brier_score(items: Iterable[ForecastOutcome]) -> float | None:
    rows = list(items)
    return sum((x.probability-x.outcome)**2 for x in rows)/len(rows) if rows else None


def expected_calibration_error(items: Iterable[ForecastOutcome], bins: int = 10) -> float | None:
    rows = list(items)
    if bins < 2 or not rows:
        return None
    total = 0.0
    for i in range(bins):
        lo, hi = i/bins, (i+1)/bins
        group = [x for x in rows if lo <= x.probability < hi or (i == bins-1 and x.probability == 1)]
        if group:
            confidence = sum(x.probability for x in group)/len(group)
            accuracy = sum(x.outcome for x in group)/len(group)
            total += len(group)/len(rows)*abs(confidence-accuracy)
    return total


class DriftMonitor:
    """Compare recent Brier loss with a baseline; requires enough resolved labels."""
    def __init__(self, baseline_size: int = 100, recent_size: int = 30, min_samples: int = 20,
                 relative_degradation: float = 0.35, absolute_degradation: float = 0.03):
        if baseline_size < recent_size or recent_size < min_samples or min_samples < 5:
            raise ValueError("Invalid drift window sizes")
        self.baseline_size, self.recent_size, self.min_samples = baseline_size, recent_size, min_samples
        self.relative_degradation, self.absolute_degradation = relative_degradation, absolute_degradation
        self._items: deque[ForecastOutcome] = deque(maxlen=baseline_size+recent_size)

    def add(self, item: ForecastOutcome):
        item.validate(); self._items.append(item)

    def status(self) -> dict:
        rows = list(self._items)
        recent = rows[-self.recent_size:]
        baseline = rows[-(self.recent_size+self.baseline_size):-self.recent_size]
        if len(recent) < self.min_samples or len(baseline) < self.min_samples:
            return {"status": "insufficient_history", "drift_detected": False,
                    "recent_samples": len(recent), "baseline_samples": len(baseline),
                    "action": "NO_MODEL_CHANGE"}
        r, b = brier_score(recent), brier_score(baseline)
        delta = r-b
        drift = delta >= max(self.absolute_degradation, abs(b)*self.relative_degradation)
        return {"status": "drift_detected" if drift else "stable", "drift_detected": drift,
                "baseline_brier": round(b, 6), "recent_brier": round(r, 6),
                "absolute_degradation": round(delta, 6), "action": "BLOCK_NEW_ENTRIES_AND_RETRAIN_CHALLENGER" if drift else "NO_MODEL_CHANGE",
                "promotion_policy": "challenger_requires_independent_walk_forward_validation"}


def walk_forward_splits(n: int, *, min_train: int, test_size: int, step: int | None = None, purge: int = 0):
    """Yield expanding chronological (train_end, test_start, test_end) boundaries."""
    if min_train < 1 or test_size < 1 or purge < 0 or n < min_train + purge + test_size:
        return []
    step = step or test_size
    if step < 1:
        raise ValueError("step must be positive")
    out, train_end = [], min_train
    while train_end + purge + test_size <= n:
        start = train_end + purge
        out.append((train_end, start, start+test_size))
        train_end += step
    return out
