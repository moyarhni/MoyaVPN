from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    wallex_base_url: str = "https://api.wallex.ir"
    symbols: str = "BTCUSDT,BTCTMN,USDTTMN"
    poll_seconds: int = 15
    request_timeout_seconds: float = 10
    database_url: str = "sqlite:///./wallex_market.db"
    max_market_data_age_seconds: int = 60
    moya_api_token: str = ""
    wallex_api_key: str = ""
    paper_auto_trading_enabled: bool = False
    paper_fee_rate: float = Field(default=0.001, ge=0, lt=1)
    paper_max_slippage_bps: float = Field(default=50.0, ge=0, le=5000)
    max_total_exposure_fraction: float = Field(default=0.50, gt=0, le=1)
    live_trading_enabled: bool = False
    auto_analysis_enabled: bool = True
    analysis_resolution: str = "60"
    analysis_lookback_candles: int = 250
    forecast_enabled: bool = True
    forecast_timeframes: str = "5,15,60,240,1D"
    forecast_lookback_candles: int = 1000
    forecast_refresh_seconds: int = 300

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def symbol_list(self) -> list[str]:
        return [s.strip().upper() for s in self.symbols.split(",") if s.strip()]

    @property
    def forecast_timeframe_list(self) -> list[str]:
        return [s.strip() for s in self.forecast_timeframes.split(",") if s.strip()]

settings = Settings()
