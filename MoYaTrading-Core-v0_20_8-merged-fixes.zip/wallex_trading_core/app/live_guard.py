"""Persistent guard for LIVE trading (stdlib sqlite3 only; independent of the paper ledger).

Rules (project directive):
- Live trading is OFF by default and is enabled only by an explicit confirmation phrase.
- After the first realized live loss, live entries are locked. The lock survives restarts.
- Closing existing positions is never blocked by this guard.
- Unlocking requires its own explicit confirmation and leaves live trading DISABLED
  (it must be enabled again separately).
Paper trading and data collection are not affected by this guard.
"""
from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation

ENABLE_PHRASE = "ENABLE LIVE TRADING"
UNLOCK_PHRASE = "UNLOCK AFTER LOSS"


class LiveTradingBlocked(RuntimeError):
    pass


def default_path() -> str:
    return os.environ.get("MOYA_GUARD_DB", "./moya_live_guard.db")


class LiveGuard:
    def __init__(self, db_path: str | None = None):
        self.db_path = db_path or default_path()
        with self._conn() as c:
            c.execute("CREATE TABLE IF NOT EXISTS guard_state ("
                      "id INTEGER PRIMARY KEY CHECK (id = 1), live_enabled INTEGER NOT NULL DEFAULT 0, "
                      "locked INTEGER NOT NULL DEFAULT 0, lock_reason TEXT, updated_at TEXT NOT NULL)")
            c.execute("CREATE TABLE IF NOT EXISTS recorded_trades ("
                      "trade_id TEXT PRIMARY KEY, net_pnl TEXT NOT NULL, recorded_at TEXT NOT NULL)")
            c.execute("INSERT OR IGNORE INTO guard_state (id, live_enabled, locked, updated_at) VALUES (1, 0, 0, ?)",
                      (self._now(),))

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.db_path, isolation_level=None, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            # SQLite creates files with permissions controlled by the process umask.
            # Restrict the guard database because it controls whether live entries are allowed.
            try:
                os.chmod(self.db_path, 0o600)
            except OSError:
                pass
            yield conn
        finally:
            conn.close()

    def status(self) -> dict:
        with self._conn() as c:
            r = c.execute("SELECT * FROM guard_state WHERE id = 1").fetchone()
        return {"live_enabled": bool(r["live_enabled"]), "locked": bool(r["locked"]),
                "lock_reason": r["lock_reason"], "updated_at": r["updated_at"],
                "new_live_entries_allowed": bool(r["live_enabled"]) and not bool(r["locked"]),
                "closing_allowed": True}

    def enable(self, confirmation: str) -> dict:
        if confirmation != ENABLE_PHRASE:
            raise LiveTradingBlocked("Explicit confirmation phrase required to enable live trading")
        with self._conn() as c:
            c.execute("BEGIN IMMEDIATE")
            r = c.execute("SELECT locked FROM guard_state WHERE id = 1").fetchone()
            if r["locked"]:
                c.execute("ROLLBACK")
                raise LiveTradingBlocked("Live trading is locked after a realized loss; unlock explicitly first")
            c.execute("UPDATE guard_state SET live_enabled = 1, updated_at = ? WHERE id = 1", (self._now(),))
            c.execute("COMMIT")
        return self.status()

    def disable(self) -> dict:
        with self._conn() as c:
            c.execute("UPDATE guard_state SET live_enabled = 0, updated_at = ? WHERE id = 1", (self._now(),))
        return self.status()

    def record_realized_pnl(self, trade_id: str, net_pnl: Decimal | str) -> dict:
        """Record a closed LIVE trade. The first net loss locks entries and disables live trading.
        Idempotent per trade_id."""
        if not trade_id or not str(trade_id).strip():
            raise ValueError("trade_id is required")
        try:
            pnl = Decimal(str(net_pnl))
        except InvalidOperation as exc:
            raise ValueError("net_pnl must be a decimal number") from exc
        if not pnl.is_finite():
            raise ValueError("net_pnl must be finite")
        with self._conn() as c:
            c.execute("BEGIN IMMEDIATE")
            if c.execute("SELECT 1 FROM recorded_trades WHERE trade_id = ?", (trade_id,)).fetchone() is None:
                c.execute("INSERT INTO recorded_trades (trade_id, net_pnl, recorded_at) VALUES (?, ?, ?)",
                          (trade_id, str(pnl), self._now()))
                if pnl < 0:
                    c.execute("UPDATE guard_state SET locked = 1, live_enabled = 0, "
                              "lock_reason = COALESCE(lock_reason, 'first_realized_loss'), updated_at = ? WHERE id = 1",
                              (self._now(),))
            c.execute("COMMIT")
        return self.status()

    def unlock(self, confirmation: str) -> dict:
        if confirmation != UNLOCK_PHRASE:
            raise LiveTradingBlocked("Explicit confirmation phrase required to unlock")
        with self._conn() as c:
            c.execute("UPDATE guard_state SET locked = 0, lock_reason = NULL, live_enabled = 0, updated_at = ? "
                      "WHERE id = 1", (self._now(),))
        return self.status()

    def assert_can_open(self) -> None:
        s = self.status()
        if s["locked"]:
            raise LiveTradingBlocked(f"Live entries locked: {s['lock_reason']}")
        if not s["live_enabled"]:
            raise LiveTradingBlocked("Live trading is disabled (default)")
