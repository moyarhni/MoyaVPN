"""Conservative paper execution stress model. Never sends exchange orders."""
from __future__ import annotations
from decimal import Decimal
from .paper import D, Side, simulate_market_fill, PaperSimulationError


def simulate_execution(book: dict, side: Side | str, quantity, *, fee_rate="0.001",
                        max_slippage_bps="100", latency_ms=250, volatility_bps_per_s="8",
                        stale_after_ms=1500, available_fraction="1") -> dict:
    latency = int(latency_ms)
    stale = int(stale_after_ms)
    vol = D(volatility_bps_per_s, "volatility_bps_per_s")
    fraction = D(available_fraction, "available_fraction")
    if latency < 0 or stale < 0 or vol < 0 or not 0 < fraction <= 1:
        raise PaperSimulationError("Invalid execution stress parameters")
    if latency > stale:
        return {"status": "rejected_stale_book", "filled_quantity": "0", "unfilled_quantity": str(D(quantity, "quantity")),
                "latency_ms": latency, "stale_after_ms": stale, "orders_submitted": False}
    requested = D(quantity, "quantity")
    adjusted_qty = requested * fraction
    fill = simulate_market_fill(book, side, adjusted_qty, fee_rate, max_slippage_bps)
    latency_slippage = vol * D(latency) / D(1000)
    side_enum = Side(side)
    avg = fill.average_price
    if avg is not None and latency_slippage:
        factor = D(1) + latency_slippage/D(10000) if side_enum == Side.BUY else D(1) - latency_slippage/D(10000)
        avg *= factor
    unfilled = requested - fill.filled_quantity
    return {"status": "filled" if unfilled == 0 else "partial" if fill.filled_quantity > 0 else fill.status,
            "requested_quantity": str(requested), "filled_quantity": str(fill.filled_quantity),
            "unfilled_quantity": str(unfilled), "book_average_price": str(fill.average_price) if fill.average_price is not None else None,
            "latency_adjusted_average_price": str(avg) if avg is not None else None,
            "book_slippage_bps": str(fill.slippage_bps) if fill.slippage_bps is not None else None,
            "latency_slippage_bps": str(latency_slippage), "fee_quote": str(fill.fee_quote),
            "latency_ms": latency, "partial_fill_model": "visible_depth_fraction",
            "orders_submitted": False, "note": "Stress estimate only; no queue position or exchange matching guarantee."}
