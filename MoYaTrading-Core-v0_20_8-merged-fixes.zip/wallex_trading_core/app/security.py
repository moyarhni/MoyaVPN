"""Fail-closed API bearer-token guard.

Only /health is public. Configure MOYA_API_TOKEN before using protected API
routes, including interactive documentation and the OpenAPI schema.
"""
import secrets

from fastapi import Request
from fastapi.responses import JSONResponse

from .config import settings


class ApiSecurityMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)

        request = Request(scope, receive=receive)
        if request.url.path == "/health":
            return await self.app(scope, receive, send)

        token = (getattr(settings, "moya_api_token", "") or "").strip()
        if not token:
            response = JSONResponse(
                {"detail": "API authentication is not configured"},
                status_code=503,
            )
            return await response(scope, receive, send)

        supplied = request.headers.get("authorization", "")
        scheme, separator, credential = supplied.partition(" ")
        if (
            not separator
            or scheme.lower() != "bearer"
            or not credential
            or not secrets.compare_digest(credential, token)
        ):
            response = JSONResponse({"detail": "Unauthorized"}, status_code=401)
            return await response(scope, receive, send)

        return await self.app(scope, receive, send)
