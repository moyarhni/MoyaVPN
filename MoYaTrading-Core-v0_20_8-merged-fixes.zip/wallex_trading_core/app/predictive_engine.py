"""Multi-timeframe, walk-forward market forecasting (research/paper only).

The model is a small regularized logistic classifier trained on lagged OHLCV
features. Labels use only future closes that are already available at fit time.
A chronological, purged holdout supplies out-of-sample calibration evidence.
The engine refuses to emit a usable probability when the holdout is too small.
It never places orders and its output is not a promise of profitability.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import exp, log
from statistics import mean, pstdev
from typing import Mapping, Sequence

from .market_data import Candle
from .regime import classify_regime
from .adaptive import ForecastOutcome, expected_calibration_error


@dataclass(frozen=True)
class ForecastConfig:
    horizon_bars: int = 3
    min_move_pct: float = 0.0025
    min_training_samples: int = 120
    min_oos_samples: int = 40
    min_local_calibration_samples: int = 30
    epochs: int = 350
    learning_rate: float = 0.08
    l2: float = 0.02
    success_threshold_pct: float = 80.0
    min_timeframe_votes: int = 3

    def validate(self) -> None:
        if self.horizon_bars < 1 or self.min_move_pct < 0:
            raise ValueError("Invalid forecast horizon or minimum move")
        if self.min_training_samples < 30 or self.min_oos_samples < 10:
            raise ValueError("Training and OOS sample requirements are too small")
        if self.min_local_calibration_samples < 10:
            raise ValueError("Local calibration sample requirement is too small")
        if not 50 <= self.success_threshold_pct <= 99.9:
            raise ValueError("success threshold must be between 50 and 99.9")


# Feature vector uses information available at the decision candle only.
FEATURE_NAMES = (
    "return_1", "return_3", "return_6", "return_12", "ema_spread",
    "rsi_scaled", "atr_pct", "volume_ratio", "candle_body_ratio",
)


def _ema(values: Sequence[float], period: int) -> float:
    alpha = 2.0 / (period + 1.0)
    result = values[0]
    for value in values[1:]:
        result = alpha * value + (1.0 - alpha) * result
    return result


def _features(candles: Sequence[Candle], index: int) -> list[float]:
    # Every feature uses at most the latest 21 candles. Avoid rebuilding the
    # entire prefix for every historical row (quadratic work on long histories).
    start = max(0, index - 20)
    window = candles[start: index + 1]
    closes = [float(c.close) for c in window]
    current = window[-1]
    returns = [closes[-1] / closes[-1 - n] - 1.0 for n in (1, 3, 6, 12)]
    fast = _ema(closes[-min(len(closes), 9):], 9)
    slow = _ema(closes[-min(len(closes), 21):], 21)
    gains, losses = [], []
    for previous, value in zip(closes[-15:-1], closes[-14:]):
        change = value - previous
        gains.append(max(change, 0.0))
        losses.append(max(-change, 0.0))
    avg_gain = sum(gains) / 14.0
    avg_loss = sum(losses) / 14.0
    rsi = 100.0 if avg_loss == 0 and avg_gain > 0 else 50.0 if avg_loss == 0 else 100.0 - 100.0 / (1.0 + avg_gain / avg_loss)
    true_ranges = []
    for prev, cur in zip(window[-15:-1], window[-14:]):
        prev_close = float(prev.close)
        true_ranges.append(max(float(cur.high) - float(cur.low), abs(float(cur.high) - prev_close), abs(float(cur.low) - prev_close)))
    atr_pct = (sum(true_ranges) / max(1, len(true_ranges))) / float(current.close)
    prior_volumes = [float(c.volume) for c in window[-21:-1]]
    avg_volume = sum(prior_volumes) / len(prior_volumes) if prior_volumes else 0.0
    volume_ratio = min(5.0, float(current.volume) / avg_volume) if avg_volume > 0 else 1.0
    candle_range = max(float(current.high) - float(current.low), 1e-12)
    body_ratio = (float(current.close) - float(current.open)) / candle_range
    values = returns + [fast / slow - 1.0, rsi / 100.0, atr_pct, volume_ratio, body_ratio]
    return [max(-5.0, min(5.0, x)) for x in values]


def _dataset(candles: Sequence[Candle], cfg: ForecastConfig):
    rows, labels, indices = [], [], []
    first = 30
    last = len(candles) - cfg.horizon_bars
    for i in range(first, last):
        future_return = float(candles[i + cfg.horizon_bars].close / candles[i].close - 1)
        rows.append(_features(candles, i))
        labels.append(1 if future_return > cfg.min_move_pct else 0 if future_return < -cfg.min_move_pct else -1)
        indices.append(i)
    return rows, labels, indices


def _sigmoid(value: float) -> float:
    value = max(-35.0, min(35.0, value))
    return 1.0 / (1.0 + exp(-value))


def _fit(rows: list[list[float]], labels: list[int], cfg: ForecastConfig):
    width = len(FEATURE_NAMES)
    means = [mean(row[j] for row in rows) for j in range(width)]
    scales = [pstdev(row[j] for row in rows) or 1.0 for j in range(width)]
    normalized = [[(row[j] - means[j]) / scales[j] for j in range(width)] for row in rows]
    weights = [0.0] * width
    bias = log((sum(labels) + 1.0) / (len(labels) - sum(labels) + 1.0))
    for _ in range(cfg.epochs):
        grad = [0.0] * width
        grad_bias = 0.0
        for row, label in zip(normalized, labels):
            error = _sigmoid(sum(w * x for w, x in zip(weights, row)) + bias) - label
            grad_bias += error
            for j, x in enumerate(row):
                grad[j] += error * x
        n = float(len(labels))
        bias -= cfg.learning_rate * grad_bias / n
        for j in range(width):
            weights[j] -= cfg.learning_rate * (grad[j] / n + cfg.l2 * weights[j])
    return {"means": means, "scales": scales, "weights": weights, "bias": bias}


def _predict(model: dict, row: list[float]) -> float:
    normalized = [(row[j] - model["means"][j]) / model["scales"][j] for j in range(len(row))]
    return _sigmoid(sum(w * x for w, x in zip(model["weights"], normalized)) + model["bias"])


def _isotonic_calibrator(probabilities: list[float], labels: list[int]):
    """Pool-adjacent-violators fit using OOS predictions only."""
    ordered = sorted(zip(probabilities, labels), key=lambda item: item[0])
    blocks = []
    for probability, label in ordered:
        blocks.append([probability, probability, float(label), 1])
        while len(blocks) >= 2:
            left, right = blocks[-2], blocks[-1]
            if left[2] / left[3] <= right[2] / right[3]:
                break
            blocks[-2:] = [[left[0], right[1], left[2] + right[2], left[3] + right[3]]]
    return blocks


def _calibrate(probability: float, blocks: list[list[float]]) -> float:
    for low, high, positives, count in blocks:
        if low <= probability <= high:
            # Beta(1, 1) smoothing prevents tiny isotonic blocks from emitting
            # unjustified exact 0% or 100% probabilities.
            return (positives + 1.0) / (count + 2.0)
    nearest = min(blocks, key=lambda b: min(abs(probability - b[0]), abs(probability - b[1])))
    return (nearest[2] + 1.0) / (nearest[3] + 2.0)


def _wilson_lower(successes: int, total: int, z: float = 1.96) -> float:
    if total <= 0:
        return 0.0
    p = successes / total
    denominator = 1.0 + z * z / total
    centre = p + z * z / (2.0 * total)
    margin = z * ((p * (1.0 - p) / total + z * z / (4.0 * total * total)) ** 0.5)
    return max(0.0, (centre - margin) / denominator)


def _validate_candles(candles: Sequence[Candle]) -> None:
    if len(candles) < 60:
        raise ValueError("At least 60 closed candles are required")
    previous = 0
    for candle in candles:
        if candle.timestamp <= previous:
            raise ValueError("Candles must be strictly chronological")
        previous = candle.timestamp
        if min(candle.open, candle.high, candle.low, candle.close) <= 0 or candle.volume < 0:
            raise ValueError("Invalid OHLCV values")
        if candle.high < max(candle.open, candle.low, candle.close) or candle.low > min(candle.open, candle.high, candle.close):
            raise ValueError("Invalid OHLC range")


def forecast_timeframe(candles: Sequence[Candle], timeframe: str, cfg: ForecastConfig | None = None) -> dict:
    cfg = cfg or ForecastConfig()
    cfg.validate()
    _validate_candles(candles)
    rows, labels, indices = _dataset(candles, cfg)
    # Three chronological segments: fit, calibration, and untouched reliability holdout.
    # Neutral outcomes remain in the timeline and are estimated separately.
    fit_end = int(len(rows) * 0.60)
    calibration_end = int(len(rows) * 0.80)
    calibration_start_index = indices[fit_end] if fit_end < len(indices) else len(candles)
    reliability_start_index = indices[calibration_end] if calibration_end < len(indices) else len(candles)
    fit_indices = [j for j, idx in enumerate(indices[:fit_end])
                   if idx + cfg.horizon_bars < calibration_start_index and labels[j] != -1]
    calibration_indices = [j for j in range(fit_end, calibration_end)
                           if indices[j] + cfg.horizon_bars < reliability_start_index and labels[j] != -1]
    reliability_all_indices = list(range(calibration_end, len(rows)))
    reliability_indices = [j for j in reliability_all_indices if labels[j] != -1]
    train_rows = [rows[j] for j in fit_indices]
    train_labels = [labels[j] for j in fit_indices]
    calibration_rows = [rows[j] for j in calibration_indices]
    calibration_labels = [labels[j] for j in calibration_indices]
    reliability_rows = [rows[j] for j in reliability_indices]
    reliability_labels = [labels[j] for j in reliability_indices]
    if len(train_rows) < cfg.min_training_samples:
        return {"timeframe": timeframe, "status": "insufficient_training_data", "training_samples": len(train_rows),
                "required_training_samples": cfg.min_training_samples, "success_probability_pct": None}
    if len(calibration_rows) < cfg.min_oos_samples or len(reliability_rows) < cfg.min_oos_samples:
        return {"timeframe": timeframe, "status": "insufficient_oos_data",
                "calibration_samples": len(calibration_rows), "oos_samples": len(reliability_rows),
                "required_samples_per_holdout": cfg.min_oos_samples, "success_probability_pct": None}

    model = _fit(train_rows, train_labels, cfg)
    calibration_raw = [_predict(model, row) for row in calibration_rows]
    calibrator = _isotonic_calibrator(calibration_raw, calibration_labels)
    reliability_raw = [_predict(model, row) for row in reliability_rows]
    reliability_calibrated = [_calibrate(p, calibrator) for p in reliability_raw]
    # Score the probabilities that are actually exposed to callers.
    brier = sum((p - y) ** 2 for p, y in zip(reliability_calibrated, reliability_labels)) / len(reliability_labels)
    reliability_outcomes = [ForecastOutcome(timestamp=int(indices[j]), probability=float(p), outcome=int(y), regime="UNKNOWN", timeframe=timeframe)
                            for j, p, y in zip(reliability_indices, reliability_calibrated, reliability_labels)]
    ece = expected_calibration_error(reliability_outcomes, bins=10)
    regime = classify_regime(candles)
    neutral_count = sum(1 for j in reliability_all_indices if labels[j] == -1)
    neutral_rate = neutral_count / len(reliability_all_indices) if reliability_all_indices else 1.0
    raw_probability = _predict(model, _features(candles, len(candles) - 1))
    calibrated_probability = _calibrate(raw_probability, calibrator)
    direction = "BULLISH" if calibrated_probability >= 0.5 else "BEARISH"
    local = [(p, y) for p, y in zip(reliability_calibrated, reliability_labels)
             if abs(p - calibrated_probability) <= 0.10]
    wins = sum(1 for _, y in local if (y == 1 if direction == "BULLISH" else y == 0))
    conditional_lower_bound = _wilson_lower(wins, len(local)) if len(local) >= cfg.min_local_calibration_samples else None
    unconditional_lower_bound = conditional_lower_bound * (1.0 - neutral_rate) if conditional_lower_bound is not None else None
    bullish_scenario = (1.0 - neutral_rate) * calibrated_probability
    bearish_scenario = (1.0 - neutral_rate) * (1.0 - calibrated_probability)
    return {
        "timeframe": timeframe, "status": "calibrated" if unconditional_lower_bound is not None else "calibration_sample_too_small",
        "direction": direction, "horizon_bars": cfg.horizon_bars,
        "raw_bullish_probability_pct": round(raw_probability * 100, 2),
        "calibrated_bullish_probability_pct": round(calibrated_probability * 100, 2),
        "scenarios": {"bullish_pct": round(bullish_scenario * 100, 2),
                      "bearish_pct": round(bearish_scenario * 100, 2),
                      "neutral_pct": round(neutral_rate * 100, 2)},
        "success_probability_pct": round(unconditional_lower_bound * 100, 2) if unconditional_lower_bound is not None else None,
        "conditional_directional_precision_lower_bound_pct": round(conditional_lower_bound * 100, 2) if conditional_lower_bound is not None else None,
        "local_oos_samples": len(local), "local_oos_wins": wins if unconditional_lower_bound is not None else None,
        "training_samples": len(train_rows), "calibration_samples": len(calibration_rows), "oos_samples": len(reliability_rows),
        "neutral_oos_samples": neutral_count, "reliability_oos_total_samples": len(reliability_all_indices),
        "oos_brier_score": round(brier, 5), "oos_brier_probability_source": "calibrated",
        "oos_expected_calibration_error": round(ece, 5) if ece is not None else None,
        "regime": regime,
        "uncertainty": {"high": ece is None or ece > 0.15 or len(local) < cfg.min_local_calibration_samples,
                        "reason": "calibration_error_or_local_sample_uncertainty"},
        "last_candle_timestamp": candles[-1].timestamp,
        "last_close": str(candles[-1].close),
        "method": "regularized_logistic_model_with_purged_fit_calibration_and_untouched_reliability_holdouts",
        "probability_note": "scenario percentages are empirical conditional-direction estimates adjusted by the holdout neutral rate; success_probability_pct is the 95% Wilson lower bound of local directional precision multiplied by one minus the holdout neutral rate. These are research estimates, not guarantees.",
    }


def forecast_market(timeframes: Mapping[str, Sequence[Candle]], *, symbol: str,
                    cfg: ForecastConfig | None = None) -> dict:
    cfg = cfg or ForecastConfig()
    cfg.validate()
    if not symbol or not symbol.strip():
        raise ValueError("symbol is required")
    results = []
    for timeframe, candles in timeframes.items():
        try:
            results.append(forecast_timeframe(candles, timeframe, cfg))
        except (ValueError, ArithmeticError, OverflowError) as exc:
            results.append({"timeframe": timeframe, "status": "invalid_data", "error": str(exc),
                            "success_probability_pct": None})
    calibrated = [r for r in results if r.get("status") == "calibrated" and r.get("success_probability_pct") is not None]
    bullish = [r for r in calibrated if r["direction"] == "BULLISH"]
    bearish = [r for r in calibrated if r["direction"] == "BEARISH"]
    majority = "BULLISH" if len(bullish) > len(bearish) else "BEARISH" if len(bearish) > len(bullish) else "MIXED"
    aligned = bullish if majority == "BULLISH" else bearish if majority == "BEARISH" else []
    # Conservative ensemble score: weakest validated lower bound among agreeing timeframes.
    conservative = min((r["success_probability_pct"] for r in aligned), default=None)
    opposition_count = len(bearish if majority == "BULLISH" else bullish if majority == "BEARISH" else calibrated)
    enough_votes = len(calibrated) >= cfg.min_timeframe_votes and len(aligned) >= cfg.min_timeframe_votes
    high_volatility = any(r.get("regime", {}).get("regime") == "HIGH_VOLATILITY" for r in calibrated)
    uncertain = any(r.get("uncertainty", {}).get("high", True) for r in calibrated)
    threshold_passed = bool(enough_votes and conservative is not None and conservative > cfg.success_threshold_pct
                            and not high_volatility and not uncertain)
    if majority == "BULLISH" and threshold_passed:
        action = "BUY_CANDIDATE"
    elif majority == "BEARISH" and threshold_passed:
        action = "REDUCE_RISK_OR_EXIT"  # Spot only; never opens a short.
    else:
        action = "NO_TRADE"
    return {
        "engine": "moya_predictive_intelligence_v1", "symbol": symbol.upper(),
        "mode": "research_and_paper_gate_only", "direction": majority,
        "action": action, "conservative_success_probability_pct": round(conservative, 2) if conservative is not None else None,
        "required_probability_strictly_above_pct": cfg.success_threshold_pct,
        "calibrated_timeframes": len(calibrated), "aligned_timeframes": len(aligned),
        "opposition": {"opposing_timeframes": opposition_count,
                       "summary": "Opposing timeframe votes are counted; mixed or insufficient votes block entry."},
        "entry_gate_passed": threshold_passed and majority == "BULLISH",
        "market_regime_guard": {"high_volatility_detected": high_volatility, "uncertainty_detected": uncertain,
                                "entry_blocked_if_true": True},
        "live_trading_enabled": False, "orders_submitted": False,
        "timeframes": results,
        "safety": {"scores_are_probabilities": False, "probability_source": "purged chronological out-of-sample local precision lower bound",
                   "spot_shorting_disabled": True, "live_order_execution": "disabled"},
    }
