"""Authenticated, read-only Wallex account adapter. No order mutation methods."""
from __future__ import annotations
import httpx
from .config import settings

class WallexPrivateAPIError(RuntimeError):
    pass

class WallexAccountClient:
    """Reads balances/open orders. API key is supplied from environment, never logged."""
    def __init__(self, api_key: str | None = None, base_url: str | None = None, timeout: float = 10):
        key = api_key if api_key is not None else getattr(settings, "wallex_api_key", "")
        if not key or not key.strip():
            raise ValueError("WALLEX_API_KEY is required for private read-only access")
        self._client = httpx.AsyncClient(base_url=(base_url or settings.wallex_base_url).rstrip("/"),
            timeout=timeout, headers={"Accept":"application/json", "X-API-Key":key.strip(),
                                      "User-Agent":"MoYaTrading-Core/0.20.7"})

    async def close(self):
        await self._client.aclose()

    async def _get(self, path: str, params: dict | None = None):
        try:
            response = await self._client.get(path, params=params)
            response.raise_for_status(); payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise WallexPrivateAPIError(f"Wallex private request failed: {type(exc).__name__}") from exc
        if not isinstance(payload, dict) or payload.get("success") is False:
            raise WallexPrivateAPIError("Wallex returned an unsuccessful private response")
        return payload

    async def balances(self):
        return await self._get("/v1/account/balances")

    async def open_orders(self, symbol: str | None = None, page: int = 1, per_page: int = 50):
        if page < 1 or not 1 <= per_page <= 100:
            raise ValueError("Invalid pagination")
        params = {"page":page, "per_page":per_page}
        if symbol:
            params["symbol"] = symbol.upper()
        return await self._get("/v1/account/openOrders", params)

    # Deliberately absent: submit_order(), cancel_order(), withdrawals().
