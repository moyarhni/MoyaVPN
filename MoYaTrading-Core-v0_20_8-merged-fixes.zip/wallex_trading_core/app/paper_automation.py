"""Opt-in automatic SPOT-LONG paper execution and protective exit management.

No exchange order mutation is possible from this module. Entries require an
explicit paper-auto setting and a BUY_CANDIDATE from the existing gated stack.
Intrabar stop/target ambiguity is resolved conservatively in favor of the stop.
"""
from __future__ import annotations
from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import settings
from .paper_ledger import (PaperPosition, PaperPositionPlan, PaperWallet, PaperTrade,
                           open_position, close_position, D)
from .risk_manager import check_portfolio_risk
from .exit_scan import find_exit


def _daily_loss(db: Session) -> Decimal:
    now = datetime.now(timezone.utc)
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0).replace(tzinfo=None)
    rows = db.scalars(select(PaperTrade).where(PaperTrade.closed_at >= midnight)).all()
    return sum((max(Decimal(0), -D(row.realized_pnl, "realized_pnl")) for row in rows), Decimal(0))



async def process_symbol_paper_cycle(client, db: Session, symbol: str, candle,
                                     decision: dict, forecast: dict | None, candles=None) -> dict:
    if not settings.paper_auto_trading_enabled:
        return {"enabled": False, "actions": [], "reason": "paper_auto_trading_disabled"}
    actions: list[dict] = []
    closed_this_cycle = False
    positions = db.scalars(select(PaperPosition).where(
        PaperPosition.symbol == symbol.upper(), PaperPosition.status == "OPEN",
        PaperPosition.direction == "LONG")).all()
    for position in positions:
        plan = db.get(PaperPositionPlan, position.id)
        if plan is None or candle.timestamp <= plan.last_checked_candle_ts:
            continue
        stop, target = D(plan.stop_loss, "stop_loss"), D(plan.take_profit, "take_profit")
        # Scan every closed candle since the last check, not only the newest one, so a stop
        # breached during a gap (restart / skipped cycle) is not missed.
        exit_hit = find_exit(candles or [candle], stop, target, plan.last_checked_candle_ts)
        plan.last_checked_candle_ts = max(plan.last_checked_candle_ts, candle.timestamp)
        if exit_hit:
            reason = exit_hit[0]
            plan.exit_reason = reason
            db.flush()
            book = await client.depth(symbol)
            trade, fill, replayed = close_position(db, position_id=position.id, book=book,
                idempotency_key=f"auto-close-{position.id}-{candle.timestamp}",
                fee_rate=str(settings.paper_fee_rate), max_slippage_bps=str(settings.paper_max_slippage_bps))
            closed_this_cycle = True
            actions.append({"action": "CLOSE", "position_id": position.id,
                "reason": reason, "realized_pnl": trade.realized_pnl,
                "fill_status": fill.status if fill else "replayed", "replayed": replayed})
        else:
            db.commit()

    # Avoid closing and reopening on the same candle, including after a process restart.
    if closed_this_cycle:
        return {"enabled": True, "actions": actions, "entry": "closed_this_cycle_no_reentry"}
    closed_on_this_candle = db.scalar(select(PaperPositionPlan).join(
        PaperPosition, PaperPosition.id == PaperPositionPlan.position_id
    ).where(PaperPosition.symbol == symbol.upper(), PaperPosition.status == "CLOSED",
            PaperPositionPlan.last_checked_candle_ts == candle.timestamp))
    if closed_on_this_candle is not None:
        return {"enabled": True, "actions": actions, "entry": "closed_on_this_candle_no_reentry"}
    # One open LONG per symbol. Bearish evidence never opens a SHORT in Spot mode.
    if db.scalar(select(PaperPosition).where(PaperPosition.symbol == symbol.upper(),
            PaperPosition.status == "OPEN")) is not None:
        return {"enabled": True, "actions": actions, "entry": "blocked_open_position_exists"}
    integrated = (forecast or {}).get("integrated_decision", {})
    if integrated.get("action") != "BUY_CANDIDATE":
        return {"enabled": True, "actions": actions, "entry": "no_qualified_buy_candidate"}
    if decision.get("action") != "BUY":
        return {"enabled": True, "actions": actions, "entry": "decision_not_buy"}
    wallet = db.get(PaperWallet, 1)
    if wallet is None:
        return {"enabled": True, "actions": actions, "entry": "paper_wallet_not_initialized"}
    price = D(candle.close, "close")
    stop_raw, target_raw = decision.get("levels", {}).get("stop_loss"), decision.get("levels", {}).get("take_profit")
    if not stop_raw or not target_raw:
        return {"enabled": True, "actions": actions, "entry": "protective_levels_missing"}
    stop, target = D(stop_raw, "stop_loss"), D(target_raw, "take_profit")
    if not 0 < stop < price < target:
        return {"enabled": True, "actions": actions, "entry": "invalid_protective_levels"}
    open_positions = db.scalars(select(PaperPosition).where(PaperPosition.status == "OPEN")).all()
    equity = D(wallet.available_balance, "available_balance") + sum(
        (D(p.collateral, "collateral") for p in open_positions), Decimal(0))
    exposure = [D(p.quantity, "quantity") * D(p.entry_price, "entry_price") for p in open_positions]
    risk = check_portfolio_risk(equity=equity, open_position_values=exposure,
        daily_realized_loss=_daily_loss(db),
        max_total_exposure_fraction=Decimal(str(settings.max_total_exposure_fraction)))
    if not risk["allowed"]:
        return {"enabled": True, "actions": actions, "entry": "portfolio_risk_blocked", "risk": risk}
    qty = D(decision.get("position", {}).get("suggested_buy_quantity", "0"), "suggested_quantity")
    if qty <= 0:
        return {"enabled": True, "actions": actions, "entry": "zero_suggested_quantity"}
    open_key = f"auto-open-{symbol.upper()}-{candle.timestamp}"
    prior_attempt = db.scalar(select(PaperPosition).where(PaperPosition.open_key == open_key))
    if prior_attempt is not None:
        return {"enabled": True, "actions": actions, "entry": "entry_already_attempted_this_candle"}
    book = await client.depth(symbol)
    position, fill, replayed = open_position(db, symbol=symbol, direction="LONG", quantity=qty,
        leverage="1", book=book, idempotency_key=open_key,
        fee_rate=str(settings.paper_fee_rate), max_slippage_bps=str(settings.paper_max_slippage_bps))
    if not replayed:
        db.add(PaperPositionPlan(position_id=position.id, stop_loss=str(stop),
            take_profit=str(target), source_candle_ts=int(candle.timestamp),
            last_checked_candle_ts=int(candle.timestamp)))
        db.commit()
    actions.append({"action": "OPEN", "position_id": position.id,
        "quantity": position.quantity, "entry_price": position.entry_price,
        "stop_loss": str(stop), "take_profit": str(target),
        "fill_status": fill.status if fill else "replayed", "replayed": replayed})
    return {"enabled": True, "actions": actions, "entry": "processed"}
