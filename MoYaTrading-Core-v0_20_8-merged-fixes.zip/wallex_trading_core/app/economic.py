"""Trade-economics helpers. These do not infer win probability from direction accuracy."""
from decimal import Decimal
D = Decimal


def evaluate_trade_economics(*, entry, target, stop, fee_rate="0.001", slippage_bps="5") -> dict:
    e, t, s, fee, slip = [D(str(x)) for x in (entry, target, stop, fee_rate, slippage_bps)]
    if any(not x.is_finite() for x in (e,t,s,fee,slip)) or e <= 0 or t <= e or s <= 0 or s >= e or fee < 0 or fee >= 1 or slip < 0:
        raise ValueError("Invalid long spot trade economics")
    friction = fee*2 + slip/D(10000)*2
    gross_reward = (t-e)/e
    gross_risk = (e-s)/e
    net_reward = gross_reward-friction
    net_risk = gross_risk+friction
    rr = net_reward/net_risk if net_risk > 0 else D(0)
    breakeven = net_risk/(net_reward+net_risk) if net_reward+net_risk > 0 else D(1)
    return {"gross_reward_pct": str(gross_reward*100), "gross_risk_pct": str(gross_risk*100),
            "estimated_round_trip_cost_pct": str(friction*100), "net_reward_pct": str(net_reward*100),
            "net_risk_pct": str(net_risk*100), "net_reward_risk_ratio": str(rr),
            "break_even_win_rate_pct": str(breakeven*100),
            "win_probability": None,
            "probability_note": "Not inferred. Requires separate target/stop first-passage labels and out-of-sample calibration."}


def _wilson_lower(successes: int, total: int, z: float = 1.96) -> float:
    if total <= 0:
        return 0.0
    p = successes / total
    den = 1 + z*z/total
    centre = p + z*z/(2*total)
    margin = z*((p*(1-p)/total + z*z/(4*total*total))**0.5)
    return max(0.0, (centre-margin)/den)


def estimate_first_passage_probability(candles, *, target_pct="0.02", stop_pct="0.01",
                                       horizon_bars=12, fee_rate="0.001", slippage_bps="5",
                                       min_samples=40) -> dict:
    """Estimate target-before-stop from chronological OHLC paths; same-bar ties count as losses."""
    target, stop = D(str(target_pct)), D(str(stop_pct))
    fee, slip = D(str(fee_rate)), D(str(slippage_bps))
    if target <= 0 or stop <= 0 or horizon_bars < 1 or min_samples < 10 or fee < 0 or slip < 0:
        raise ValueError("Invalid first-passage configuration")
    wins = losses = unresolved = 0
    # Non-overlapping paths reduce serial dependence in the binomial sample.
    for i in range(0, len(candles)-horizon_bars, horizon_bars):
        entry = D(str(candles[i].close))
        target_price, stop_price = entry*(1+target), entry*(1-stop)
        outcome = None
        for bar in candles[i+1:i+1+horizon_bars]:
            hit_target = D(str(bar.high)) >= target_price
            hit_stop = D(str(bar.low)) <= stop_price
            if hit_target and hit_stop:
                outcome = 0  # adverse tie-break; OHLC cannot reveal intrabar order
                break
            if hit_stop:
                outcome = 0; break
            if hit_target:
                outcome = 1; break
        if outcome is None: unresolved += 1
        elif outcome: wins += 1
        else: losses += 1
    n = wins+losses
    if n < min_samples:
        return {"status": "insufficient_first_passage_samples", "samples": n,
                "unresolved_paths": unresolved, "win_probability_lower_bound_pct": None,
                "action": "NO_TRADE"}
    p = wins/n
    cost = fee*2 + slip/D(10000)*2
    net_win = target-cost
    net_loss = stop+cost
    expectancy = p*net_win-(1-p)*net_loss
    lower = _wilson_lower(wins, n)
    return {"status": "estimated", "samples": n, "wins": wins, "losses": losses,
            "unresolved_paths": unresolved, "empirical_win_rate_pct": round(p*100, 3),
            "win_probability_lower_bound_pct": round(lower*100, 3),
            "net_expectancy_pct_per_trade": str(expectancy*100),
            "target_pct": str(target*100), "stop_pct": str(stop*100),
            "horizon_bars": horizon_bars, "tie_policy": "same_bar_target_and_stop_counts_as_loss",
            "sample_policy": "non_overlapping_horizons",
            "note": "Exploratory historical first-passage estimate, not an independent deployment holdout or guarantee; never use alone to authorize live entries."}
