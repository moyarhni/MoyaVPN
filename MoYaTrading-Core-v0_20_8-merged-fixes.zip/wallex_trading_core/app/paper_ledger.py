"""Persistent, exchange-isolated paper portfolio for LONG/SHORT margin-style tests.

This is a simplified research ledger. It does not model Wallex financing,
liquidation, collateral haircuts, or exchange-specific margin rules.
"""
from __future__ import annotations
from datetime import datetime, timezone
from decimal import Decimal
from uuid import uuid4

from sqlalchemy import Boolean, DateTime, Integer, String, Text, Numeric, cast, select, update
from sqlalchemy.orm import Mapped, Session, mapped_column

from .db import Base
from .paper import D, PaperFill, Side, simulate_market_fill


class PaperLedgerError(ValueError):
    pass


class PaperWallet(Base):
    __tablename__ = "paper_wallets"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    quote_asset: Mapped[str] = mapped_column(String(16), default="USDT")
    initial_balance: Mapped[str] = mapped_column(String(48))
    available_balance: Mapped[str] = mapped_column(String(48))
    realized_pnl: Mapped[str] = mapped_column(String(48), default="0")
    entry_paused: Mapped[bool] = mapped_column(Boolean, default=False)
    pause_reason: Mapped[str | None] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class PaperPosition(Base):
    __tablename__ = "paper_positions"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid4()))
    open_key: Mapped[str] = mapped_column(String(96), unique=True, index=True)
    symbol: Mapped[str] = mapped_column(String(24), index=True)
    direction: Mapped[str] = mapped_column(String(8))
    quantity: Mapped[str] = mapped_column(String(48))
    entry_price: Mapped[str] = mapped_column(String(48))
    collateral: Mapped[str] = mapped_column(String(48))
    entry_fee: Mapped[str] = mapped_column(String(48))
    leverage: Mapped[str] = mapped_column(String(24))
    status: Mapped[str] = mapped_column(String(12), default="OPEN", index=True)
    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    close_key: Mapped[str | None] = mapped_column(String(96), unique=True, nullable=True)


class PaperTrade(Base):
    __tablename__ = "paper_trades"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    position_id: Mapped[str] = mapped_column(String(36), index=True)
    symbol: Mapped[str] = mapped_column(String(24), index=True)
    direction: Mapped[str] = mapped_column(String(8))
    quantity: Mapped[str] = mapped_column(String(48))
    entry_price: Mapped[str] = mapped_column(String(48))
    exit_price: Mapped[str] = mapped_column(String(48))
    gross_pnl: Mapped[str] = mapped_column(String(48))
    entry_fee: Mapped[str] = mapped_column(String(48))
    exit_fee: Mapped[str] = mapped_column(String(48))
    realized_pnl: Mapped[str] = mapped_column(String(48))
    close_key: Mapped[str] = mapped_column(String(96), unique=True)
    closed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


def _wallet(db: Session) -> PaperWallet:
    wallet = db.get(PaperWallet, 1)
    if wallet is None:
        raise PaperLedgerError("Paper wallet is not initialized")
    return wallet


def initialize_wallet(db: Session, initial_balance: Decimal | str, quote_asset: str = "USDT") -> PaperWallet:
    existing = db.get(PaperWallet, 1)
    if existing:
        return existing
    balance = D(initial_balance, "initial_balance")
    asset = quote_asset.strip().upper()
    if balance <= 0 or not asset or len(asset) > 16:
        raise PaperLedgerError("Initial balance and quote asset must be valid")
    wallet = PaperWallet(id=1, quote_asset=asset, initial_balance=str(balance), available_balance=str(balance), realized_pnl="0")
    db.add(wallet)
    db.commit()
    db.refresh(wallet)
    return wallet


def open_position(
    db: Session, *, symbol: str, direction: str, quantity: Decimal | str,
    leverage: Decimal | str, book: dict, idempotency_key: str,
    fee_rate: Decimal | str = "0.001", max_slippage_bps: Decimal | str = "100",
) -> tuple[PaperPosition, PaperFill, bool]:
    """Open a fully-filled simulated position. Returns (position, fill, replayed)."""
    if not idempotency_key or len(idempotency_key) > 96:
        raise PaperLedgerError("A valid idempotency_key is required")
    existing = db.scalar(select(PaperPosition).where(PaperPosition.open_key == idempotency_key))
    direction = direction.upper()
    if direction not in {"LONG", "SHORT"}:
        raise PaperLedgerError("direction must be LONG or SHORT")
    qty, lev = D(quantity, "quantity"), D(leverage, "leverage")
    if qty <= 0 or lev < 1 or lev > 10:
        raise PaperLedgerError("quantity must be positive and leverage must be between 1 and 10")
    if existing:
        if existing.symbol != symbol.upper() or existing.direction != direction or D(existing.quantity, "quantity") != qty or D(existing.leverage, "leverage") != lev:
            raise PaperLedgerError("Idempotency key was already used for a different entry")
        return existing, None, True  # type: ignore[return-value]
    wallet = _wallet(db)
    side = Side.BUY if direction == "LONG" else Side.SELL
    fill = simulate_market_fill(book, side, qty, fee_rate, max_slippage_bps)
    if fill.status != "filled" or fill.average_price is None:
        raise PaperLedgerError("Paper entry requires a full simulated fill")
    collateral = fill.quote_value / lev
    needed = collateral + fill.fee_quote
    available = D(wallet.available_balance, "available_balance")
    if needed > available:
        raise PaperLedgerError("Insufficient paper balance for collateral and entry fee")
    # Atomic conditional debit prevents concurrent requests from overspending
    # the same paper wallet. Values remain decimal strings in the schema.
    debit = update(PaperWallet).where(
        PaperWallet.id == 1,
        cast(PaperWallet.available_balance, Numeric(38, 18)) >= needed,
    ).values(available_balance=cast(
        cast(PaperWallet.available_balance, Numeric(38, 18)) - needed, String(48)))
    result = db.execute(debit.execution_options(synchronize_session=False))
    if result.rowcount != 1:
        db.rollback()
        raise PaperLedgerError("Insufficient paper balance or concurrent wallet update")
    position = PaperPosition(
        symbol=symbol.upper(), direction=direction, quantity=str(qty),
        entry_price=str(fill.average_price), collateral=str(collateral),
        entry_fee=str(fill.fee_quote), leverage=str(lev), open_key=idempotency_key,
    )
    db.add(position)
    try:
        db.commit()
    except Exception:
        db.rollback()
        # Concurrent retry may have won the unique-key race.
        existing = db.scalar(select(PaperPosition).where(PaperPosition.open_key == idempotency_key))
        if existing:
            return existing, None, True  # type: ignore[return-value]
        raise
    db.refresh(position)
    return position, fill, False


def close_position(
    db: Session, *, position_id: str, book: dict, idempotency_key: str,
    fee_rate: Decimal | str = "0.001", max_slippage_bps: Decimal | str = "100",
) -> tuple[PaperTrade, PaperFill, bool]:
    if not idempotency_key or len(idempotency_key) > 96:
        raise PaperLedgerError("A valid idempotency_key is required")
    replay = db.scalar(select(PaperTrade).where(PaperTrade.close_key == idempotency_key))
    position = db.get(PaperPosition, position_id)
    if replay:
        if replay.position_id != position_id:
            raise PaperLedgerError("Idempotency key was already used for another position")
        return replay, None, True  # type: ignore[return-value]
    if position is None:
        raise PaperLedgerError("Paper position not found")
    if position.status != "OPEN":
        raise PaperLedgerError("Paper position is already closed or closing")
    qty = D(position.quantity, "position quantity")
    side = Side.SELL if position.direction == "LONG" else Side.BUY
    fill = simulate_market_fill(book, side, qty, fee_rate, max_slippage_bps)
    if fill.status != "filled" or fill.average_price is None:
        raise PaperLedgerError("Paper close requires a full simulated fill")
    entry, exit_price = D(position.entry_price, "entry_price"), fill.average_price
    gross = (exit_price - entry) * qty if position.direction == "LONG" else (entry - exit_price) * qty
    entry_fee, exit_fee = D(position.entry_fee, "entry_fee"), fill.fee_quote
    net = gross - entry_fee - exit_fee
    # Claim the open position atomically. This prevents concurrent close
    # requests with different idempotency keys from crediting the wallet twice.
    claim = db.execute(update(PaperPosition).where(
        PaperPosition.id == position_id, PaperPosition.status == "OPEN"
    ).values(status="CLOSING").execution_options(synchronize_session=False))
    if claim.rowcount != 1:
        db.rollback()
        raise PaperLedgerError("Paper position is already closed or closing")
    position.status = "CLOSING"
    wallet = _wallet(db)
    credit = update(PaperWallet).where(PaperWallet.id == 1).values(
        available_balance=cast(
            cast(PaperWallet.available_balance, Numeric(38, 18))
            + D(position.collateral, "collateral") + gross - exit_fee, String(48)),
        realized_pnl=cast(
            cast(PaperWallet.realized_pnl, Numeric(38, 18)) + net, String(48)),
    )
    db.execute(credit.execution_options(synchronize_session=False))
    db.refresh(wallet)
    position.status = "CLOSED"
    position.closed_at = datetime.now(timezone.utc)
    position.close_key = idempotency_key
    trade = PaperTrade(
        position_id=position.id, symbol=position.symbol, direction=position.direction,
        quantity=position.quantity, entry_price=position.entry_price, exit_price=str(exit_price),
        gross_pnl=str(gross), entry_fee=str(entry_fee), exit_fee=str(exit_fee),
        realized_pnl=str(net), close_key=idempotency_key,
    )
    db.add(trade)
    try:
        db.commit()
    except Exception:
        db.rollback()
        replay = db.scalar(select(PaperTrade).where(PaperTrade.close_key == idempotency_key))
        if replay:
            return replay, None, True  # type: ignore[return-value]
        raise
    db.refresh(trade)
    return trade, fill, False


def wallet_snapshot(db: Session) -> dict:
    wallet = _wallet(db)
    positions = db.scalars(select(PaperPosition).where(PaperPosition.status == "OPEN")).all()
    reserved = sum((D(p.collateral, "collateral") for p in positions), Decimal(0))
    return {
        "mode": "paper_only", "quote_asset": wallet.quote_asset,
        "initial_balance": wallet.initial_balance,
        "available_balance": wallet.available_balance,
        "reserved_collateral": str(reserved),
        "realized_pnl": wallet.realized_pnl,
        "entry_paused": False, "pause_reason": None,
        "open_positions": len(positions),
        "equity_excluding_unrealized_pnl": str(D(wallet.available_balance, "available_balance") + reserved),
    }

class PaperPositionPlan(Base):
    """Persistent protective levels for automatically managed paper LONG positions."""
    __tablename__ = "paper_position_plans"
    position_id: Mapped[str] = mapped_column(String(36), primary_key=True)
    stop_loss: Mapped[str] = mapped_column(String(48))
    take_profit: Mapped[str] = mapped_column(String(48))
    source_candle_ts: Mapped[int] = mapped_column(Integer, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    last_checked_candle_ts: Mapped[int] = mapped_column(Integer, default=0)
    exit_reason: Mapped[str | None] = mapped_column(String(24), nullable=True)
