"""Wallex SPOT private client: place / get / cancel LIMIT orders only. NO withdrawal or transfer methods exist.

Endpoint shapes follow https://developers.wallex.ir (spot create/get/cancel order pages):
  POST   https://api.wallex.ir/v1/account/orders          (success = HTTP 201)
  GET    https://api.wallex.ir/v1/account/orders/{client_id}
  DELETE https://api.wallex.ir/v1/account/orders/{client_id}
Auth: `x-api-key` header. UNVERIFIED against the live API: the exact accepted `type` value ("LIMIT"),
quantity/price precision rules, minimum notional and rate limits. Validate with a tiny order first.
Never call this directly: go through LiveWallexGateway, which enforces the persistent live guard.
"""
from __future__ import annotations

import os
import re
from decimal import Decimal, InvalidOperation
from typing import Any, Callable

BASE_URL = "https://api.wallex.ir"
_SYMBOL = re.compile(r"^[A-Z0-9]{3,20}$")
_CLIENT_ID = re.compile(r"^[A-Za-z0-9._-]{1,64}$")

# request(method, url, headers, json_body_or_None) -> (status_code, parsed_json_dict)
Requester = Callable[[str, str, dict, "dict | None"], "tuple[int, dict]"]


class WallexTradeError(RuntimeError):
    pass


def _httpx_request(method: str, url: str, headers: dict, body: dict | None) -> tuple[int, dict]:
    import httpx  # lazy: keeps this module importable without httpx
    resp = httpx.request(method, url, headers=headers, json=body, timeout=10.0)
    try:
        data = resp.json()
    except ValueError:
        data = {"message": resp.text[:200]}
    return resp.status_code, data


def _positive_decimal(value: Any, name: str) -> str:
    try:
        d = Decimal(str(value))
    except InvalidOperation as exc:
        raise WallexTradeError(f"{name} must be a decimal number") from exc
    if not d.is_finite() or d <= 0:
        raise WallexTradeError(f"{name} must be a positive finite number")
    return format(d, "f")


class WallexSpotTrader:
    def __init__(self, api_key: str, base_url: str = BASE_URL, requester: Requester | None = None):
        if not api_key or not api_key.strip():
            raise WallexTradeError("API key is required")
        self._api_key = api_key.strip()
        self._base = base_url.rstrip("/")
        self._request = requester or _httpx_request

    @classmethod
    def from_env(cls, requester: Requester | None = None) -> "WallexSpotTrader":
        return cls(os.environ.get("WALLEX_API_KEY", ""), requester=requester)

    def __repr__(self) -> str:  # never expose the key
        return "WallexSpotTrader(api_key=***)"

    def _call(self, method: str, path: str, body: dict | None, ok: tuple[int, ...]) -> dict:
        status, data = self._request(method, self._base + path, {"x-api-key": self._api_key,
                                                                  "Content-Type": "application/json"}, body)
        if status not in ok or not isinstance(data, dict) or data.get("success") is not True:
            msg = data.get("message") if isinstance(data, dict) else None
            raise WallexTradeError(f"Wallex request failed (HTTP {status}): {str(msg)[:200]}")
        return data.get("result") or {}

    def place_limit_order(self, symbol: str, side: str, price: Any, quantity: Any, client_id: str) -> dict:
        symbol = str(symbol).upper()
        side = str(side).upper()
        if not _SYMBOL.match(symbol):
            raise WallexTradeError("invalid symbol")
        if side not in ("BUY", "SELL"):
            raise WallexTradeError("side must be BUY or SELL")
        if not _CLIENT_ID.match(str(client_id)):
            raise WallexTradeError("client_id must be 1-64 chars of letters, digits, . _ -")
        body = {"client_id": str(client_id), "symbol": symbol, "side": side, "type": "LIMIT",
                "price": _positive_decimal(price, "price"), "quantity": _positive_decimal(quantity, "quantity")}
        return self._call("POST", "/v1/account/orders", body, ok=(201,))

    def get_order(self, client_id: str) -> dict:
        if not _CLIENT_ID.match(str(client_id)):
            raise WallexTradeError("invalid client_id")
        return self._call("GET", f"/v1/account/orders/{client_id}", None, ok=(200,))

    def cancel_order(self, client_id: str) -> dict:
        if not _CLIENT_ID.match(str(client_id)):
            raise WallexTradeError("invalid client_id")
        return self._call("DELETE", f"/v1/account/orders/{client_id}", None, ok=(200, 201))
