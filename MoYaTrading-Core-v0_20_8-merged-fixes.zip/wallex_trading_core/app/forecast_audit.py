"""Persistent forecast outcome labelling and drift monitoring.

Labels are resolved only after the forecast horizon has elapsed. Neutral moves
remain unresolved because the model excludes neutral labels during training.
This monitor never mutates model weights.
"""
from __future__ import annotations
from decimal import Decimal
from sqlalchemy import select
from sqlalchemy.orm import Session
from .db import ForecastAuditRecord
from .adaptive import ForecastOutcome, DriftMonitor


def record_and_resolve(db: Session, *, symbol: str, resolution: str,
                       forecast: dict | None, candles: list, duration_seconds: int) -> dict:
    if not candles:
        return {"status": "no_candles", "resolved": 0}
    # Resolve with the first observed candle at or after the forecast horizon.
    rows = db.scalars(select(ForecastAuditRecord).where(
        ForecastAuditRecord.symbol == symbol.upper(),
        ForecastAuditRecord.resolution == resolution,
        ForecastAuditRecord.outcome.is_(None),
        ForecastAuditRecord.due_timestamp <= candles[-1].timestamp,
    ).order_by(ForecastAuditRecord.due_timestamp.asc())).all()
    resolved = 0
    for row in rows:
        future = next((c for c in candles if c.timestamp >= row.due_timestamp), None)
        if future is None:
            continue
        change = Decimal(str(future.close)) / Decimal(row.entry_price) - Decimal(1)
        threshold = Decimal(row.min_move_pct)
        if change > threshold:
            actual = "BULLISH"
        elif change < -threshold:
            actual = "BEARISH"
        else:
            # Match the training label policy: neutral outcomes are excluded.
            row.resolved_timestamp = future.timestamp
            row.outcome = -1
            resolved += 1
            continue
        row.outcome = int(actual == row.direction)
        row.resolved_timestamp = future.timestamp
        resolved += 1

    recorded = 0
    if forecast:
        for item in forecast.get("timeframes", []):
            if item.get("timeframe") != resolution or item.get("status") != "calibrated":
                continue
            ts = int(item.get("last_candle_timestamp") or 0)
            bullish_probability = item.get("calibrated_bullish_probability_pct")
            entry = item.get("last_close")
            direction = item.get("direction")
            if ts <= 0 or not entry or direction not in {"BULLISH", "BEARISH"} or bullish_probability is None:
                continue
            bullish_probability = Decimal(str(bullish_probability)) / Decimal(100)
            confidence = bullish_probability if direction == "BULLISH" else Decimal(1) - bullish_probability
            existing = db.scalar(select(ForecastAuditRecord).where(
                ForecastAuditRecord.symbol == symbol.upper(),
                ForecastAuditRecord.resolution == resolution,
                ForecastAuditRecord.forecast_timestamp == ts))
            if existing is None:
                regime = item.get("regime", {}).get("regime", "UNKNOWN") if isinstance(item.get("regime"), dict) else "UNKNOWN"
                db.add(ForecastAuditRecord(symbol=symbol.upper(), resolution=resolution,
                    forecast_timestamp=ts, due_timestamp=ts + duration_seconds * int(item.get("horizon_bars", 3)),
                    entry_price=str(entry), direction=direction,
                    confidence=str(confidence),
                    min_move_pct="0.0025", regime=str(regime)))
                recorded += 1
    db.commit()
    resolved_rows = db.scalars(select(ForecastAuditRecord).where(
        ForecastAuditRecord.symbol == symbol.upper(),
        ForecastAuditRecord.resolution == resolution,
        ForecastAuditRecord.outcome.in_([0, 1]),
    ).order_by(ForecastAuditRecord.forecast_timestamp.asc())).all()
    monitor = DriftMonitor()
    for row in resolved_rows:
        monitor.add(ForecastOutcome(timestamp=row.forecast_timestamp,
            probability=float(row.confidence), outcome=int(row.outcome),
            regime=row.regime, timeframe=row.resolution))
    status = monitor.status()
    status.update({"recorded": recorded, "newly_resolved": resolved,
                   "total_resolved": len(resolved_rows),
                   "neutral_excluded": db.query(ForecastAuditRecord).filter(
                       ForecastAuditRecord.symbol == symbol.upper(),
                       ForecastAuditRecord.resolution == resolution,
                       ForecastAuditRecord.outcome == -1).count()})
    return status
