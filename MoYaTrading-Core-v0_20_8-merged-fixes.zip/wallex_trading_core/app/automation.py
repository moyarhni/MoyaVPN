"""Automatic, read-only market scan and decision pipeline.

This module fetches public Wallex candles, excludes the still-forming candle,
runs the existing decision stack, and records the result. It never places orders.
"""
from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from decimal import Decimal
from sqlalchemy import select, desc
from sqlalchemy.orm import Session

from .config import settings
from .db import MarketEvent, SystemEvent
from .market_data import normalize_udf_candles, MarketDataError
from .decision_engine import make_decision
from .paper_ledger import PaperWallet, PaperPosition
from .paper_ledger import D as ledger_decimal
from .predictive_engine import forecast_market, ForecastConfig
from .circuit_breaker import entries_paused
from .economic import estimate_first_passage_probability
from .paper_automation import process_symbol_paper_cycle
from .forecast_audit import record_and_resolve

_LAST_FORECAST_AT: dict[str, int] = {}

RESOLUTION_SECONDS = {
    "1": 60, "3": 180, "5": 300, "15": 900, "30": 1800,
    "60": 3600, "120": 7200, "240": 14400, "1D": 86400,
    "1W": 604800,
}


def closed_candles(payload: dict, resolution: str, now_ts: int | None = None):
    """Normalize UDF candles and keep only candles whose interval has ended."""
    if resolution not in RESOLUTION_SECONDS:
        raise ValueError(f"Unsupported analysis resolution: {resolution}")
    candles = normalize_udf_candles(payload)
    now = int(now_ts if now_ts is not None else time.time())
    duration = RESOLUTION_SECONDS[resolution]
    return [c for c in candles if c.timestamp + duration <= now]


def _portfolio_inputs(db: Session, symbol: str) -> tuple[Decimal, Decimal]:
    wallet = db.get(PaperWallet, 1)
    if wallet is None:
        return Decimal("0"), Decimal("0")
    positions = db.scalars(
        select(PaperPosition).where(
            PaperPosition.symbol == symbol.upper(),
            PaperPosition.status == "OPEN",
            PaperPosition.direction == "LONG",
        )
    ).all()
    base_qty = sum((ledger_decimal(p.quantity, "quantity") for p in positions), Decimal("0"))
    return ledger_decimal(wallet.available_balance, "available_balance"), base_qty


async def analyze_symbol(client, db: Session, symbol: str, *, resolution: str | None = None,
                         now_ts: int | None = None) -> dict:
    resolution = resolution or settings.analysis_resolution
    if resolution not in RESOLUTION_SECONDS:
        raise ValueError(f"Unsupported analysis resolution: {resolution}")
    end = int(now_ts if now_ts is not None else time.time())
    duration = RESOLUTION_SECONDS[resolution]
    start = end - duration * max(100, min(settings.analysis_lookback_candles, 1000))
    raw = await client.candles(symbol, resolution, start, end)
    candles = closed_candles(raw, resolution, end)
    if len(candles) < 60:
        result = {
            "symbol": symbol.upper(), "resolution": resolution,
            "status": "insufficient_closed_candles", "closed_candles": len(candles),
            "required_minimum": 60, "action": "NO_TRADE",
        }
    else:
        quote_balance, base_quantity = _portfolio_inputs(db, symbol)
        decision = make_decision(
            candles, symbol=symbol, quote_balance=quote_balance,
            base_quantity=base_quantity,
            entry_paused=False,
        )
        result = {
            "symbol": symbol.upper(), "resolution": resolution,
            "status": "analyzed", "closed_candles": len(candles),
            "last_closed_candle": candles[-1].timestamp,
            "decision": decision,
            "execution": {
                "mode": "paper_preview_only",
                "order_submitted": False,
                "reason": "Automated order execution is deliberately disabled; this cycle records analysis only.",
            },
        }
        levels = decision.get("levels", {})
        try:
            reference = Decimal(str(levels.get("reference_price")))
            stop_level = Decimal(str(levels.get("stop_loss")))
            target_level = Decimal(str(levels.get("take_profit")))
            if reference > 0 and 0 < stop_level < reference < target_level:
                result["trade_economics"] = estimate_first_passage_probability(
                    candles, target_pct=(target_level-reference)/reference,
                    stop_pct=(reference-stop_level)/reference, horizon_bars=12,
                    fee_rate="0.001", slippage_bps="5", min_samples=40)
            else:
                result["trade_economics"] = {"status":"invalid_levels", "action":"NO_TRADE"}
        except (ValueError, ArithmeticError, TypeError):
            result["trade_economics"] = {"status":"unavailable", "action":"NO_TRADE"}
        if settings.forecast_enabled:
            last_forecast = _LAST_FORECAST_AT.get(symbol.upper(), 0)
            if end - last_forecast >= max(60, settings.forecast_refresh_seconds):
                multi_tf: dict[str, list] = {}
                forecast_errors: dict[str, str] = {}
                for tf in settings.forecast_timeframe_list:
                    if tf not in RESOLUTION_SECONDS:
                        forecast_errors[tf] = "unsupported_resolution"
                        continue
                    tf_duration = RESOLUTION_SECONDS[tf]
                    tf_start = end - tf_duration * max(100, min(settings.forecast_lookback_candles, 2000))
                    try:
                        tf_raw = await client.candles(symbol, tf, tf_start, end)
                        multi_tf[tf] = closed_candles(tf_raw, tf, end)
                    except Exception as exc:
                        forecast_errors[tf] = f"{type(exc).__name__}: {exc}"
                if multi_tf:
                    result["forecast"] = forecast_market(multi_tf, symbol=symbol, cfg=ForecastConfig())
                    result["forecast"]["data_errors"] = forecast_errors
                    drift_status = {}
                    for tf, tf_candles in multi_tf.items():
                        if tf_candles:
                            drift_status[tf] = record_and_resolve(
                                db, symbol=symbol, resolution=tf, forecast=result["forecast"],
                                candles=tf_candles, duration_seconds=RESOLUTION_SECONDS[tf])
                    result["forecast"]["drift_monitor"] = drift_status
                    drift_detected = any(x.get("drift_detected", False) for x in drift_status.values())
                    predictive_action = result["forecast"].get("action")
                    existing_action = decision.get("action")
                    economics = result.get("trade_economics", {})
                    economic_gate = (economics.get("status") == "estimated"
                        and economics.get("win_probability_lower_bound_pct") is not None
                        and economics["win_probability_lower_bound_pct"] > 80
                        and Decimal(str(economics.get("net_expectancy_pct_per_trade", "-1"))) > 0)
                    result["forecast"]["economic_gate"] = {"passed": economic_gate,
                        "used_for_entry_authorization": False,
                        "reason": "informational_only_not_an_independent_deployment_holdout"}
                    if result["forecast"].get("entry_gate_passed") and existing_action == "BUY" and not drift_detected:
                        integrated_action = "BUY_CANDIDATE"
                        integrated_reason = "Calibrated multi-timeframe OOS forecast and existing indicator/pattern/risk decision passed. Economic first-passage estimate is informational only because it is not an independent deployment holdout."
                    elif predictive_action == "REDUCE_RISK_OR_EXIT" and existing_action == "SELL":
                        integrated_action = "SELL_CANDIDATE"
                        integrated_reason = "Bearish predictive evidence and existing Spot sell decision agree; this does not open a short."
                    else:
                        integrated_action = "NO_TRADE"
                        integrated_reason = "Predictive gate and existing decision did not both authorize an entry."
                    result["forecast"]["integrated_decision"] = {"action": integrated_action,
                        "existing_decision": existing_action, "predictive_action": predictive_action,
                        "live_entry_circuit_paused": entries_paused(db), "drift_detected": drift_detected, "reason": integrated_reason,
                        "orders_submitted": False}
                else:
                    result["forecast"] = {"status": "no_timeframe_data", "data_errors": forecast_errors,
                                          "action": "NO_TRADE", "entry_gate_passed": False}
                _LAST_FORECAST_AT[symbol.upper()] = end
        if candles:
            try:
                paper_result = await process_symbol_paper_cycle(
                    client, db, symbol, candles[-1], decision,
                    result.get("forecast") if isinstance(result.get("forecast"), dict) else None,
                    candles=candles,
                )
                result["paper_automation"] = paper_result
            except Exception as exc:
                db.rollback()
                result["paper_automation"] = {"enabled": settings.paper_auto_trading_enabled,
                    "error": f"{type(exc).__name__}: {exc}", "action": "NO_TRADE"}
    db.add(SystemEvent(level="INFO", message="AUTO_ANALYSIS " + json.dumps(result, default=str, separators=(",", ":"))))
    db.commit()
    return result


async def run_analysis_cycle(client, db: Session, symbols: list[str] | None = None,
                             *, resolution: str | None = None, now_ts: int | None = None) -> dict:
    targets = symbols or settings.symbol_list
    results = []
    for symbol in targets:
        try:
            results.append(await analyze_symbol(client, db, symbol, resolution=resolution, now_ts=now_ts))
        except Exception as exc:
            db.rollback()
            error = {"symbol": symbol.upper(), "status": "error",
                     "error": f"{type(exc).__name__}: {exc}", "action": "NO_TRADE"}
            db.add(SystemEvent(level="ERROR", message="AUTO_ANALYSIS " + json.dumps(error)))
            db.commit()
            results.append(error)
    return {
        "mode": "automatic_market_analysis_with_optional_paper_execution",
        "orders_submitted": False,
        "resolution": resolution or settings.analysis_resolution,
        "results": results,
        "analyzed": sum(1 for item in results if item["status"] == "analyzed"),
        "errors": sum(1 for item in results if item["status"] == "error"),
    }


def latest_analysis(db: Session, limit: int = 20) -> list[dict]:
    rows = db.scalars(
        select(SystemEvent).where(SystemEvent.message.like("AUTO_ANALYSIS %"))
        .order_by(desc(SystemEvent.id)).limit(limit)
    ).all()
    output = []
    for row in rows:
        try:
            output.append(json.loads(row.message[len("AUTO_ANALYSIS "):]))
        except (ValueError, TypeError):
            continue
    return output
