"""Pure risk calculations. This module never submits or manages exchange orders."""
from dataclasses import dataclass
from decimal import Decimal
D = Decimal

@dataclass(frozen=True, slots=True)
class RiskConfig:
    risk_fraction: Decimal = D("0.01")
    max_position_fraction: Decimal = D("0.25")
    fee_rate: Decimal = D("0.001")
    max_daily_loss_fraction: Decimal = D("0.03")

    def validate(self):
        if not D("0") < self.risk_fraction <= D("0.05"): raise ValueError("risk_fraction must be in (0, 0.05]")
        if not D("0") < self.max_position_fraction <= D("1"): raise ValueError("max_position_fraction must be in (0, 1]")
        if not D("0") <= self.fee_rate < D("0.1"): raise ValueError("fee_rate out of range")
        if not D("0") < self.max_daily_loss_fraction <= D("0.2"): raise ValueError("daily loss limit out of range")

def size_spot_position(*, quote_balance: Decimal, entry: Decimal, stop: Decimal,
                       config: RiskConfig | None = None, daily_realized_loss: Decimal = D("0")) -> dict:
    cfg = config or RiskConfig(); cfg.validate()
    vals = [D(str(x)) for x in (quote_balance, entry, stop, daily_realized_loss)]
    balance, price, stop_price, daily_loss = vals
    if any(not x.is_finite() for x in vals) or balance < 0 or price <= 0 or stop_price <= 0 or daily_loss < 0:
        raise ValueError("Invalid risk input")
    daily_limit = balance * cfg.max_daily_loss_fraction
    if daily_loss >= daily_limit and daily_limit > 0:
        return {"allowed": False, "quantity": "0", "reason": "daily_loss_limit_reached"}
    if stop_price >= price:
        return {"allowed": False, "quantity": "0", "reason": "stop_must_be_below_entry_for_spot_long"}
    risk_budget = balance * cfg.risk_fraction
    per_unit = price - stop_price + (price + stop_price) * cfg.fee_rate
    by_risk = risk_budget / per_unit if per_unit > 0 else D("0")
    by_cap = balance * cfg.max_position_fraction / price
    qty = min(by_risk, by_cap)
    if qty <= 0:
        return {"allowed": False, "quantity": "0", "reason": "insufficient_balance"}
    return {"allowed": True, "quantity": str(qty), "risk_budget": str(risk_budget),
            "position_value": str(qty * price), "daily_loss_limit": str(daily_limit), "reason": "risk_checks_passed"}


def check_portfolio_risk(*, equity: Decimal, open_position_values: list[Decimal],
                         daily_realized_loss: Decimal = D("0"),
                         max_total_exposure_fraction: Decimal = D("0.50"),
                         max_daily_loss_fraction: Decimal = D("0.03")) -> dict:
    """Portfolio-level spot exposure and daily-loss guard."""
    values = [D(str(x)) for x in [equity, daily_realized_loss, max_total_exposure_fraction,
                                  max_daily_loss_fraction, *open_position_values]]
    if any(not x.is_finite() for x in values) or equity <= 0 or daily_realized_loss < 0:
        raise ValueError("Invalid portfolio risk inputs")
    exposure_cap, daily_cap = values[2], values[3]
    if not 0 < exposure_cap <= 1 or not 0 < daily_cap <= D("0.2") or any(x < 0 for x in values[4:]):
        raise ValueError("Invalid portfolio risk limits")
    exposure = sum(values[4:], D("0"))
    exposure_fraction = exposure/equity
    daily_fraction = daily_realized_loss/equity
    reasons = []
    if exposure_fraction >= exposure_cap: reasons.append("total_exposure_limit_reached")
    if daily_fraction >= daily_cap: reasons.append("daily_loss_limit_reached")
    return {"allowed": not reasons, "equity": str(equity), "open_exposure": str(exposure),
            "exposure_fraction": str(exposure_fraction), "daily_loss_fraction": str(daily_fraction),
            "reasons": reasons, "action": "BLOCK_NEW_ENTRIES" if reasons else "ALLOW_WITHIN_LIMITS"}
