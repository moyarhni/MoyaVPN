"""Pure stop/target scan over ALL closed candles since the last check (no DB, no I/O).

Why: checking only the newest candle misses a stop breached in an earlier candle
(e.g. after a restart or a skipped cycle). Within one candle the stop wins ties
(OHLC cannot reveal intrabar order), and earlier candles win over later ones.
"""
from __future__ import annotations
from decimal import Decimal
from typing import Iterable, Sequence


def find_exit(candles: Sequence, stop, target, after_ts: int) -> tuple[str, int] | None:
    """Return ("stop_loss"|"take_profit", candle_timestamp) for the first exit trigger on a
    candle with timestamp > after_ts, or None."""
    stop_d, target_d = Decimal(str(stop)), Decimal(str(target))
    for c in sorted((c for c in candles if c.timestamp > after_ts), key=lambda c: c.timestamp):
        if Decimal(str(c.low)) <= stop_d:
            return "stop_loss", int(c.timestamp)
        if Decimal(str(c.high)) >= target_d:
            return "take_profit", int(c.timestamp)
    return None
