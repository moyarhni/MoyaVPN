"""Causal market-regime classification from closed OHLCV candles only."""
from __future__ import annotations
from statistics import mean, pstdev
from typing import Sequence
from .market_data import Candle


def classify_regime(candles: Sequence[Candle], lookback: int = 30) -> dict:
    if lookback < 10:
        raise ValueError("lookback must be at least 10")
    if len(candles) < lookback + 1:
        return {"status": "insufficient_data", "regime": "UNKNOWN", "confidence": 0.0}
    window = list(candles[-lookback:])
    closes = [float(c.close) for c in window]
    highs = [float(c.high) for c in window]
    lows = [float(c.low) for c in window]
    returns = [closes[i] / closes[i-1] - 1 for i in range(1, len(closes))]
    volatility = pstdev(returns) if len(returns) > 1 else 0.0
    net_move = abs(closes[-1] / closes[0] - 1.0)
    path_move = sum(abs(closes[i] / closes[i-1] - 1.0) for i in range(1, len(closes)))
    efficiency = net_move / path_move if path_move > 0 else 0.0
    ranges = [(h-l)/max(c, 1e-12) for h, l, c in zip(highs, lows, closes)]
    range_pct = mean(ranges)
    # Thresholds are transparent heuristics, not learned labels.
    if volatility >= 0.025 or range_pct >= 0.04:
        regime = "HIGH_VOLATILITY"
        confidence = min(0.99, max(volatility / 0.04, range_pct / 0.06))
    elif efficiency >= 0.42 and net_move >= 0.012:
        regime = "TRENDING"
        confidence = min(0.99, 0.5 + efficiency * 0.5)
    else:
        regime = "RANGING"
        confidence = min(0.95, max(0.5, 1.0 - efficiency))
    direction = "UP" if closes[-1] > closes[0] else "DOWN" if closes[-1] < closes[0] else "FLAT"
    return {"status": "classified", "regime": regime, "direction": direction,
            "confidence": round(confidence, 4), "realized_volatility_pct": round(volatility*100, 4),
            "average_candle_range_pct": round(range_pct*100, 4),
            "efficiency_ratio": round(efficiency, 4), "lookback": lookback,
            "data_cutoff_timestamp": window[-1].timestamp,
            "method": "causal_rolling_efficiency_and_realized_volatility_heuristic"}
